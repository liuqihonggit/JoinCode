window.__ModuleLoader__.load({
	id: "@deepseek-ai/dsh-api-remotes",
	factory: (require) => {
		var module = { exports: {} };
		var exports = module.exports;
		Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
		//#region ../../../node_modules/.pnpm/zod@4.4.3/node_modules/zod/v4/core/core.js
		var _a$1;
		function $constructor(name, initializer, params) {
			function init(inst, def) {
				if (!inst._zod) Object.defineProperty(inst, "_zod", {
					value: {
						def,
						constr: _,
						traits: /* @__PURE__ */ new Set()
					},
					enumerable: false
				});
				if (inst._zod.traits.has(name)) return;
				inst._zod.traits.add(name);
				initializer(inst, def);
				const proto = _.prototype;
				const keys = Object.keys(proto);
				for (let i = 0; i < keys.length; i++) {
					const k = keys[i];
					if (!(k in inst)) inst[k] = proto[k].bind(inst);
				}
			}
			const Parent = params?.Parent ?? Object;
			class Definition extends Parent {}
			Object.defineProperty(Definition, "name", { value: name });
			function _(def) {
				var _a;
				const inst = params?.Parent ? new Definition() : this;
				init(inst, def);
				(_a = inst._zod).deferred ?? (_a.deferred = []);
				for (const fn of inst._zod.deferred) fn();
				return inst;
			}
			Object.defineProperty(_, "init", { value: init });
			Object.defineProperty(_, Symbol.hasInstance, { value: (inst) => {
				if (params?.Parent && inst instanceof params.Parent) return true;
				return inst?._zod?.traits?.has(name);
			} });
			Object.defineProperty(_, "name", { value: name });
			return _;
		}
		var $ZodAsyncError = class extends Error {
			constructor() {
				super(`Encountered Promise during synchronous parse. Use .parseAsync() instead.`);
			}
		};
		var $ZodEncodeError = class extends Error {
			constructor(name) {
				super(`Encountered unidirectional transform during encode: ${name}`);
				this.name = "ZodEncodeError";
			}
		};
		(_a$1 = globalThis).__zod_globalConfig ?? (_a$1.__zod_globalConfig = {});
		const globalConfig = globalThis.__zod_globalConfig;
		function config(newConfig) {
			if (newConfig) Object.assign(globalConfig, newConfig);
			return globalConfig;
		}
		//#endregion
		//#region ../../../node_modules/.pnpm/zod@4.4.3/node_modules/zod/v4/core/util.js
		function getEnumValues(entries) {
			const numericValues = Object.values(entries).filter((v) => typeof v === "number");
			return Object.entries(entries).filter(([k, _]) => numericValues.indexOf(+k) === -1).map(([_, v]) => v);
		}
		function jsonStringifyReplacer(_, value) {
			if (typeof value === "bigint") return value.toString();
			return value;
		}
		function cached(getter) {
			return { get value() {
				{
					const value = getter();
					Object.defineProperty(this, "value", { value });
					return value;
				}
				throw new Error("cached value already set");
			} };
		}
		function nullish(input) {
			return input === null || input === void 0;
		}
		function cleanRegex(source) {
			const start = source.startsWith("^") ? 1 : 0;
			const end = source.endsWith("$") ? source.length - 1 : source.length;
			return source.slice(start, end);
		}
		function floatSafeRemainder(val, step) {
			const ratio = val / step;
			const roundedRatio = Math.round(ratio);
			const tolerance = Number.EPSILON * Math.max(Math.abs(ratio), 1);
			if (Math.abs(ratio - roundedRatio) < tolerance) return 0;
			return ratio - roundedRatio;
		}
		const EVALUATING = /* @__PURE__*/ Symbol("evaluating");
		function defineLazy(object, key, getter) {
			let value = void 0;
			Object.defineProperty(object, key, {
				get() {
					if (value === EVALUATING) return;
					if (value === void 0) {
						value = EVALUATING;
						value = getter();
					}
					return value;
				},
				set(v) {
					Object.defineProperty(object, key, { value: v });
				},
				configurable: true
			});
		}
		function assignProp(target, prop, value) {
			Object.defineProperty(target, prop, {
				value,
				writable: true,
				enumerable: true,
				configurable: true
			});
		}
		function mergeDefs(...defs) {
			const mergedDescriptors = {};
			for (const def of defs) Object.assign(mergedDescriptors, Object.getOwnPropertyDescriptors(def));
			return Object.defineProperties({}, mergedDescriptors);
		}
		function esc(str) {
			return JSON.stringify(str);
		}
		function slugify(input) {
			return input.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
		}
		const captureStackTrace = "captureStackTrace" in Error ? Error.captureStackTrace : (..._args) => {};
		function isObject(data) {
			return typeof data === "object" && data !== null && !Array.isArray(data);
		}
		const allowsEval = /* @__PURE__*/ cached(() => {
			if (globalConfig.jitless) return false;
			if (typeof navigator !== "undefined" && navigator?.userAgent?.includes("Cloudflare")) return false;
			try {
				new Function("");
				return true;
			} catch (_) {
				return false;
			}
		});
		function isPlainObject(o) {
			if (isObject(o) === false) return false;
			const ctor = o.constructor;
			if (ctor === void 0) return true;
			if (typeof ctor !== "function") return true;
			const prot = ctor.prototype;
			if (isObject(prot) === false) return false;
			if (Object.prototype.hasOwnProperty.call(prot, "isPrototypeOf") === false) return false;
			return true;
		}
		function shallowClone(o) {
			if (isPlainObject(o)) return { ...o };
			if (Array.isArray(o)) return [...o];
			if (o instanceof Map) return new Map(o);
			if (o instanceof Set) return new Set(o);
			return o;
		}
		const propertyKeyTypes = /* @__PURE__*/ new Set([
			"string",
			"number",
			"symbol"
		]);
		function escapeRegex(str) {
			return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
		}
		function clone(inst, def, params) {
			const cl = new inst._zod.constr(def ?? inst._zod.def);
			if (!def || params?.parent) cl._zod.parent = inst;
			return cl;
		}
		function normalizeParams(_params) {
			const params = _params;
			if (!params) return {};
			if (typeof params === "string") return { error: () => params };
			if (params?.message !== void 0) {
				if (params?.error !== void 0) throw new Error("Cannot specify both `message` and `error` params");
				params.error = params.message;
			}
			delete params.message;
			if (typeof params.error === "string") return {
				...params,
				error: () => params.error
			};
			return params;
		}
		function optionalKeys(shape) {
			return Object.keys(shape).filter((k) => {
				return shape[k]._zod.optin === "optional" && shape[k]._zod.optout === "optional";
			});
		}
		const NUMBER_FORMAT_RANGES = {
			safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
			int32: [-2147483648, 2147483647],
			uint32: [0, 4294967295],
			float32: [-34028234663852886e22, 34028234663852886e22],
			float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
		};
		function pick(schema, mask) {
			const currDef = schema._zod.def;
			const checks = currDef.checks;
			if (checks && checks.length > 0) throw new Error(".pick() cannot be used on object schemas containing refinements");
			return clone(schema, mergeDefs(schema._zod.def, {
				get shape() {
					const newShape = {};
					for (const key in mask) {
						if (!(key in currDef.shape)) throw new Error(`Unrecognized key: "${key}"`);
						if (!mask[key]) continue;
						newShape[key] = currDef.shape[key];
					}
					assignProp(this, "shape", newShape);
					return newShape;
				},
				checks: []
			}));
		}
		function omit(schema, mask) {
			const currDef = schema._zod.def;
			const checks = currDef.checks;
			if (checks && checks.length > 0) throw new Error(".omit() cannot be used on object schemas containing refinements");
			return clone(schema, mergeDefs(schema._zod.def, {
				get shape() {
					const newShape = { ...schema._zod.def.shape };
					for (const key in mask) {
						if (!(key in currDef.shape)) throw new Error(`Unrecognized key: "${key}"`);
						if (!mask[key]) continue;
						delete newShape[key];
					}
					assignProp(this, "shape", newShape);
					return newShape;
				},
				checks: []
			}));
		}
		function extend(schema, shape) {
			if (!isPlainObject(shape)) throw new Error("Invalid input to extend: expected a plain object");
			const checks = schema._zod.def.checks;
			if (checks && checks.length > 0) {
				const existingShape = schema._zod.def.shape;
				for (const key in shape) if (Object.getOwnPropertyDescriptor(existingShape, key) !== void 0) throw new Error("Cannot overwrite keys on object schemas containing refinements. Use `.safeExtend()` instead.");
			}
			return clone(schema, mergeDefs(schema._zod.def, { get shape() {
				const _shape = {
					...schema._zod.def.shape,
					...shape
				};
				assignProp(this, "shape", _shape);
				return _shape;
			} }));
		}
		function safeExtend(schema, shape) {
			if (!isPlainObject(shape)) throw new Error("Invalid input to safeExtend: expected a plain object");
			return clone(schema, mergeDefs(schema._zod.def, { get shape() {
				const _shape = {
					...schema._zod.def.shape,
					...shape
				};
				assignProp(this, "shape", _shape);
				return _shape;
			} }));
		}
		function merge(a, b) {
			if (a._zod.def.checks?.length) throw new Error(".merge() cannot be used on object schemas containing refinements. Use .safeExtend() instead.");
			return clone(a, mergeDefs(a._zod.def, {
				get shape() {
					const _shape = {
						...a._zod.def.shape,
						...b._zod.def.shape
					};
					assignProp(this, "shape", _shape);
					return _shape;
				},
				get catchall() {
					return b._zod.def.catchall;
				},
				checks: b._zod.def.checks ?? []
			}));
		}
		function partial(Class, schema, mask) {
			const checks = schema._zod.def.checks;
			if (checks && checks.length > 0) throw new Error(".partial() cannot be used on object schemas containing refinements");
			return clone(schema, mergeDefs(schema._zod.def, {
				get shape() {
					const oldShape = schema._zod.def.shape;
					const shape = { ...oldShape };
					if (mask) for (const key in mask) {
						if (!(key in oldShape)) throw new Error(`Unrecognized key: "${key}"`);
						if (!mask[key]) continue;
						shape[key] = Class ? new Class({
							type: "optional",
							innerType: oldShape[key]
						}) : oldShape[key];
					}
					else for (const key in oldShape) shape[key] = Class ? new Class({
						type: "optional",
						innerType: oldShape[key]
					}) : oldShape[key];
					assignProp(this, "shape", shape);
					return shape;
				},
				checks: []
			}));
		}
		function required(Class, schema, mask) {
			return clone(schema, mergeDefs(schema._zod.def, { get shape() {
				const oldShape = schema._zod.def.shape;
				const shape = { ...oldShape };
				if (mask) for (const key in mask) {
					if (!(key in shape)) throw new Error(`Unrecognized key: "${key}"`);
					if (!mask[key]) continue;
					shape[key] = new Class({
						type: "nonoptional",
						innerType: oldShape[key]
					});
				}
				else for (const key in oldShape) shape[key] = new Class({
					type: "nonoptional",
					innerType: oldShape[key]
				});
				assignProp(this, "shape", shape);
				return shape;
			} }));
		}
		function aborted(x, startIndex = 0) {
			if (x.aborted === true) return true;
			for (let i = startIndex; i < x.issues.length; i++) if (x.issues[i]?.continue !== true) return true;
			return false;
		}
		function explicitlyAborted(x, startIndex = 0) {
			if (x.aborted === true) return true;
			for (let i = startIndex; i < x.issues.length; i++) if (x.issues[i]?.continue === false) return true;
			return false;
		}
		function prefixIssues(path, issues) {
			return issues.map((iss) => {
				var _a;
				(_a = iss).path ?? (_a.path = []);
				iss.path.unshift(path);
				return iss;
			});
		}
		function unwrapMessage(message) {
			return typeof message === "string" ? message : message?.message;
		}
		function finalizeIssue(iss, ctx, config) {
			const message = iss.message ? iss.message : unwrapMessage(iss.inst?._zod.def?.error?.(iss)) ?? unwrapMessage(ctx?.error?.(iss)) ?? unwrapMessage(config.customError?.(iss)) ?? unwrapMessage(config.localeError?.(iss)) ?? "Invalid input";
			const { inst: _inst, continue: _continue, input: _input, ...rest } = iss;
			rest.path ?? (rest.path = []);
			rest.message = message;
			if (ctx?.reportInput) rest.input = _input;
			return rest;
		}
		function getLengthableOrigin(input) {
			if (Array.isArray(input)) return "array";
			if (typeof input === "string") return "string";
			return "unknown";
		}
		function issue(...args) {
			const [iss, input, inst] = args;
			if (typeof iss === "string") return {
				message: iss,
				code: "custom",
				input,
				inst
			};
			return { ...iss };
		}
		//#endregion
		//#region ../../../node_modules/.pnpm/zod@4.4.3/node_modules/zod/v4/core/errors.js
		const initializer$1 = (inst, def) => {
			inst.name = "$ZodError";
			Object.defineProperty(inst, "_zod", {
				value: inst._zod,
				enumerable: false
			});
			Object.defineProperty(inst, "issues", {
				value: def,
				enumerable: false
			});
			inst.message = JSON.stringify(def, jsonStringifyReplacer, 2);
			Object.defineProperty(inst, "toString", {
				value: () => inst.message,
				enumerable: false
			});
		};
		const $ZodError = $constructor("$ZodError", initializer$1);
		const $ZodRealError = $constructor("$ZodError", initializer$1, { Parent: Error });
		function flattenError(error, mapper = (issue) => issue.message) {
			const fieldErrors = {};
			const formErrors = [];
			for (const sub of error.issues) if (sub.path.length > 0) {
				fieldErrors[sub.path[0]] = fieldErrors[sub.path[0]] || [];
				fieldErrors[sub.path[0]].push(mapper(sub));
			} else formErrors.push(mapper(sub));
			return {
				formErrors,
				fieldErrors
			};
		}
		function formatError(error, mapper = (issue) => issue.message) {
			const fieldErrors = { _errors: [] };
			const processError = (error, path = []) => {
				for (const issue of error.issues) if (issue.code === "invalid_union" && issue.errors.length) issue.errors.map((issues) => processError({ issues }, [...path, ...issue.path]));
				else if (issue.code === "invalid_key") processError({ issues: issue.issues }, [...path, ...issue.path]);
				else if (issue.code === "invalid_element") processError({ issues: issue.issues }, [...path, ...issue.path]);
				else {
					const fullpath = [...path, ...issue.path];
					if (fullpath.length === 0) fieldErrors._errors.push(mapper(issue));
					else {
						let curr = fieldErrors;
						let i = 0;
						while (i < fullpath.length) {
							const el = fullpath[i];
							if (!(i === fullpath.length - 1)) curr[el] = curr[el] || { _errors: [] };
							else {
								curr[el] = curr[el] || { _errors: [] };
								curr[el]._errors.push(mapper(issue));
							}
							curr = curr[el];
							i++;
						}
					}
				}
			};
			processError(error);
			return fieldErrors;
		}
		//#endregion
		//#region ../../../node_modules/.pnpm/zod@4.4.3/node_modules/zod/v4/core/parse.js
		const _parse = (_Err) => (schema, value, _ctx, _params) => {
			const ctx = _ctx ? {
				..._ctx,
				async: false
			} : { async: false };
			const result = schema._zod.run({
				value,
				issues: []
			}, ctx);
			if (result instanceof Promise) throw new $ZodAsyncError();
			if (result.issues.length) {
				const e = new ((_params?.Err) ?? _Err)(result.issues.map((iss) => finalizeIssue(iss, ctx, config())));
				captureStackTrace(e, _params?.callee);
				throw e;
			}
			return result.value;
		};
		const _parseAsync = (_Err) => async (schema, value, _ctx, params) => {
			const ctx = _ctx ? {
				..._ctx,
				async: true
			} : { async: true };
			let result = schema._zod.run({
				value,
				issues: []
			}, ctx);
			if (result instanceof Promise) result = await result;
			if (result.issues.length) {
				const e = new ((params?.Err) ?? _Err)(result.issues.map((iss) => finalizeIssue(iss, ctx, config())));
				captureStackTrace(e, params?.callee);
				throw e;
			}
			return result.value;
		};
		const _safeParse = (_Err) => (schema, value, _ctx) => {
			const ctx = _ctx ? {
				..._ctx,
				async: false
			} : { async: false };
			const result = schema._zod.run({
				value,
				issues: []
			}, ctx);
			if (result instanceof Promise) throw new $ZodAsyncError();
			return result.issues.length ? {
				success: false,
				error: new (_Err ?? $ZodError)(result.issues.map((iss) => finalizeIssue(iss, ctx, config())))
			} : {
				success: true,
				data: result.value
			};
		};
		const safeParse$1 = /* @__PURE__*/ _safeParse($ZodRealError);
		const _safeParseAsync = (_Err) => async (schema, value, _ctx) => {
			const ctx = _ctx ? {
				..._ctx,
				async: true
			} : { async: true };
			let result = schema._zod.run({
				value,
				issues: []
			}, ctx);
			if (result instanceof Promise) result = await result;
			return result.issues.length ? {
				success: false,
				error: new _Err(result.issues.map((iss) => finalizeIssue(iss, ctx, config())))
			} : {
				success: true,
				data: result.value
			};
		};
		const safeParseAsync$1 = /* @__PURE__*/ _safeParseAsync($ZodRealError);
		const _encode = (_Err) => (schema, value, _ctx) => {
			const ctx = _ctx ? {
				..._ctx,
				direction: "backward"
			} : { direction: "backward" };
			return _parse(_Err)(schema, value, ctx);
		};
		const _decode = (_Err) => (schema, value, _ctx) => {
			return _parse(_Err)(schema, value, _ctx);
		};
		const _encodeAsync = (_Err) => async (schema, value, _ctx) => {
			const ctx = _ctx ? {
				..._ctx,
				direction: "backward"
			} : { direction: "backward" };
			return _parseAsync(_Err)(schema, value, ctx);
		};
		const _decodeAsync = (_Err) => async (schema, value, _ctx) => {
			return _parseAsync(_Err)(schema, value, _ctx);
		};
		const _safeEncode = (_Err) => (schema, value, _ctx) => {
			const ctx = _ctx ? {
				..._ctx,
				direction: "backward"
			} : { direction: "backward" };
			return _safeParse(_Err)(schema, value, ctx);
		};
		const _safeDecode = (_Err) => (schema, value, _ctx) => {
			return _safeParse(_Err)(schema, value, _ctx);
		};
		const _safeEncodeAsync = (_Err) => async (schema, value, _ctx) => {
			const ctx = _ctx ? {
				..._ctx,
				direction: "backward"
			} : { direction: "backward" };
			return _safeParseAsync(_Err)(schema, value, ctx);
		};
		const _safeDecodeAsync = (_Err) => async (schema, value, _ctx) => {
			return _safeParseAsync(_Err)(schema, value, _ctx);
		};
		//#endregion
		//#region ../../../node_modules/.pnpm/zod@4.4.3/node_modules/zod/v4/core/regexes.js
		/**
		* @deprecated CUID v1 is deprecated by its authors due to information leakage
		* (timestamps embedded in the id). Use {@link cuid2} instead.
		* See https://github.com/paralleldrive/cuid.
		*/
		const cuid = /^[cC][0-9a-z]{6,}$/;
		const cuid2 = /^[0-9a-z]+$/;
		const ulid = /^[0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{26}$/;
		const xid = /^[0-9a-vA-V]{20}$/;
		const ksuid = /^[A-Za-z0-9]{27}$/;
		const nanoid = /^[a-zA-Z0-9_-]{21}$/;
		/** ISO 8601-1 duration regex. Does not support the 8601-2 extensions like negative durations or fractional/negative components. */
		const duration$1 = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/;
		/** A regex for any UUID-like identifier: 8-4-4-4-12 hex pattern */
		const guid = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/;
		/** Returns a regex for validating an RFC 9562/4122 UUID.
		*
		* @param version Optionally specify a version 1-8. If no version is specified, all versions are supported. */
		const uuid = (version) => {
			if (!version) return /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/;
			return new RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${version}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`);
		};
		/** Practical email validation */
		const email = /^(?!\.)(?!.*\.\.)([A-Za-z0-9_'+\-\.]*)[A-Za-z0-9_+-]@([A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/;
		const _emoji$1 = `^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$`;
		function emoji() {
			return new RegExp(_emoji$1, "u");
		}
		const ipv4 = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
		const ipv6 = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/;
		const cidrv4 = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/;
		const cidrv6 = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|::|([0-9a-fA-F]{1,4})?::([0-9a-fA-F]{1,4}:?){0,6})\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/;
		const base64 = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/;
		const base64url = /^[A-Za-z0-9_-]*$/;
		const httpProtocol = /^https?$/;
		const e164 = /^\+[1-9]\d{6,14}$/;
		const dateSource = `(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))`;
		const date$1 = /*@__PURE__*/ new RegExp(`^${dateSource}$`);
		function timeSource(args) {
			const hhmm = `(?:[01]\\d|2[0-3]):[0-5]\\d`;
			return typeof args.precision === "number" ? args.precision === -1 ? `${hhmm}` : args.precision === 0 ? `${hhmm}:[0-5]\\d` : `${hhmm}:[0-5]\\d\\.\\d{${args.precision}}` : `${hhmm}(?::[0-5]\\d(?:\\.\\d+)?)?`;
		}
		function time$1(args) {
			return new RegExp(`^${timeSource(args)}$`);
		}
		function datetime$1(args) {
			const time = timeSource({ precision: args.precision });
			const opts = ["Z"];
			if (args.local) opts.push("");
			if (args.offset) opts.push(`([+-](?:[01]\\d|2[0-3]):[0-5]\\d)`);
			const timeRegex = `${time}(?:${opts.join("|")})`;
			return new RegExp(`^${dateSource}T(?:${timeRegex})$`);
		}
		const string$1 = (params) => {
			const regex = params ? `[\\s\\S]{${params?.minimum ?? 0},${params?.maximum ?? ""}}` : `[\\s\\S]*`;
			return new RegExp(`^${regex}$`);
		};
		const integer = /^-?\d+$/;
		const number$1 = /^-?\d+(?:\.\d+)?$/;
		const boolean$1 = /^(?:true|false)$/i;
		const _undefined$2 = /^undefined$/i;
		const lowercase = /^[^A-Z]*$/;
		const uppercase = /^[^a-z]*$/;
		//#endregion
		//#region ../../../node_modules/.pnpm/zod@4.4.3/node_modules/zod/v4/core/checks.js
		const $ZodCheck = /*@__PURE__*/ $constructor("$ZodCheck", (inst, def) => {
			var _a;
			inst._zod ?? (inst._zod = {});
			inst._zod.def = def;
			(_a = inst._zod).onattach ?? (_a.onattach = []);
		});
		const numericOriginMap = {
			number: "number",
			bigint: "bigint",
			object: "date"
		};
		const $ZodCheckLessThan = /*@__PURE__*/ $constructor("$ZodCheckLessThan", (inst, def) => {
			$ZodCheck.init(inst, def);
			const origin = numericOriginMap[typeof def.value];
			inst._zod.onattach.push((inst) => {
				const bag = inst._zod.bag;
				const curr = (def.inclusive ? bag.maximum : bag.exclusiveMaximum) ?? Number.POSITIVE_INFINITY;
				if (def.value < curr) if (def.inclusive) bag.maximum = def.value;
				else bag.exclusiveMaximum = def.value;
			});
			inst._zod.check = (payload) => {
				if (def.inclusive ? payload.value <= def.value : payload.value < def.value) return;
				payload.issues.push({
					origin,
					code: "too_big",
					maximum: typeof def.value === "object" ? def.value.getTime() : def.value,
					input: payload.value,
					inclusive: def.inclusive,
					inst,
					continue: !def.abort
				});
			};
		});
		const $ZodCheckGreaterThan = /*@__PURE__*/ $constructor("$ZodCheckGreaterThan", (inst, def) => {
			$ZodCheck.init(inst, def);
			const origin = numericOriginMap[typeof def.value];
			inst._zod.onattach.push((inst) => {
				const bag = inst._zod.bag;
				const curr = (def.inclusive ? bag.minimum : bag.exclusiveMinimum) ?? Number.NEGATIVE_INFINITY;
				if (def.value > curr) if (def.inclusive) bag.minimum = def.value;
				else bag.exclusiveMinimum = def.value;
			});
			inst._zod.check = (payload) => {
				if (def.inclusive ? payload.value >= def.value : payload.value > def.value) return;
				payload.issues.push({
					origin,
					code: "too_small",
					minimum: typeof def.value === "object" ? def.value.getTime() : def.value,
					input: payload.value,
					inclusive: def.inclusive,
					inst,
					continue: !def.abort
				});
			};
		});
		const $ZodCheckMultipleOf = /*@__PURE__*/ $constructor("$ZodCheckMultipleOf", (inst, def) => {
			$ZodCheck.init(inst, def);
			inst._zod.onattach.push((inst) => {
				var _a;
				(_a = inst._zod.bag).multipleOf ?? (_a.multipleOf = def.value);
			});
			inst._zod.check = (payload) => {
				if (typeof payload.value !== typeof def.value) throw new Error("Cannot mix number and bigint in multiple_of check.");
				if (typeof payload.value === "bigint" ? payload.value % def.value === BigInt(0) : floatSafeRemainder(payload.value, def.value) === 0) return;
				payload.issues.push({
					origin: typeof payload.value,
					code: "not_multiple_of",
					divisor: def.value,
					input: payload.value,
					inst,
					continue: !def.abort
				});
			};
		});
		const $ZodCheckNumberFormat = /*@__PURE__*/ $constructor("$ZodCheckNumberFormat", (inst, def) => {
			$ZodCheck.init(inst, def);
			def.format = def.format || "float64";
			const isInt = def.format?.includes("int");
			const origin = isInt ? "int" : "number";
			const [minimum, maximum] = NUMBER_FORMAT_RANGES[def.format];
			inst._zod.onattach.push((inst) => {
				const bag = inst._zod.bag;
				bag.format = def.format;
				bag.minimum = minimum;
				bag.maximum = maximum;
				if (isInt) bag.pattern = integer;
			});
			inst._zod.check = (payload) => {
				const input = payload.value;
				if (isInt) {
					if (!Number.isInteger(input)) {
						payload.issues.push({
							expected: origin,
							format: def.format,
							code: "invalid_type",
							continue: false,
							input,
							inst
						});
						return;
					}
					if (!Number.isSafeInteger(input)) {
						if (input > 0) payload.issues.push({
							input,
							code: "too_big",
							maximum: Number.MAX_SAFE_INTEGER,
							note: "Integers must be within the safe integer range.",
							inst,
							origin,
							inclusive: true,
							continue: !def.abort
						});
						else payload.issues.push({
							input,
							code: "too_small",
							minimum: Number.MIN_SAFE_INTEGER,
							note: "Integers must be within the safe integer range.",
							inst,
							origin,
							inclusive: true,
							continue: !def.abort
						});
						return;
					}
				}
				if (input < minimum) payload.issues.push({
					origin: "number",
					input,
					code: "too_small",
					minimum,
					inclusive: true,
					inst,
					continue: !def.abort
				});
				if (input > maximum) payload.issues.push({
					origin: "number",
					input,
					code: "too_big",
					maximum,
					inclusive: true,
					inst,
					continue: !def.abort
				});
			};
		});
		const $ZodCheckMaxLength = /*@__PURE__*/ $constructor("$ZodCheckMaxLength", (inst, def) => {
			var _a;
			$ZodCheck.init(inst, def);
			(_a = inst._zod.def).when ?? (_a.when = (payload) => {
				const val = payload.value;
				return !nullish(val) && val.length !== void 0;
			});
			inst._zod.onattach.push((inst) => {
				const curr = inst._zod.bag.maximum ?? Number.POSITIVE_INFINITY;
				if (def.maximum < curr) inst._zod.bag.maximum = def.maximum;
			});
			inst._zod.check = (payload) => {
				const input = payload.value;
				if (input.length <= def.maximum) return;
				const origin = getLengthableOrigin(input);
				payload.issues.push({
					origin,
					code: "too_big",
					maximum: def.maximum,
					inclusive: true,
					input,
					inst,
					continue: !def.abort
				});
			};
		});
		const $ZodCheckMinLength = /*@__PURE__*/ $constructor("$ZodCheckMinLength", (inst, def) => {
			var _a;
			$ZodCheck.init(inst, def);
			(_a = inst._zod.def).when ?? (_a.when = (payload) => {
				const val = payload.value;
				return !nullish(val) && val.length !== void 0;
			});
			inst._zod.onattach.push((inst) => {
				const curr = inst._zod.bag.minimum ?? Number.NEGATIVE_INFINITY;
				if (def.minimum > curr) inst._zod.bag.minimum = def.minimum;
			});
			inst._zod.check = (payload) => {
				const input = payload.value;
				if (input.length >= def.minimum) return;
				const origin = getLengthableOrigin(input);
				payload.issues.push({
					origin,
					code: "too_small",
					minimum: def.minimum,
					inclusive: true,
					input,
					inst,
					continue: !def.abort
				});
			};
		});
		const $ZodCheckLengthEquals = /*@__PURE__*/ $constructor("$ZodCheckLengthEquals", (inst, def) => {
			var _a;
			$ZodCheck.init(inst, def);
			(_a = inst._zod.def).when ?? (_a.when = (payload) => {
				const val = payload.value;
				return !nullish(val) && val.length !== void 0;
			});
			inst._zod.onattach.push((inst) => {
				const bag = inst._zod.bag;
				bag.minimum = def.length;
				bag.maximum = def.length;
				bag.length = def.length;
			});
			inst._zod.check = (payload) => {
				const input = payload.value;
				const length = input.length;
				if (length === def.length) return;
				const origin = getLengthableOrigin(input);
				const tooBig = length > def.length;
				payload.issues.push({
					origin,
					...tooBig ? {
						code: "too_big",
						maximum: def.length
					} : {
						code: "too_small",
						minimum: def.length
					},
					inclusive: true,
					exact: true,
					input: payload.value,
					inst,
					continue: !def.abort
				});
			};
		});
		const $ZodCheckStringFormat = /*@__PURE__*/ $constructor("$ZodCheckStringFormat", (inst, def) => {
			var _a, _b;
			$ZodCheck.init(inst, def);
			inst._zod.onattach.push((inst) => {
				const bag = inst._zod.bag;
				bag.format = def.format;
				if (def.pattern) {
					bag.patterns ?? (bag.patterns = /* @__PURE__ */ new Set());
					bag.patterns.add(def.pattern);
				}
			});
			if (def.pattern) (_a = inst._zod).check ?? (_a.check = (payload) => {
				def.pattern.lastIndex = 0;
				if (def.pattern.test(payload.value)) return;
				payload.issues.push({
					origin: "string",
					code: "invalid_format",
					format: def.format,
					input: payload.value,
					...def.pattern ? { pattern: def.pattern.toString() } : {},
					inst,
					continue: !def.abort
				});
			});
			else (_b = inst._zod).check ?? (_b.check = () => {});
		});
		const $ZodCheckRegex = /*@__PURE__*/ $constructor("$ZodCheckRegex", (inst, def) => {
			$ZodCheckStringFormat.init(inst, def);
			inst._zod.check = (payload) => {
				def.pattern.lastIndex = 0;
				if (def.pattern.test(payload.value)) return;
				payload.issues.push({
					origin: "string",
					code: "invalid_format",
					format: "regex",
					input: payload.value,
					pattern: def.pattern.toString(),
					inst,
					continue: !def.abort
				});
			};
		});
		const $ZodCheckLowerCase = /*@__PURE__*/ $constructor("$ZodCheckLowerCase", (inst, def) => {
			def.pattern ?? (def.pattern = lowercase);
			$ZodCheckStringFormat.init(inst, def);
		});
		const $ZodCheckUpperCase = /*@__PURE__*/ $constructor("$ZodCheckUpperCase", (inst, def) => {
			def.pattern ?? (def.pattern = uppercase);
			$ZodCheckStringFormat.init(inst, def);
		});
		const $ZodCheckIncludes = /*@__PURE__*/ $constructor("$ZodCheckIncludes", (inst, def) => {
			$ZodCheck.init(inst, def);
			const escapedRegex = escapeRegex(def.includes);
			const pattern = new RegExp(typeof def.position === "number" ? `^.{${def.position}}${escapedRegex}` : escapedRegex);
			def.pattern = pattern;
			inst._zod.onattach.push((inst) => {
				const bag = inst._zod.bag;
				bag.patterns ?? (bag.patterns = /* @__PURE__ */ new Set());
				bag.patterns.add(pattern);
			});
			inst._zod.check = (payload) => {
				if (payload.value.includes(def.includes, def.position)) return;
				payload.issues.push({
					origin: "string",
					code: "invalid_format",
					format: "includes",
					includes: def.includes,
					input: payload.value,
					inst,
					continue: !def.abort
				});
			};
		});
		const $ZodCheckStartsWith = /*@__PURE__*/ $constructor("$ZodCheckStartsWith", (inst, def) => {
			$ZodCheck.init(inst, def);
			const pattern = new RegExp(`^${escapeRegex(def.prefix)}.*`);
			def.pattern ?? (def.pattern = pattern);
			inst._zod.onattach.push((inst) => {
				const bag = inst._zod.bag;
				bag.patterns ?? (bag.patterns = /* @__PURE__ */ new Set());
				bag.patterns.add(pattern);
			});
			inst._zod.check = (payload) => {
				if (payload.value.startsWith(def.prefix)) return;
				payload.issues.push({
					origin: "string",
					code: "invalid_format",
					format: "starts_with",
					prefix: def.prefix,
					input: payload.value,
					inst,
					continue: !def.abort
				});
			};
		});
		const $ZodCheckEndsWith = /*@__PURE__*/ $constructor("$ZodCheckEndsWith", (inst, def) => {
			$ZodCheck.init(inst, def);
			const pattern = new RegExp(`.*${escapeRegex(def.suffix)}$`);
			def.pattern ?? (def.pattern = pattern);
			inst._zod.onattach.push((inst) => {
				const bag = inst._zod.bag;
				bag.patterns ?? (bag.patterns = /* @__PURE__ */ new Set());
				bag.patterns.add(pattern);
			});
			inst._zod.check = (payload) => {
				if (payload.value.endsWith(def.suffix)) return;
				payload.issues.push({
					origin: "string",
					code: "invalid_format",
					format: "ends_with",
					suffix: def.suffix,
					input: payload.value,
					inst,
					continue: !def.abort
				});
			};
		});
		const $ZodCheckOverwrite = /*@__PURE__*/ $constructor("$ZodCheckOverwrite", (inst, def) => {
			$ZodCheck.init(inst, def);
			inst._zod.check = (payload) => {
				payload.value = def.tx(payload.value);
			};
		});
		//#endregion
		//#region ../../../node_modules/.pnpm/zod@4.4.3/node_modules/zod/v4/core/doc.js
		var Doc = class {
			constructor(args = []) {
				this.content = [];
				this.indent = 0;
				if (this) this.args = args;
			}
			indented(fn) {
				this.indent += 1;
				fn(this);
				this.indent -= 1;
			}
			write(arg) {
				if (typeof arg === "function") {
					arg(this, { execution: "sync" });
					arg(this, { execution: "async" });
					return;
				}
				const lines = arg.split("\n").filter((x) => x);
				const minIndent = Math.min(...lines.map((x) => x.length - x.trimStart().length));
				const dedented = lines.map((x) => x.slice(minIndent)).map((x) => " ".repeat(this.indent * 2) + x);
				for (const line of dedented) this.content.push(line);
			}
			compile() {
				const F = Function;
				const args = this?.args;
				const lines = [...(this?.content ?? [``]).map((x) => `  ${x}`)];
				return new F(...args, lines.join("\n"));
			}
		};
		//#endregion
		//#region ../../../node_modules/.pnpm/zod@4.4.3/node_modules/zod/v4/core/versions.js
		const version = {
			major: 4,
			minor: 4,
			patch: 3
		};
		//#endregion
		//#region ../../../node_modules/.pnpm/zod@4.4.3/node_modules/zod/v4/core/schemas.js
		const $ZodType = /*@__PURE__*/ $constructor("$ZodType", (inst, def) => {
			var _a;
			inst ?? (inst = {});
			inst._zod.def = def;
			inst._zod.bag = inst._zod.bag || {};
			inst._zod.version = version;
			const checks = [...inst._zod.def.checks ?? []];
			if (inst._zod.traits.has("$ZodCheck")) checks.unshift(inst);
			for (const ch of checks) for (const fn of ch._zod.onattach) fn(inst);
			if (checks.length === 0) {
				(_a = inst._zod).deferred ?? (_a.deferred = []);
				inst._zod.deferred?.push(() => {
					inst._zod.run = inst._zod.parse;
				});
			} else {
				const runChecks = (payload, checks, ctx) => {
					let isAborted = aborted(payload);
					let asyncResult;
					for (const ch of checks) {
						if (ch._zod.def.when) {
							if (explicitlyAborted(payload)) continue;
							if (!ch._zod.def.when(payload)) continue;
						} else if (isAborted) continue;
						const currLen = payload.issues.length;
						const _ = ch._zod.check(payload);
						if (_ instanceof Promise && ctx?.async === false) throw new $ZodAsyncError();
						if (asyncResult || _ instanceof Promise) asyncResult = (asyncResult ?? Promise.resolve()).then(async () => {
							await _;
							if (payload.issues.length === currLen) return;
							if (!isAborted) isAborted = aborted(payload, currLen);
						});
						else {
							if (payload.issues.length === currLen) continue;
							if (!isAborted) isAborted = aborted(payload, currLen);
						}
					}
					if (asyncResult) return asyncResult.then(() => {
						return payload;
					});
					return payload;
				};
				const handleCanaryResult = (canary, payload, ctx) => {
					if (aborted(canary)) {
						canary.aborted = true;
						return canary;
					}
					const checkResult = runChecks(payload, checks, ctx);
					if (checkResult instanceof Promise) {
						if (ctx.async === false) throw new $ZodAsyncError();
						return checkResult.then((checkResult) => inst._zod.parse(checkResult, ctx));
					}
					return inst._zod.parse(checkResult, ctx);
				};
				inst._zod.run = (payload, ctx) => {
					if (ctx.skipChecks) return inst._zod.parse(payload, ctx);
					if (ctx.direction === "backward") {
						const canary = inst._zod.parse({
							value: payload.value,
							issues: []
						}, {
							...ctx,
							skipChecks: true
						});
						if (canary instanceof Promise) return canary.then((canary) => {
							return handleCanaryResult(canary, payload, ctx);
						});
						return handleCanaryResult(canary, payload, ctx);
					}
					const result = inst._zod.parse(payload, ctx);
					if (result instanceof Promise) {
						if (ctx.async === false) throw new $ZodAsyncError();
						return result.then((result) => runChecks(result, checks, ctx));
					}
					return runChecks(result, checks, ctx);
				};
			}
			defineLazy(inst, "~standard", () => ({
				validate: (value) => {
					try {
						const r = safeParse$1(inst, value);
						return r.success ? { value: r.data } : { issues: r.error?.issues };
					} catch (_) {
						return safeParseAsync$1(inst, value).then((r) => r.success ? { value: r.data } : { issues: r.error?.issues });
					}
				},
				vendor: "zod",
				version: 1
			}));
		});
		const $ZodString = /*@__PURE__*/ $constructor("$ZodString", (inst, def) => {
			$ZodType.init(inst, def);
			inst._zod.pattern = [...inst?._zod.bag?.patterns ?? []].pop() ?? string$1(inst._zod.bag);
			inst._zod.parse = (payload, _) => {
				if (def.coerce) try {
					payload.value = String(payload.value);
				} catch (_) {}
				if (typeof payload.value === "string") return payload;
				payload.issues.push({
					expected: "string",
					code: "invalid_type",
					input: payload.value,
					inst
				});
				return payload;
			};
		});
		const $ZodStringFormat = /*@__PURE__*/ $constructor("$ZodStringFormat", (inst, def) => {
			$ZodCheckStringFormat.init(inst, def);
			$ZodString.init(inst, def);
		});
		const $ZodGUID = /*@__PURE__*/ $constructor("$ZodGUID", (inst, def) => {
			def.pattern ?? (def.pattern = guid);
			$ZodStringFormat.init(inst, def);
		});
		const $ZodUUID = /*@__PURE__*/ $constructor("$ZodUUID", (inst, def) => {
			if (def.version) {
				const v = {
					v1: 1,
					v2: 2,
					v3: 3,
					v4: 4,
					v5: 5,
					v6: 6,
					v7: 7,
					v8: 8
				}[def.version];
				if (v === void 0) throw new Error(`Invalid UUID version: "${def.version}"`);
				def.pattern ?? (def.pattern = uuid(v));
			} else def.pattern ?? (def.pattern = uuid());
			$ZodStringFormat.init(inst, def);
		});
		const $ZodEmail = /*@__PURE__*/ $constructor("$ZodEmail", (inst, def) => {
			def.pattern ?? (def.pattern = email);
			$ZodStringFormat.init(inst, def);
		});
		const $ZodURL = /*@__PURE__*/ $constructor("$ZodURL", (inst, def) => {
			$ZodStringFormat.init(inst, def);
			inst._zod.check = (payload) => {
				try {
					const trimmed = payload.value.trim();
					if (!def.normalize && def.protocol?.source === httpProtocol.source) {
						if (!/^https?:\/\//i.test(trimmed)) {
							payload.issues.push({
								code: "invalid_format",
								format: "url",
								note: "Invalid URL format",
								input: payload.value,
								inst,
								continue: !def.abort
							});
							return;
						}
					}
					const url = new URL(trimmed);
					if (def.hostname) {
						def.hostname.lastIndex = 0;
						if (!def.hostname.test(url.hostname)) payload.issues.push({
							code: "invalid_format",
							format: "url",
							note: "Invalid hostname",
							pattern: def.hostname.source,
							input: payload.value,
							inst,
							continue: !def.abort
						});
					}
					if (def.protocol) {
						def.protocol.lastIndex = 0;
						if (!def.protocol.test(url.protocol.endsWith(":") ? url.protocol.slice(0, -1) : url.protocol)) payload.issues.push({
							code: "invalid_format",
							format: "url",
							note: "Invalid protocol",
							pattern: def.protocol.source,
							input: payload.value,
							inst,
							continue: !def.abort
						});
					}
					if (def.normalize) payload.value = url.href;
					else payload.value = trimmed;
					return;
				} catch (_) {
					payload.issues.push({
						code: "invalid_format",
						format: "url",
						input: payload.value,
						inst,
						continue: !def.abort
					});
				}
			};
		});
		const $ZodEmoji = /*@__PURE__*/ $constructor("$ZodEmoji", (inst, def) => {
			def.pattern ?? (def.pattern = emoji());
			$ZodStringFormat.init(inst, def);
		});
		const $ZodNanoID = /*@__PURE__*/ $constructor("$ZodNanoID", (inst, def) => {
			def.pattern ?? (def.pattern = nanoid);
			$ZodStringFormat.init(inst, def);
		});
		/**
		* @deprecated CUID v1 is deprecated by its authors due to information leakage
		* (timestamps embedded in the id). Use {@link $ZodCUID2} instead.
		* See https://github.com/paralleldrive/cuid.
		*/
		const $ZodCUID = /*@__PURE__*/ $constructor("$ZodCUID", (inst, def) => {
			def.pattern ?? (def.pattern = cuid);
			$ZodStringFormat.init(inst, def);
		});
		const $ZodCUID2 = /*@__PURE__*/ $constructor("$ZodCUID2", (inst, def) => {
			def.pattern ?? (def.pattern = cuid2);
			$ZodStringFormat.init(inst, def);
		});
		const $ZodULID = /*@__PURE__*/ $constructor("$ZodULID", (inst, def) => {
			def.pattern ?? (def.pattern = ulid);
			$ZodStringFormat.init(inst, def);
		});
		const $ZodXID = /*@__PURE__*/ $constructor("$ZodXID", (inst, def) => {
			def.pattern ?? (def.pattern = xid);
			$ZodStringFormat.init(inst, def);
		});
		const $ZodKSUID = /*@__PURE__*/ $constructor("$ZodKSUID", (inst, def) => {
			def.pattern ?? (def.pattern = ksuid);
			$ZodStringFormat.init(inst, def);
		});
		const $ZodISODateTime = /*@__PURE__*/ $constructor("$ZodISODateTime", (inst, def) => {
			def.pattern ?? (def.pattern = datetime$1(def));
			$ZodStringFormat.init(inst, def);
		});
		const $ZodISODate = /*@__PURE__*/ $constructor("$ZodISODate", (inst, def) => {
			def.pattern ?? (def.pattern = date$1);
			$ZodStringFormat.init(inst, def);
		});
		const $ZodISOTime = /*@__PURE__*/ $constructor("$ZodISOTime", (inst, def) => {
			def.pattern ?? (def.pattern = time$1(def));
			$ZodStringFormat.init(inst, def);
		});
		const $ZodISODuration = /*@__PURE__*/ $constructor("$ZodISODuration", (inst, def) => {
			def.pattern ?? (def.pattern = duration$1);
			$ZodStringFormat.init(inst, def);
		});
		const $ZodIPv4 = /*@__PURE__*/ $constructor("$ZodIPv4", (inst, def) => {
			def.pattern ?? (def.pattern = ipv4);
			$ZodStringFormat.init(inst, def);
			inst._zod.bag.format = `ipv4`;
		});
		const $ZodIPv6 = /*@__PURE__*/ $constructor("$ZodIPv6", (inst, def) => {
			def.pattern ?? (def.pattern = ipv6);
			$ZodStringFormat.init(inst, def);
			inst._zod.bag.format = `ipv6`;
			inst._zod.check = (payload) => {
				try {
					new URL(`http://[${payload.value}]`);
				} catch {
					payload.issues.push({
						code: "invalid_format",
						format: "ipv6",
						input: payload.value,
						inst,
						continue: !def.abort
					});
				}
			};
		});
		const $ZodCIDRv4 = /*@__PURE__*/ $constructor("$ZodCIDRv4", (inst, def) => {
			def.pattern ?? (def.pattern = cidrv4);
			$ZodStringFormat.init(inst, def);
		});
		const $ZodCIDRv6 = /*@__PURE__*/ $constructor("$ZodCIDRv6", (inst, def) => {
			def.pattern ?? (def.pattern = cidrv6);
			$ZodStringFormat.init(inst, def);
			inst._zod.check = (payload) => {
				const parts = payload.value.split("/");
				try {
					if (parts.length !== 2) throw new Error();
					const [address, prefix] = parts;
					if (!prefix) throw new Error();
					const prefixNum = Number(prefix);
					if (`${prefixNum}` !== prefix) throw new Error();
					if (prefixNum < 0 || prefixNum > 128) throw new Error();
					new URL(`http://[${address}]`);
				} catch {
					payload.issues.push({
						code: "invalid_format",
						format: "cidrv6",
						input: payload.value,
						inst,
						continue: !def.abort
					});
				}
			};
		});
		function isValidBase64(data) {
			if (data === "") return true;
			if (/\s/.test(data)) return false;
			if (data.length % 4 !== 0) return false;
			try {
				atob(data);
				return true;
			} catch {
				return false;
			}
		}
		const $ZodBase64 = /*@__PURE__*/ $constructor("$ZodBase64", (inst, def) => {
			def.pattern ?? (def.pattern = base64);
			$ZodStringFormat.init(inst, def);
			inst._zod.bag.contentEncoding = "base64";
			inst._zod.check = (payload) => {
				if (isValidBase64(payload.value)) return;
				payload.issues.push({
					code: "invalid_format",
					format: "base64",
					input: payload.value,
					inst,
					continue: !def.abort
				});
			};
		});
		function isValidBase64URL(data) {
			if (!base64url.test(data)) return false;
			const base64 = data.replace(/[-_]/g, (c) => c === "-" ? "+" : "/");
			return isValidBase64(base64.padEnd(Math.ceil(base64.length / 4) * 4, "="));
		}
		const $ZodBase64URL = /*@__PURE__*/ $constructor("$ZodBase64URL", (inst, def) => {
			def.pattern ?? (def.pattern = base64url);
			$ZodStringFormat.init(inst, def);
			inst._zod.bag.contentEncoding = "base64url";
			inst._zod.check = (payload) => {
				if (isValidBase64URL(payload.value)) return;
				payload.issues.push({
					code: "invalid_format",
					format: "base64url",
					input: payload.value,
					inst,
					continue: !def.abort
				});
			};
		});
		const $ZodE164 = /*@__PURE__*/ $constructor("$ZodE164", (inst, def) => {
			def.pattern ?? (def.pattern = e164);
			$ZodStringFormat.init(inst, def);
		});
		function isValidJWT(token, algorithm = null) {
			try {
				const tokensParts = token.split(".");
				if (tokensParts.length !== 3) return false;
				const [header] = tokensParts;
				if (!header) return false;
				const parsedHeader = JSON.parse(atob(header));
				if ("typ" in parsedHeader && parsedHeader?.typ !== "JWT") return false;
				if (!parsedHeader.alg) return false;
				if (algorithm && (!("alg" in parsedHeader) || parsedHeader.alg !== algorithm)) return false;
				return true;
			} catch {
				return false;
			}
		}
		const $ZodJWT = /*@__PURE__*/ $constructor("$ZodJWT", (inst, def) => {
			$ZodStringFormat.init(inst, def);
			inst._zod.check = (payload) => {
				if (isValidJWT(payload.value, def.alg)) return;
				payload.issues.push({
					code: "invalid_format",
					format: "jwt",
					input: payload.value,
					inst,
					continue: !def.abort
				});
			};
		});
		const $ZodNumber = /*@__PURE__*/ $constructor("$ZodNumber", (inst, def) => {
			$ZodType.init(inst, def);
			inst._zod.pattern = inst._zod.bag.pattern ?? number$1;
			inst._zod.parse = (payload, _ctx) => {
				if (def.coerce) try {
					payload.value = Number(payload.value);
				} catch (_) {}
				const input = payload.value;
				if (typeof input === "number" && !Number.isNaN(input) && Number.isFinite(input)) return payload;
				const received = typeof input === "number" ? Number.isNaN(input) ? "NaN" : !Number.isFinite(input) ? "Infinity" : void 0 : void 0;
				payload.issues.push({
					expected: "number",
					code: "invalid_type",
					input,
					inst,
					...received ? { received } : {}
				});
				return payload;
			};
		});
		const $ZodNumberFormat = /*@__PURE__*/ $constructor("$ZodNumberFormat", (inst, def) => {
			$ZodCheckNumberFormat.init(inst, def);
			$ZodNumber.init(inst, def);
		});
		const $ZodBoolean = /*@__PURE__*/ $constructor("$ZodBoolean", (inst, def) => {
			$ZodType.init(inst, def);
			inst._zod.pattern = boolean$1;
			inst._zod.parse = (payload, _ctx) => {
				if (def.coerce) try {
					payload.value = Boolean(payload.value);
				} catch (_) {}
				const input = payload.value;
				if (typeof input === "boolean") return payload;
				payload.issues.push({
					expected: "boolean",
					code: "invalid_type",
					input,
					inst
				});
				return payload;
			};
		});
		const $ZodUndefined = /*@__PURE__*/ $constructor("$ZodUndefined", (inst, def) => {
			$ZodType.init(inst, def);
			inst._zod.pattern = _undefined$2;
			inst._zod.values = new Set([void 0]);
			inst._zod.parse = (payload, _ctx) => {
				const input = payload.value;
				if (typeof input === "undefined") return payload;
				payload.issues.push({
					expected: "undefined",
					code: "invalid_type",
					input,
					inst
				});
				return payload;
			};
		});
		const $ZodUnknown = /*@__PURE__*/ $constructor("$ZodUnknown", (inst, def) => {
			$ZodType.init(inst, def);
			inst._zod.parse = (payload) => payload;
		});
		const $ZodNever = /*@__PURE__*/ $constructor("$ZodNever", (inst, def) => {
			$ZodType.init(inst, def);
			inst._zod.parse = (payload, _ctx) => {
				payload.issues.push({
					expected: "never",
					code: "invalid_type",
					input: payload.value,
					inst
				});
				return payload;
			};
		});
		const $ZodVoid = /*@__PURE__*/ $constructor("$ZodVoid", (inst, def) => {
			$ZodType.init(inst, def);
			inst._zod.parse = (payload, _ctx) => {
				const input = payload.value;
				if (typeof input === "undefined") return payload;
				payload.issues.push({
					expected: "void",
					code: "invalid_type",
					input,
					inst
				});
				return payload;
			};
		});
		function handleArrayResult(result, final, index) {
			if (result.issues.length) final.issues.push(...prefixIssues(index, result.issues));
			final.value[index] = result.value;
		}
		const $ZodArray = /*@__PURE__*/ $constructor("$ZodArray", (inst, def) => {
			$ZodType.init(inst, def);
			inst._zod.parse = (payload, ctx) => {
				const input = payload.value;
				if (!Array.isArray(input)) {
					payload.issues.push({
						expected: "array",
						code: "invalid_type",
						input,
						inst
					});
					return payload;
				}
				payload.value = Array(input.length);
				const proms = [];
				for (let i = 0; i < input.length; i++) {
					const item = input[i];
					const result = def.element._zod.run({
						value: item,
						issues: []
					}, ctx);
					if (result instanceof Promise) proms.push(result.then((result) => handleArrayResult(result, payload, i)));
					else handleArrayResult(result, payload, i);
				}
				if (proms.length) return Promise.all(proms).then(() => payload);
				return payload;
			};
		});
		function handlePropertyResult(result, final, key, input, isOptionalIn, isOptionalOut) {
			const isPresent = key in input;
			if (result.issues.length) {
				if (isOptionalIn && isOptionalOut && !isPresent) return;
				final.issues.push(...prefixIssues(key, result.issues));
			}
			if (!isPresent && !isOptionalIn) {
				if (!result.issues.length) final.issues.push({
					code: "invalid_type",
					expected: "nonoptional",
					input: void 0,
					path: [key]
				});
				return;
			}
			if (result.value === void 0) {
				if (isPresent) final.value[key] = void 0;
			} else final.value[key] = result.value;
		}
		function normalizeDef(def) {
			const keys = Object.keys(def.shape);
			for (const k of keys) if (!def.shape?.[k]?._zod?.traits?.has("$ZodType")) throw new Error(`Invalid element at key "${k}": expected a Zod schema`);
			const okeys = optionalKeys(def.shape);
			return {
				...def,
				keys,
				keySet: new Set(keys),
				numKeys: keys.length,
				optionalKeys: new Set(okeys)
			};
		}
		function handleCatchall(proms, input, payload, ctx, def, inst) {
			const unrecognized = [];
			const keySet = def.keySet;
			const _catchall = def.catchall._zod;
			const t = _catchall.def.type;
			const isOptionalIn = _catchall.optin === "optional";
			const isOptionalOut = _catchall.optout === "optional";
			for (const key in input) {
				if (key === "__proto__") continue;
				if (keySet.has(key)) continue;
				if (t === "never") {
					unrecognized.push(key);
					continue;
				}
				const r = _catchall.run({
					value: input[key],
					issues: []
				}, ctx);
				if (r instanceof Promise) proms.push(r.then((r) => handlePropertyResult(r, payload, key, input, isOptionalIn, isOptionalOut)));
				else handlePropertyResult(r, payload, key, input, isOptionalIn, isOptionalOut);
			}
			if (unrecognized.length) payload.issues.push({
				code: "unrecognized_keys",
				keys: unrecognized,
				input,
				inst
			});
			if (!proms.length) return payload;
			return Promise.all(proms).then(() => {
				return payload;
			});
		}
		const $ZodObject = /*@__PURE__*/ $constructor("$ZodObject", (inst, def) => {
			$ZodType.init(inst, def);
			if (!Object.getOwnPropertyDescriptor(def, "shape")?.get) {
				const sh = def.shape;
				Object.defineProperty(def, "shape", { get: () => {
					const newSh = { ...sh };
					Object.defineProperty(def, "shape", { value: newSh });
					return newSh;
				} });
			}
			const _normalized = cached(() => normalizeDef(def));
			defineLazy(inst._zod, "propValues", () => {
				const shape = def.shape;
				const propValues = {};
				for (const key in shape) {
					const field = shape[key]._zod;
					if (field.values) {
						propValues[key] ?? (propValues[key] = /* @__PURE__ */ new Set());
						for (const v of field.values) propValues[key].add(v);
					}
				}
				return propValues;
			});
			const isObject$1 = isObject;
			const catchall = def.catchall;
			let value;
			inst._zod.parse = (payload, ctx) => {
				value ?? (value = _normalized.value);
				const input = payload.value;
				if (!isObject$1(input)) {
					payload.issues.push({
						expected: "object",
						code: "invalid_type",
						input,
						inst
					});
					return payload;
				}
				payload.value = {};
				const proms = [];
				const shape = value.shape;
				for (const key of value.keys) {
					const el = shape[key];
					const isOptionalIn = el._zod.optin === "optional";
					const isOptionalOut = el._zod.optout === "optional";
					const r = el._zod.run({
						value: input[key],
						issues: []
					}, ctx);
					if (r instanceof Promise) proms.push(r.then((r) => handlePropertyResult(r, payload, key, input, isOptionalIn, isOptionalOut)));
					else handlePropertyResult(r, payload, key, input, isOptionalIn, isOptionalOut);
				}
				if (!catchall) return proms.length ? Promise.all(proms).then(() => payload) : payload;
				return handleCatchall(proms, input, payload, ctx, _normalized.value, inst);
			};
		});
		const $ZodObjectJIT = /*@__PURE__*/ $constructor("$ZodObjectJIT", (inst, def) => {
			$ZodObject.init(inst, def);
			const superParse = inst._zod.parse;
			const _normalized = cached(() => normalizeDef(def));
			const generateFastpass = (shape) => {
				const doc = new Doc([
					"shape",
					"payload",
					"ctx"
				]);
				const normalized = _normalized.value;
				const parseStr = (key) => {
					const k = esc(key);
					return `shape[${k}]._zod.run({ value: input[${k}], issues: [] }, ctx)`;
				};
				doc.write(`const input = payload.value;`);
				const ids = Object.create(null);
				let counter = 0;
				for (const key of normalized.keys) ids[key] = `key_${counter++}`;
				doc.write(`const newResult = {};`);
				for (const key of normalized.keys) {
					const id = ids[key];
					const k = esc(key);
					const schema = shape[key];
					const isOptionalIn = schema?._zod?.optin === "optional";
					const isOptionalOut = schema?._zod?.optout === "optional";
					doc.write(`const ${id} = ${parseStr(key)};`);
					if (isOptionalIn && isOptionalOut) doc.write(`
        if (${id}.issues.length) {
          if (${k} in input) {
            payload.issues = payload.issues.concat(${id}.issues.map(iss => ({
              ...iss,
              path: iss.path ? [${k}, ...iss.path] : [${k}]
            })));
          }
        }
        
        if (${id}.value === undefined) {
          if (${k} in input) {
            newResult[${k}] = undefined;
          }
        } else {
          newResult[${k}] = ${id}.value;
        }
        
      `);
					else if (!isOptionalIn) doc.write(`
        const ${id}_present = ${k} in input;
        if (${id}.issues.length) {
          payload.issues = payload.issues.concat(${id}.issues.map(iss => ({
            ...iss,
            path: iss.path ? [${k}, ...iss.path] : [${k}]
          })));
        }
        if (!${id}_present && !${id}.issues.length) {
          payload.issues.push({
            code: "invalid_type",
            expected: "nonoptional",
            input: undefined,
            path: [${k}]
          });
        }

        if (${id}_present) {
          if (${id}.value === undefined) {
            newResult[${k}] = undefined;
          } else {
            newResult[${k}] = ${id}.value;
          }
        }

      `);
					else doc.write(`
        if (${id}.issues.length) {
          payload.issues = payload.issues.concat(${id}.issues.map(iss => ({
            ...iss,
            path: iss.path ? [${k}, ...iss.path] : [${k}]
          })));
        }
        
        if (${id}.value === undefined) {
          if (${k} in input) {
            newResult[${k}] = undefined;
          }
        } else {
          newResult[${k}] = ${id}.value;
        }
        
      `);
				}
				doc.write(`payload.value = newResult;`);
				doc.write(`return payload;`);
				const fn = doc.compile();
				return (payload, ctx) => fn(shape, payload, ctx);
			};
			let fastpass;
			const isObject$2 = isObject;
			const jit = !globalConfig.jitless;
			const fastEnabled = jit && allowsEval.value;
			const catchall = def.catchall;
			let value;
			inst._zod.parse = (payload, ctx) => {
				value ?? (value = _normalized.value);
				const input = payload.value;
				if (!isObject$2(input)) {
					payload.issues.push({
						expected: "object",
						code: "invalid_type",
						input,
						inst
					});
					return payload;
				}
				if (jit && fastEnabled && ctx?.async === false && ctx.jitless !== true) {
					if (!fastpass) fastpass = generateFastpass(def.shape);
					payload = fastpass(payload, ctx);
					if (!catchall) return payload;
					return handleCatchall([], input, payload, ctx, value, inst);
				}
				return superParse(payload, ctx);
			};
		});
		function handleUnionResults(results, final, inst, ctx) {
			for (const result of results) if (result.issues.length === 0) {
				final.value = result.value;
				return final;
			}
			const nonaborted = results.filter((r) => !aborted(r));
			if (nonaborted.length === 1) {
				final.value = nonaborted[0].value;
				return nonaborted[0];
			}
			final.issues.push({
				code: "invalid_union",
				input: final.value,
				inst,
				errors: results.map((result) => result.issues.map((iss) => finalizeIssue(iss, ctx, config())))
			});
			return final;
		}
		const $ZodUnion = /*@__PURE__*/ $constructor("$ZodUnion", (inst, def) => {
			$ZodType.init(inst, def);
			defineLazy(inst._zod, "optin", () => def.options.some((o) => o._zod.optin === "optional") ? "optional" : void 0);
			defineLazy(inst._zod, "optout", () => def.options.some((o) => o._zod.optout === "optional") ? "optional" : void 0);
			defineLazy(inst._zod, "values", () => {
				if (def.options.every((o) => o._zod.values)) return new Set(def.options.flatMap((option) => Array.from(option._zod.values)));
			});
			defineLazy(inst._zod, "pattern", () => {
				if (def.options.every((o) => o._zod.pattern)) {
					const patterns = def.options.map((o) => o._zod.pattern);
					return new RegExp(`^(${patterns.map((p) => cleanRegex(p.source)).join("|")})$`);
				}
			});
			const first = def.options.length === 1 ? def.options[0]._zod.run : null;
			inst._zod.parse = (payload, ctx) => {
				if (first) return first(payload, ctx);
				let async = false;
				const results = [];
				for (const option of def.options) {
					const result = option._zod.run({
						value: payload.value,
						issues: []
					}, ctx);
					if (result instanceof Promise) {
						results.push(result);
						async = true;
					} else {
						if (result.issues.length === 0) return result;
						results.push(result);
					}
				}
				if (!async) return handleUnionResults(results, payload, inst, ctx);
				return Promise.all(results).then((results) => {
					return handleUnionResults(results, payload, inst, ctx);
				});
			};
		});
		const $ZodIntersection = /*@__PURE__*/ $constructor("$ZodIntersection", (inst, def) => {
			$ZodType.init(inst, def);
			inst._zod.parse = (payload, ctx) => {
				const input = payload.value;
				const left = def.left._zod.run({
					value: input,
					issues: []
				}, ctx);
				const right = def.right._zod.run({
					value: input,
					issues: []
				}, ctx);
				if (left instanceof Promise || right instanceof Promise) return Promise.all([left, right]).then(([left, right]) => {
					return handleIntersectionResults(payload, left, right);
				});
				return handleIntersectionResults(payload, left, right);
			};
		});
		function mergeValues(a, b) {
			if (a === b) return {
				valid: true,
				data: a
			};
			if (a instanceof Date && b instanceof Date && +a === +b) return {
				valid: true,
				data: a
			};
			if (isPlainObject(a) && isPlainObject(b)) {
				const bKeys = Object.keys(b);
				const sharedKeys = Object.keys(a).filter((key) => bKeys.indexOf(key) !== -1);
				const newObj = {
					...a,
					...b
				};
				for (const key of sharedKeys) {
					const sharedValue = mergeValues(a[key], b[key]);
					if (!sharedValue.valid) return {
						valid: false,
						mergeErrorPath: [key, ...sharedValue.mergeErrorPath]
					};
					newObj[key] = sharedValue.data;
				}
				return {
					valid: true,
					data: newObj
				};
			}
			if (Array.isArray(a) && Array.isArray(b)) {
				if (a.length !== b.length) return {
					valid: false,
					mergeErrorPath: []
				};
				const newArray = [];
				for (let index = 0; index < a.length; index++) {
					const itemA = a[index];
					const itemB = b[index];
					const sharedValue = mergeValues(itemA, itemB);
					if (!sharedValue.valid) return {
						valid: false,
						mergeErrorPath: [index, ...sharedValue.mergeErrorPath]
					};
					newArray.push(sharedValue.data);
				}
				return {
					valid: true,
					data: newArray
				};
			}
			return {
				valid: false,
				mergeErrorPath: []
			};
		}
		function handleIntersectionResults(result, left, right) {
			const unrecKeys = /* @__PURE__ */ new Map();
			let unrecIssue;
			for (const iss of left.issues) if (iss.code === "unrecognized_keys") {
				unrecIssue ?? (unrecIssue = iss);
				for (const k of iss.keys) {
					if (!unrecKeys.has(k)) unrecKeys.set(k, {});
					unrecKeys.get(k).l = true;
				}
			} else result.issues.push(iss);
			for (const iss of right.issues) if (iss.code === "unrecognized_keys") for (const k of iss.keys) {
				if (!unrecKeys.has(k)) unrecKeys.set(k, {});
				unrecKeys.get(k).r = true;
			}
			else result.issues.push(iss);
			const bothKeys = [...unrecKeys].filter(([, f]) => f.l && f.r).map(([k]) => k);
			if (bothKeys.length && unrecIssue) result.issues.push({
				...unrecIssue,
				keys: bothKeys
			});
			if (aborted(result)) return result;
			const merged = mergeValues(left.value, right.value);
			if (!merged.valid) throw new Error(`Unmergable intersection. Error path: ${JSON.stringify(merged.mergeErrorPath)}`);
			result.value = merged.data;
			return result;
		}
		const $ZodRecord = /*@__PURE__*/ $constructor("$ZodRecord", (inst, def) => {
			$ZodType.init(inst, def);
			inst._zod.parse = (payload, ctx) => {
				const input = payload.value;
				if (!isPlainObject(input)) {
					payload.issues.push({
						expected: "record",
						code: "invalid_type",
						input,
						inst
					});
					return payload;
				}
				const proms = [];
				const values = def.keyType._zod.values;
				if (values) {
					payload.value = {};
					const recordKeys = /* @__PURE__ */ new Set();
					for (const key of values) if (typeof key === "string" || typeof key === "number" || typeof key === "symbol") {
						recordKeys.add(typeof key === "number" ? key.toString() : key);
						const keyResult = def.keyType._zod.run({
							value: key,
							issues: []
						}, ctx);
						if (keyResult instanceof Promise) throw new Error("Async schemas not supported in object keys currently");
						if (keyResult.issues.length) {
							payload.issues.push({
								code: "invalid_key",
								origin: "record",
								issues: keyResult.issues.map((iss) => finalizeIssue(iss, ctx, config())),
								input: key,
								path: [key],
								inst
							});
							continue;
						}
						const outKey = keyResult.value;
						const result = def.valueType._zod.run({
							value: input[key],
							issues: []
						}, ctx);
						if (result instanceof Promise) proms.push(result.then((result) => {
							if (result.issues.length) payload.issues.push(...prefixIssues(key, result.issues));
							payload.value[outKey] = result.value;
						}));
						else {
							if (result.issues.length) payload.issues.push(...prefixIssues(key, result.issues));
							payload.value[outKey] = result.value;
						}
					}
					let unrecognized;
					for (const key in input) if (!recordKeys.has(key)) {
						unrecognized = unrecognized ?? [];
						unrecognized.push(key);
					}
					if (unrecognized && unrecognized.length > 0) payload.issues.push({
						code: "unrecognized_keys",
						input,
						inst,
						keys: unrecognized
					});
				} else {
					payload.value = {};
					for (const key of Reflect.ownKeys(input)) {
						if (key === "__proto__") continue;
						if (!Object.prototype.propertyIsEnumerable.call(input, key)) continue;
						let keyResult = def.keyType._zod.run({
							value: key,
							issues: []
						}, ctx);
						if (keyResult instanceof Promise) throw new Error("Async schemas not supported in object keys currently");
						if (typeof key === "string" && number$1.test(key) && keyResult.issues.length) {
							const retryResult = def.keyType._zod.run({
								value: Number(key),
								issues: []
							}, ctx);
							if (retryResult instanceof Promise) throw new Error("Async schemas not supported in object keys currently");
							if (retryResult.issues.length === 0) keyResult = retryResult;
						}
						if (keyResult.issues.length) {
							if (def.mode === "loose") payload.value[key] = input[key];
							else payload.issues.push({
								code: "invalid_key",
								origin: "record",
								issues: keyResult.issues.map((iss) => finalizeIssue(iss, ctx, config())),
								input: key,
								path: [key],
								inst
							});
							continue;
						}
						const result = def.valueType._zod.run({
							value: input[key],
							issues: []
						}, ctx);
						if (result instanceof Promise) proms.push(result.then((result) => {
							if (result.issues.length) payload.issues.push(...prefixIssues(key, result.issues));
							payload.value[keyResult.value] = result.value;
						}));
						else {
							if (result.issues.length) payload.issues.push(...prefixIssues(key, result.issues));
							payload.value[keyResult.value] = result.value;
						}
					}
				}
				if (proms.length) return Promise.all(proms).then(() => payload);
				return payload;
			};
		});
		const $ZodEnum = /*@__PURE__*/ $constructor("$ZodEnum", (inst, def) => {
			$ZodType.init(inst, def);
			const values = getEnumValues(def.entries);
			const valuesSet = new Set(values);
			inst._zod.values = valuesSet;
			inst._zod.pattern = new RegExp(`^(${values.filter((k) => propertyKeyTypes.has(typeof k)).map((o) => typeof o === "string" ? escapeRegex(o) : o.toString()).join("|")})$`);
			inst._zod.parse = (payload, _ctx) => {
				const input = payload.value;
				if (valuesSet.has(input)) return payload;
				payload.issues.push({
					code: "invalid_value",
					values,
					input,
					inst
				});
				return payload;
			};
		});
		const $ZodLiteral = /*@__PURE__*/ $constructor("$ZodLiteral", (inst, def) => {
			$ZodType.init(inst, def);
			if (def.values.length === 0) throw new Error("Cannot create literal schema with no valid values");
			const values = new Set(def.values);
			inst._zod.values = values;
			inst._zod.pattern = new RegExp(`^(${def.values.map((o) => typeof o === "string" ? escapeRegex(o) : o ? escapeRegex(o.toString()) : String(o)).join("|")})$`);
			inst._zod.parse = (payload, _ctx) => {
				const input = payload.value;
				if (values.has(input)) return payload;
				payload.issues.push({
					code: "invalid_value",
					values: def.values,
					input,
					inst
				});
				return payload;
			};
		});
		const $ZodTransform = /*@__PURE__*/ $constructor("$ZodTransform", (inst, def) => {
			$ZodType.init(inst, def);
			inst._zod.optin = "optional";
			inst._zod.parse = (payload, ctx) => {
				if (ctx.direction === "backward") throw new $ZodEncodeError(inst.constructor.name);
				const _out = def.transform(payload.value, payload);
				if (ctx.async) return (_out instanceof Promise ? _out : Promise.resolve(_out)).then((output) => {
					payload.value = output;
					payload.fallback = true;
					return payload;
				});
				if (_out instanceof Promise) throw new $ZodAsyncError();
				payload.value = _out;
				payload.fallback = true;
				return payload;
			};
		});
		function handleOptionalResult(result, input) {
			if (input === void 0 && (result.issues.length || result.fallback)) return {
				issues: [],
				value: void 0
			};
			return result;
		}
		const $ZodOptional = /*@__PURE__*/ $constructor("$ZodOptional", (inst, def) => {
			$ZodType.init(inst, def);
			inst._zod.optin = "optional";
			inst._zod.optout = "optional";
			defineLazy(inst._zod, "values", () => {
				return def.innerType._zod.values ? new Set([...def.innerType._zod.values, void 0]) : void 0;
			});
			defineLazy(inst._zod, "pattern", () => {
				const pattern = def.innerType._zod.pattern;
				return pattern ? new RegExp(`^(${cleanRegex(pattern.source)})?$`) : void 0;
			});
			inst._zod.parse = (payload, ctx) => {
				if (def.innerType._zod.optin === "optional") {
					const input = payload.value;
					const result = def.innerType._zod.run(payload, ctx);
					if (result instanceof Promise) return result.then((r) => handleOptionalResult(r, input));
					return handleOptionalResult(result, input);
				}
				if (payload.value === void 0) return payload;
				return def.innerType._zod.run(payload, ctx);
			};
		});
		const $ZodExactOptional = /*@__PURE__*/ $constructor("$ZodExactOptional", (inst, def) => {
			$ZodOptional.init(inst, def);
			defineLazy(inst._zod, "values", () => def.innerType._zod.values);
			defineLazy(inst._zod, "pattern", () => def.innerType._zod.pattern);
			inst._zod.parse = (payload, ctx) => {
				return def.innerType._zod.run(payload, ctx);
			};
		});
		const $ZodNullable = /*@__PURE__*/ $constructor("$ZodNullable", (inst, def) => {
			$ZodType.init(inst, def);
			defineLazy(inst._zod, "optin", () => def.innerType._zod.optin);
			defineLazy(inst._zod, "optout", () => def.innerType._zod.optout);
			defineLazy(inst._zod, "pattern", () => {
				const pattern = def.innerType._zod.pattern;
				return pattern ? new RegExp(`^(${cleanRegex(pattern.source)}|null)$`) : void 0;
			});
			defineLazy(inst._zod, "values", () => {
				return def.innerType._zod.values ? new Set([...def.innerType._zod.values, null]) : void 0;
			});
			inst._zod.parse = (payload, ctx) => {
				if (payload.value === null) return payload;
				return def.innerType._zod.run(payload, ctx);
			};
		});
		const $ZodDefault = /*@__PURE__*/ $constructor("$ZodDefault", (inst, def) => {
			$ZodType.init(inst, def);
			inst._zod.optin = "optional";
			defineLazy(inst._zod, "values", () => def.innerType._zod.values);
			inst._zod.parse = (payload, ctx) => {
				if (ctx.direction === "backward") return def.innerType._zod.run(payload, ctx);
				if (payload.value === void 0) {
					payload.value = def.defaultValue;
					/**
					* $ZodDefault returns the default value immediately in forward direction.
					* It doesn't pass the default value into the validator ("prefault"). There's no reason to pass the default value through validation. The validity of the default is enforced by TypeScript statically. Otherwise, it's the responsibility of the user to ensure the default is valid. In the case of pipes with divergent in/out types, you can specify the default on the `in` schema of your ZodPipe to set a "prefault" for the pipe.   */
					return payload;
				}
				const result = def.innerType._zod.run(payload, ctx);
				if (result instanceof Promise) return result.then((result) => handleDefaultResult(result, def));
				return handleDefaultResult(result, def);
			};
		});
		function handleDefaultResult(payload, def) {
			if (payload.value === void 0) payload.value = def.defaultValue;
			return payload;
		}
		const $ZodPrefault = /*@__PURE__*/ $constructor("$ZodPrefault", (inst, def) => {
			$ZodType.init(inst, def);
			inst._zod.optin = "optional";
			defineLazy(inst._zod, "values", () => def.innerType._zod.values);
			inst._zod.parse = (payload, ctx) => {
				if (ctx.direction === "backward") return def.innerType._zod.run(payload, ctx);
				if (payload.value === void 0) payload.value = def.defaultValue;
				return def.innerType._zod.run(payload, ctx);
			};
		});
		const $ZodNonOptional = /*@__PURE__*/ $constructor("$ZodNonOptional", (inst, def) => {
			$ZodType.init(inst, def);
			defineLazy(inst._zod, "values", () => {
				const v = def.innerType._zod.values;
				return v ? new Set([...v].filter((x) => x !== void 0)) : void 0;
			});
			inst._zod.parse = (payload, ctx) => {
				const result = def.innerType._zod.run(payload, ctx);
				if (result instanceof Promise) return result.then((result) => handleNonOptionalResult(result, inst));
				return handleNonOptionalResult(result, inst);
			};
		});
		function handleNonOptionalResult(payload, inst) {
			if (!payload.issues.length && payload.value === void 0) payload.issues.push({
				code: "invalid_type",
				expected: "nonoptional",
				input: payload.value,
				inst
			});
			return payload;
		}
		const $ZodCatch = /*@__PURE__*/ $constructor("$ZodCatch", (inst, def) => {
			$ZodType.init(inst, def);
			inst._zod.optin = "optional";
			defineLazy(inst._zod, "optout", () => def.innerType._zod.optout);
			defineLazy(inst._zod, "values", () => def.innerType._zod.values);
			inst._zod.parse = (payload, ctx) => {
				if (ctx.direction === "backward") return def.innerType._zod.run(payload, ctx);
				const result = def.innerType._zod.run(payload, ctx);
				if (result instanceof Promise) return result.then((result) => {
					payload.value = result.value;
					if (result.issues.length) {
						payload.value = def.catchValue({
							...payload,
							error: { issues: result.issues.map((iss) => finalizeIssue(iss, ctx, config())) },
							input: payload.value
						});
						payload.issues = [];
						payload.fallback = true;
					}
					return payload;
				});
				payload.value = result.value;
				if (result.issues.length) {
					payload.value = def.catchValue({
						...payload,
						error: { issues: result.issues.map((iss) => finalizeIssue(iss, ctx, config())) },
						input: payload.value
					});
					payload.issues = [];
					payload.fallback = true;
				}
				return payload;
			};
		});
		const $ZodPipe = /*@__PURE__*/ $constructor("$ZodPipe", (inst, def) => {
			$ZodType.init(inst, def);
			defineLazy(inst._zod, "values", () => def.in._zod.values);
			defineLazy(inst._zod, "optin", () => def.in._zod.optin);
			defineLazy(inst._zod, "optout", () => def.out._zod.optout);
			defineLazy(inst._zod, "propValues", () => def.in._zod.propValues);
			inst._zod.parse = (payload, ctx) => {
				if (ctx.direction === "backward") {
					const right = def.out._zod.run(payload, ctx);
					if (right instanceof Promise) return right.then((right) => handlePipeResult(right, def.in, ctx));
					return handlePipeResult(right, def.in, ctx);
				}
				const left = def.in._zod.run(payload, ctx);
				if (left instanceof Promise) return left.then((left) => handlePipeResult(left, def.out, ctx));
				return handlePipeResult(left, def.out, ctx);
			};
		});
		function handlePipeResult(left, next, ctx) {
			if (left.issues.length) {
				left.aborted = true;
				return left;
			}
			return next._zod.run({
				value: left.value,
				issues: left.issues,
				fallback: left.fallback
			}, ctx);
		}
		const $ZodReadonly = /*@__PURE__*/ $constructor("$ZodReadonly", (inst, def) => {
			$ZodType.init(inst, def);
			defineLazy(inst._zod, "propValues", () => def.innerType._zod.propValues);
			defineLazy(inst._zod, "values", () => def.innerType._zod.values);
			defineLazy(inst._zod, "optin", () => def.innerType?._zod?.optin);
			defineLazy(inst._zod, "optout", () => def.innerType?._zod?.optout);
			inst._zod.parse = (payload, ctx) => {
				if (ctx.direction === "backward") return def.innerType._zod.run(payload, ctx);
				const result = def.innerType._zod.run(payload, ctx);
				if (result instanceof Promise) return result.then(handleReadonlyResult);
				return handleReadonlyResult(result);
			};
		});
		function handleReadonlyResult(payload) {
			payload.value = Object.freeze(payload.value);
			return payload;
		}
		const $ZodLazy = /*@__PURE__*/ $constructor("$ZodLazy", (inst, def) => {
			$ZodType.init(inst, def);
			defineLazy(inst._zod, "innerType", () => {
				const d = def;
				if (!d._cachedInner) d._cachedInner = def.getter();
				return d._cachedInner;
			});
			defineLazy(inst._zod, "pattern", () => inst._zod.innerType?._zod?.pattern);
			defineLazy(inst._zod, "propValues", () => inst._zod.innerType?._zod?.propValues);
			defineLazy(inst._zod, "optin", () => inst._zod.innerType?._zod?.optin ?? void 0);
			defineLazy(inst._zod, "optout", () => inst._zod.innerType?._zod?.optout ?? void 0);
			inst._zod.parse = (payload, ctx) => {
				return inst._zod.innerType._zod.run(payload, ctx);
			};
		});
		const $ZodCustom = /*@__PURE__*/ $constructor("$ZodCustom", (inst, def) => {
			$ZodCheck.init(inst, def);
			$ZodType.init(inst, def);
			inst._zod.parse = (payload, _) => {
				return payload;
			};
			inst._zod.check = (payload) => {
				const input = payload.value;
				const r = def.fn(input);
				if (r instanceof Promise) return r.then((r) => handleRefineResult(r, payload, input, inst));
				handleRefineResult(r, payload, input, inst);
			};
		});
		function handleRefineResult(result, payload, input, inst) {
			if (!result) {
				const _iss = {
					code: "custom",
					input,
					inst,
					path: [...inst._zod.def.path ?? []],
					continue: !inst._zod.def.abort
				};
				if (inst._zod.def.params) _iss.params = inst._zod.def.params;
				payload.issues.push(issue(_iss));
			}
		}
		//#endregion
		//#region ../../../node_modules/.pnpm/zod@4.4.3/node_modules/zod/v4/core/registries.js
		var _a;
		var $ZodRegistry = class {
			constructor() {
				this._map = /* @__PURE__ */ new WeakMap();
				this._idmap = /* @__PURE__ */ new Map();
			}
			add(schema, ..._meta) {
				const meta = _meta[0];
				this._map.set(schema, meta);
				if (meta && typeof meta === "object" && "id" in meta) this._idmap.set(meta.id, schema);
				return this;
			}
			clear() {
				this._map = /* @__PURE__ */ new WeakMap();
				this._idmap = /* @__PURE__ */ new Map();
				return this;
			}
			remove(schema) {
				const meta = this._map.get(schema);
				if (meta && typeof meta === "object" && "id" in meta) this._idmap.delete(meta.id);
				this._map.delete(schema);
				return this;
			}
			get(schema) {
				const p = schema._zod.parent;
				if (p) {
					const pm = { ...this.get(p) ?? {} };
					delete pm.id;
					const f = {
						...pm,
						...this._map.get(schema)
					};
					return Object.keys(f).length ? f : void 0;
				}
				return this._map.get(schema);
			}
			has(schema) {
				return this._map.has(schema);
			}
		};
		function registry() {
			return new $ZodRegistry();
		}
		(_a = globalThis).__zod_globalRegistry ?? (_a.__zod_globalRegistry = registry());
		const globalRegistry = globalThis.__zod_globalRegistry;
		//#endregion
		//#region ../../../node_modules/.pnpm/zod@4.4.3/node_modules/zod/v4/core/api.js
		// @__NO_SIDE_EFFECTS__
		function _string(Class, params) {
			return new Class({
				type: "string",
				...normalizeParams(params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _email(Class, params) {
			return new Class({
				type: "string",
				format: "email",
				check: "string_format",
				abort: false,
				...normalizeParams(params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _guid(Class, params) {
			return new Class({
				type: "string",
				format: "guid",
				check: "string_format",
				abort: false,
				...normalizeParams(params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _uuid(Class, params) {
			return new Class({
				type: "string",
				format: "uuid",
				check: "string_format",
				abort: false,
				...normalizeParams(params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _uuidv4(Class, params) {
			return new Class({
				type: "string",
				format: "uuid",
				check: "string_format",
				abort: false,
				version: "v4",
				...normalizeParams(params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _uuidv6(Class, params) {
			return new Class({
				type: "string",
				format: "uuid",
				check: "string_format",
				abort: false,
				version: "v6",
				...normalizeParams(params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _uuidv7(Class, params) {
			return new Class({
				type: "string",
				format: "uuid",
				check: "string_format",
				abort: false,
				version: "v7",
				...normalizeParams(params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _url(Class, params) {
			return new Class({
				type: "string",
				format: "url",
				check: "string_format",
				abort: false,
				...normalizeParams(params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _emoji(Class, params) {
			return new Class({
				type: "string",
				format: "emoji",
				check: "string_format",
				abort: false,
				...normalizeParams(params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _nanoid(Class, params) {
			return new Class({
				type: "string",
				format: "nanoid",
				check: "string_format",
				abort: false,
				...normalizeParams(params)
			});
		}
		/**
		* @deprecated CUID v1 is deprecated by its authors due to information leakage
		* (timestamps embedded in the id). Use {@link _cuid2} instead.
		* See https://github.com/paralleldrive/cuid.
		*/
		// @__NO_SIDE_EFFECTS__
		function _cuid(Class, params) {
			return new Class({
				type: "string",
				format: "cuid",
				check: "string_format",
				abort: false,
				...normalizeParams(params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _cuid2(Class, params) {
			return new Class({
				type: "string",
				format: "cuid2",
				check: "string_format",
				abort: false,
				...normalizeParams(params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _ulid(Class, params) {
			return new Class({
				type: "string",
				format: "ulid",
				check: "string_format",
				abort: false,
				...normalizeParams(params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _xid(Class, params) {
			return new Class({
				type: "string",
				format: "xid",
				check: "string_format",
				abort: false,
				...normalizeParams(params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _ksuid(Class, params) {
			return new Class({
				type: "string",
				format: "ksuid",
				check: "string_format",
				abort: false,
				...normalizeParams(params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _ipv4(Class, params) {
			return new Class({
				type: "string",
				format: "ipv4",
				check: "string_format",
				abort: false,
				...normalizeParams(params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _ipv6(Class, params) {
			return new Class({
				type: "string",
				format: "ipv6",
				check: "string_format",
				abort: false,
				...normalizeParams(params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _cidrv4(Class, params) {
			return new Class({
				type: "string",
				format: "cidrv4",
				check: "string_format",
				abort: false,
				...normalizeParams(params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _cidrv6(Class, params) {
			return new Class({
				type: "string",
				format: "cidrv6",
				check: "string_format",
				abort: false,
				...normalizeParams(params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _base64(Class, params) {
			return new Class({
				type: "string",
				format: "base64",
				check: "string_format",
				abort: false,
				...normalizeParams(params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _base64url(Class, params) {
			return new Class({
				type: "string",
				format: "base64url",
				check: "string_format",
				abort: false,
				...normalizeParams(params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _e164(Class, params) {
			return new Class({
				type: "string",
				format: "e164",
				check: "string_format",
				abort: false,
				...normalizeParams(params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _jwt(Class, params) {
			return new Class({
				type: "string",
				format: "jwt",
				check: "string_format",
				abort: false,
				...normalizeParams(params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _isoDateTime(Class, params) {
			return new Class({
				type: "string",
				format: "datetime",
				check: "string_format",
				offset: false,
				local: false,
				precision: null,
				...normalizeParams(params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _isoDate(Class, params) {
			return new Class({
				type: "string",
				format: "date",
				check: "string_format",
				...normalizeParams(params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _isoTime(Class, params) {
			return new Class({
				type: "string",
				format: "time",
				check: "string_format",
				precision: null,
				...normalizeParams(params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _isoDuration(Class, params) {
			return new Class({
				type: "string",
				format: "duration",
				check: "string_format",
				...normalizeParams(params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _number(Class, params) {
			return new Class({
				type: "number",
				checks: [],
				...normalizeParams(params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _int(Class, params) {
			return new Class({
				type: "number",
				check: "number_format",
				abort: false,
				format: "safeint",
				...normalizeParams(params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _boolean(Class, params) {
			return new Class({
				type: "boolean",
				...normalizeParams(params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _undefined$1(Class, params) {
			return new Class({
				type: "undefined",
				...normalizeParams(params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _unknown(Class) {
			return new Class({ type: "unknown" });
		}
		// @__NO_SIDE_EFFECTS__
		function _never(Class, params) {
			return new Class({
				type: "never",
				...normalizeParams(params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _void$1(Class, params) {
			return new Class({
				type: "void",
				...normalizeParams(params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _lt(value, params) {
			return new $ZodCheckLessThan({
				check: "less_than",
				...normalizeParams(params),
				value,
				inclusive: false
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _lte(value, params) {
			return new $ZodCheckLessThan({
				check: "less_than",
				...normalizeParams(params),
				value,
				inclusive: true
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _gt(value, params) {
			return new $ZodCheckGreaterThan({
				check: "greater_than",
				...normalizeParams(params),
				value,
				inclusive: false
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _gte(value, params) {
			return new $ZodCheckGreaterThan({
				check: "greater_than",
				...normalizeParams(params),
				value,
				inclusive: true
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _multipleOf(value, params) {
			return new $ZodCheckMultipleOf({
				check: "multiple_of",
				...normalizeParams(params),
				value
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _maxLength(maximum, params) {
			return new $ZodCheckMaxLength({
				check: "max_length",
				...normalizeParams(params),
				maximum
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _minLength(minimum, params) {
			return new $ZodCheckMinLength({
				check: "min_length",
				...normalizeParams(params),
				minimum
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _length(length, params) {
			return new $ZodCheckLengthEquals({
				check: "length_equals",
				...normalizeParams(params),
				length
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _regex(pattern, params) {
			return new $ZodCheckRegex({
				check: "string_format",
				format: "regex",
				...normalizeParams(params),
				pattern
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _lowercase(params) {
			return new $ZodCheckLowerCase({
				check: "string_format",
				format: "lowercase",
				...normalizeParams(params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _uppercase(params) {
			return new $ZodCheckUpperCase({
				check: "string_format",
				format: "uppercase",
				...normalizeParams(params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _includes(includes, params) {
			return new $ZodCheckIncludes({
				check: "string_format",
				format: "includes",
				...normalizeParams(params),
				includes
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _startsWith(prefix, params) {
			return new $ZodCheckStartsWith({
				check: "string_format",
				format: "starts_with",
				...normalizeParams(params),
				prefix
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _endsWith(suffix, params) {
			return new $ZodCheckEndsWith({
				check: "string_format",
				format: "ends_with",
				...normalizeParams(params),
				suffix
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _overwrite(tx) {
			return new $ZodCheckOverwrite({
				check: "overwrite",
				tx
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _normalize(form) {
			return /* @__PURE__ */ _overwrite((input) => input.normalize(form));
		}
		// @__NO_SIDE_EFFECTS__
		function _trim() {
			return /* @__PURE__ */ _overwrite((input) => input.trim());
		}
		// @__NO_SIDE_EFFECTS__
		function _toLowerCase() {
			return /* @__PURE__ */ _overwrite((input) => input.toLowerCase());
		}
		// @__NO_SIDE_EFFECTS__
		function _toUpperCase() {
			return /* @__PURE__ */ _overwrite((input) => input.toUpperCase());
		}
		// @__NO_SIDE_EFFECTS__
		function _slugify() {
			return /* @__PURE__ */ _overwrite((input) => slugify(input));
		}
		// @__NO_SIDE_EFFECTS__
		function _array(Class, element, params) {
			return new Class({
				type: "array",
				element,
				...normalizeParams(params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _refine(Class, fn, _params) {
			return new Class({
				type: "custom",
				check: "custom",
				fn,
				...normalizeParams(_params)
			});
		}
		// @__NO_SIDE_EFFECTS__
		function _superRefine(fn, params) {
			const ch = /* @__PURE__ */ _check((payload) => {
				payload.addIssue = (issue$2) => {
					if (typeof issue$2 === "string") payload.issues.push(issue(issue$2, payload.value, ch._zod.def));
					else {
						const _issue = issue$2;
						if (_issue.fatal) _issue.continue = false;
						_issue.code ?? (_issue.code = "custom");
						_issue.input ?? (_issue.input = payload.value);
						_issue.inst ?? (_issue.inst = ch);
						_issue.continue ?? (_issue.continue = !ch._zod.def.abort);
						payload.issues.push(issue(_issue));
					}
				};
				return fn(payload.value, payload);
			}, params);
			return ch;
		}
		// @__NO_SIDE_EFFECTS__
		function _check(fn, params) {
			const ch = new $ZodCheck({
				check: "custom",
				...normalizeParams(params)
			});
			ch._zod.check = fn;
			return ch;
		}
		//#endregion
		//#region ../../../node_modules/.pnpm/zod@4.4.3/node_modules/zod/v4/core/to-json-schema.js
		function initializeContext(params) {
			let target = params?.target ?? "draft-2020-12";
			if (target === "draft-4") target = "draft-04";
			if (target === "draft-7") target = "draft-07";
			return {
				processors: params.processors ?? {},
				metadataRegistry: params?.metadata ?? globalRegistry,
				target,
				unrepresentable: params?.unrepresentable ?? "throw",
				override: params?.override ?? (() => {}),
				io: params?.io ?? "output",
				counter: 0,
				seen: /* @__PURE__ */ new Map(),
				cycles: params?.cycles ?? "ref",
				reused: params?.reused ?? "inline",
				external: params?.external ?? void 0
			};
		}
		function process(schema, ctx, _params = {
			path: [],
			schemaPath: []
		}) {
			var _a;
			const def = schema._zod.def;
			const seen = ctx.seen.get(schema);
			if (seen) {
				seen.count++;
				if (_params.schemaPath.includes(schema)) seen.cycle = _params.path;
				return seen.schema;
			}
			const result = {
				schema: {},
				count: 1,
				cycle: void 0,
				path: _params.path
			};
			ctx.seen.set(schema, result);
			const overrideSchema = schema._zod.toJSONSchema?.();
			if (overrideSchema) result.schema = overrideSchema;
			else {
				const params = {
					..._params,
					schemaPath: [..._params.schemaPath, schema],
					path: _params.path
				};
				if (schema._zod.processJSONSchema) schema._zod.processJSONSchema(ctx, result.schema, params);
				else {
					const _json = result.schema;
					const processor = ctx.processors[def.type];
					if (!processor) throw new Error(`[toJSONSchema]: Non-representable type encountered: ${def.type}`);
					processor(schema, ctx, _json, params);
				}
				const parent = schema._zod.parent;
				if (parent) {
					if (!result.ref) result.ref = parent;
					process(parent, ctx, params);
					ctx.seen.get(parent).isParent = true;
				}
			}
			const meta = ctx.metadataRegistry.get(schema);
			if (meta) Object.assign(result.schema, meta);
			if (ctx.io === "input" && isTransforming(schema)) {
				delete result.schema.examples;
				delete result.schema.default;
			}
			if (ctx.io === "input" && "_prefault" in result.schema) (_a = result.schema).default ?? (_a.default = result.schema._prefault);
			delete result.schema._prefault;
			return ctx.seen.get(schema).schema;
		}
		function extractDefs(ctx, schema) {
			const root = ctx.seen.get(schema);
			if (!root) throw new Error("Unprocessed schema. This is a bug in Zod.");
			const idToSchema = /* @__PURE__ */ new Map();
			for (const entry of ctx.seen.entries()) {
				const id = ctx.metadataRegistry.get(entry[0])?.id;
				if (id) {
					const existing = idToSchema.get(id);
					if (existing && existing !== entry[0]) throw new Error(`Duplicate schema id "${id}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`);
					idToSchema.set(id, entry[0]);
				}
			}
			const makeURI = (entry) => {
				const defsSegment = ctx.target === "draft-2020-12" ? "$defs" : "definitions";
				if (ctx.external) {
					const externalId = ctx.external.registry.get(entry[0])?.id;
					const uriGenerator = ctx.external.uri ?? ((id) => id);
					if (externalId) return { ref: uriGenerator(externalId) };
					const id = entry[1].defId ?? entry[1].schema.id ?? `schema${ctx.counter++}`;
					entry[1].defId = id;
					return {
						defId: id,
						ref: `${uriGenerator("__shared")}#/${defsSegment}/${id}`
					};
				}
				if (entry[1] === root) return { ref: "#" };
				const defUriPrefix = `#/${defsSegment}/`;
				const defId = entry[1].schema.id ?? `__schema${ctx.counter++}`;
				return {
					defId,
					ref: defUriPrefix + defId
				};
			};
			const extractToDef = (entry) => {
				if (entry[1].schema.$ref) return;
				const seen = entry[1];
				const { ref, defId } = makeURI(entry);
				seen.def = { ...seen.schema };
				if (defId) seen.defId = defId;
				const schema = seen.schema;
				for (const key in schema) delete schema[key];
				schema.$ref = ref;
			};
			if (ctx.cycles === "throw") for (const entry of ctx.seen.entries()) {
				const seen = entry[1];
				if (seen.cycle) throw new Error(`Cycle detected: #/${seen.cycle?.join("/")}/<root>

Set the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`);
			}
			for (const entry of ctx.seen.entries()) {
				const seen = entry[1];
				if (schema === entry[0]) {
					extractToDef(entry);
					continue;
				}
				if (ctx.external) {
					const ext = ctx.external.registry.get(entry[0])?.id;
					if (schema !== entry[0] && ext) {
						extractToDef(entry);
						continue;
					}
				}
				if (ctx.metadataRegistry.get(entry[0])?.id) {
					extractToDef(entry);
					continue;
				}
				if (seen.cycle) {
					extractToDef(entry);
					continue;
				}
				if (seen.count > 1) {
					if (ctx.reused === "ref") {
						extractToDef(entry);
						continue;
					}
				}
			}
		}
		function finalize(ctx, schema) {
			const root = ctx.seen.get(schema);
			if (!root) throw new Error("Unprocessed schema. This is a bug in Zod.");
			const flattenRef = (zodSchema) => {
				const seen = ctx.seen.get(zodSchema);
				if (seen.ref === null) return;
				const schema = seen.def ?? seen.schema;
				const _cached = { ...schema };
				const ref = seen.ref;
				seen.ref = null;
				if (ref) {
					flattenRef(ref);
					const refSeen = ctx.seen.get(ref);
					const refSchema = refSeen.schema;
					if (refSchema.$ref && (ctx.target === "draft-07" || ctx.target === "draft-04" || ctx.target === "openapi-3.0")) {
						schema.allOf = schema.allOf ?? [];
						schema.allOf.push(refSchema);
					} else Object.assign(schema, refSchema);
					Object.assign(schema, _cached);
					if (zodSchema._zod.parent === ref) for (const key in schema) {
						if (key === "$ref" || key === "allOf") continue;
						if (!(key in _cached)) delete schema[key];
					}
					if (refSchema.$ref && refSeen.def) for (const key in schema) {
						if (key === "$ref" || key === "allOf") continue;
						if (key in refSeen.def && JSON.stringify(schema[key]) === JSON.stringify(refSeen.def[key])) delete schema[key];
					}
				}
				const parent = zodSchema._zod.parent;
				if (parent && parent !== ref) {
					flattenRef(parent);
					const parentSeen = ctx.seen.get(parent);
					if (parentSeen?.schema.$ref) {
						schema.$ref = parentSeen.schema.$ref;
						if (parentSeen.def) for (const key in schema) {
							if (key === "$ref" || key === "allOf") continue;
							if (key in parentSeen.def && JSON.stringify(schema[key]) === JSON.stringify(parentSeen.def[key])) delete schema[key];
						}
					}
				}
				ctx.override({
					zodSchema,
					jsonSchema: schema,
					path: seen.path ?? []
				});
			};
			for (const entry of [...ctx.seen.entries()].reverse()) flattenRef(entry[0]);
			const result = {};
			if (ctx.target === "draft-2020-12") result.$schema = "https://json-schema.org/draft/2020-12/schema";
			else if (ctx.target === "draft-07") result.$schema = "http://json-schema.org/draft-07/schema#";
			else if (ctx.target === "draft-04") result.$schema = "http://json-schema.org/draft-04/schema#";
			else if (ctx.target === "openapi-3.0") {}
			if (ctx.external?.uri) {
				const id = ctx.external.registry.get(schema)?.id;
				if (!id) throw new Error("Schema is missing an `id` property");
				result.$id = ctx.external.uri(id);
			}
			Object.assign(result, root.def ?? root.schema);
			const rootMetaId = ctx.metadataRegistry.get(schema)?.id;
			if (rootMetaId !== void 0 && result.id === rootMetaId) delete result.id;
			const defs = ctx.external?.defs ?? {};
			for (const entry of ctx.seen.entries()) {
				const seen = entry[1];
				if (seen.def && seen.defId) {
					if (seen.def.id === seen.defId) delete seen.def.id;
					defs[seen.defId] = seen.def;
				}
			}
			if (ctx.external) {} else if (Object.keys(defs).length > 0) if (ctx.target === "draft-2020-12") result.$defs = defs;
			else result.definitions = defs;
			try {
				const finalized = JSON.parse(JSON.stringify(result));
				Object.defineProperty(finalized, "~standard", {
					value: {
						...schema["~standard"],
						jsonSchema: {
							input: createStandardJSONSchemaMethod(schema, "input", ctx.processors),
							output: createStandardJSONSchemaMethod(schema, "output", ctx.processors)
						}
					},
					enumerable: false,
					writable: false
				});
				return finalized;
			} catch (_err) {
				throw new Error("Error converting schema to JSON.");
			}
		}
		function isTransforming(_schema, _ctx) {
			const ctx = _ctx ?? { seen: /* @__PURE__ */ new Set() };
			if (ctx.seen.has(_schema)) return false;
			ctx.seen.add(_schema);
			const def = _schema._zod.def;
			if (def.type === "transform") return true;
			if (def.type === "array") return isTransforming(def.element, ctx);
			if (def.type === "set") return isTransforming(def.valueType, ctx);
			if (def.type === "lazy") return isTransforming(def.getter(), ctx);
			if (def.type === "promise" || def.type === "optional" || def.type === "nonoptional" || def.type === "nullable" || def.type === "readonly" || def.type === "default" || def.type === "prefault") return isTransforming(def.innerType, ctx);
			if (def.type === "intersection") return isTransforming(def.left, ctx) || isTransforming(def.right, ctx);
			if (def.type === "record" || def.type === "map") return isTransforming(def.keyType, ctx) || isTransforming(def.valueType, ctx);
			if (def.type === "pipe") {
				if (_schema._zod.traits.has("$ZodCodec")) return true;
				return isTransforming(def.in, ctx) || isTransforming(def.out, ctx);
			}
			if (def.type === "object") {
				for (const key in def.shape) if (isTransforming(def.shape[key], ctx)) return true;
				return false;
			}
			if (def.type === "union") {
				for (const option of def.options) if (isTransforming(option, ctx)) return true;
				return false;
			}
			if (def.type === "tuple") {
				for (const item of def.items) if (isTransforming(item, ctx)) return true;
				if (def.rest && isTransforming(def.rest, ctx)) return true;
				return false;
			}
			return false;
		}
		/**
		* Creates a toJSONSchema method for a schema instance.
		* This encapsulates the logic of initializing context, processing, extracting defs, and finalizing.
		*/
		const createToJSONSchemaMethod = (schema, processors = {}) => (params) => {
			const ctx = initializeContext({
				...params,
				processors
			});
			process(schema, ctx);
			extractDefs(ctx, schema);
			return finalize(ctx, schema);
		};
		const createStandardJSONSchemaMethod = (schema, io, processors = {}) => (params) => {
			const { libraryOptions, target } = params ?? {};
			const ctx = initializeContext({
				...libraryOptions ?? {},
				target,
				io,
				processors
			});
			process(schema, ctx);
			extractDefs(ctx, schema);
			return finalize(ctx, schema);
		};
		//#endregion
		//#region ../../../node_modules/.pnpm/zod@4.4.3/node_modules/zod/v4/core/json-schema-processors.js
		const formatMap = {
			guid: "uuid",
			url: "uri",
			datetime: "date-time",
			json_string: "json-string",
			regex: ""
		};
		const stringProcessor = (schema, ctx, _json, _params) => {
			const json = _json;
			json.type = "string";
			const { minimum, maximum, format, patterns, contentEncoding } = schema._zod.bag;
			if (typeof minimum === "number") json.minLength = minimum;
			if (typeof maximum === "number") json.maxLength = maximum;
			if (format) {
				json.format = formatMap[format] ?? format;
				if (json.format === "") delete json.format;
				if (format === "time") delete json.format;
			}
			if (contentEncoding) json.contentEncoding = contentEncoding;
			if (patterns && patterns.size > 0) {
				const regexes = [...patterns];
				if (regexes.length === 1) json.pattern = regexes[0].source;
				else if (regexes.length > 1) json.allOf = [...regexes.map((regex) => ({
					...ctx.target === "draft-07" || ctx.target === "draft-04" || ctx.target === "openapi-3.0" ? { type: "string" } : {},
					pattern: regex.source
				}))];
			}
		};
		const numberProcessor = (schema, ctx, _json, _params) => {
			const json = _json;
			const { minimum, maximum, format, multipleOf, exclusiveMaximum, exclusiveMinimum } = schema._zod.bag;
			if (typeof format === "string" && format.includes("int")) json.type = "integer";
			else json.type = "number";
			const exMin = typeof exclusiveMinimum === "number" && exclusiveMinimum >= (minimum ?? Number.NEGATIVE_INFINITY);
			const exMax = typeof exclusiveMaximum === "number" && exclusiveMaximum <= (maximum ?? Number.POSITIVE_INFINITY);
			const legacy = ctx.target === "draft-04" || ctx.target === "openapi-3.0";
			if (exMin) if (legacy) {
				json.minimum = exclusiveMinimum;
				json.exclusiveMinimum = true;
			} else json.exclusiveMinimum = exclusiveMinimum;
			else if (typeof minimum === "number") json.minimum = minimum;
			if (exMax) if (legacy) {
				json.maximum = exclusiveMaximum;
				json.exclusiveMaximum = true;
			} else json.exclusiveMaximum = exclusiveMaximum;
			else if (typeof maximum === "number") json.maximum = maximum;
			if (typeof multipleOf === "number") json.multipleOf = multipleOf;
		};
		const booleanProcessor = (_schema, _ctx, json, _params) => {
			json.type = "boolean";
		};
		const undefinedProcessor = (_schema, ctx, _json, _params) => {
			if (ctx.unrepresentable === "throw") throw new Error("Undefined cannot be represented in JSON Schema");
		};
		const voidProcessor = (_schema, ctx, _json, _params) => {
			if (ctx.unrepresentable === "throw") throw new Error("Void cannot be represented in JSON Schema");
		};
		const neverProcessor = (_schema, _ctx, json, _params) => {
			json.not = {};
		};
		const enumProcessor = (schema, _ctx, json, _params) => {
			const def = schema._zod.def;
			const values = getEnumValues(def.entries);
			if (values.every((v) => typeof v === "number")) json.type = "number";
			if (values.every((v) => typeof v === "string")) json.type = "string";
			json.enum = values;
		};
		const literalProcessor = (schema, ctx, json, _params) => {
			const def = schema._zod.def;
			const vals = [];
			for (const val of def.values) if (val === void 0) {
				if (ctx.unrepresentable === "throw") throw new Error("Literal `undefined` cannot be represented in JSON Schema");
			} else if (typeof val === "bigint") if (ctx.unrepresentable === "throw") throw new Error("BigInt literals cannot be represented in JSON Schema");
			else vals.push(Number(val));
			else vals.push(val);
			if (vals.length === 0) {} else if (vals.length === 1) {
				const val = vals[0];
				json.type = val === null ? "null" : typeof val;
				if (ctx.target === "draft-04" || ctx.target === "openapi-3.0") json.enum = [val];
				else json.const = val;
			} else {
				if (vals.every((v) => typeof v === "number")) json.type = "number";
				if (vals.every((v) => typeof v === "string")) json.type = "string";
				if (vals.every((v) => typeof v === "boolean")) json.type = "boolean";
				if (vals.every((v) => v === null)) json.type = "null";
				json.enum = vals;
			}
		};
		const customProcessor = (_schema, ctx, _json, _params) => {
			if (ctx.unrepresentable === "throw") throw new Error("Custom types cannot be represented in JSON Schema");
		};
		const transformProcessor = (_schema, ctx, _json, _params) => {
			if (ctx.unrepresentable === "throw") throw new Error("Transforms cannot be represented in JSON Schema");
		};
		const arrayProcessor = (schema, ctx, _json, params) => {
			const json = _json;
			const def = schema._zod.def;
			const { minimum, maximum } = schema._zod.bag;
			if (typeof minimum === "number") json.minItems = minimum;
			if (typeof maximum === "number") json.maxItems = maximum;
			json.type = "array";
			json.items = process(def.element, ctx, {
				...params,
				path: [...params.path, "items"]
			});
		};
		const objectProcessor = (schema, ctx, _json, params) => {
			const json = _json;
			const def = schema._zod.def;
			json.type = "object";
			json.properties = {};
			const shape = def.shape;
			for (const key in shape) json.properties[key] = process(shape[key], ctx, {
				...params,
				path: [
					...params.path,
					"properties",
					key
				]
			});
			const allKeys = new Set(Object.keys(shape));
			const requiredKeys = new Set([...allKeys].filter((key) => {
				const v = def.shape[key]._zod;
				if (ctx.io === "input") return v.optin === void 0;
				else return v.optout === void 0;
			}));
			if (requiredKeys.size > 0) json.required = Array.from(requiredKeys);
			if (def.catchall?._zod.def.type === "never") json.additionalProperties = false;
			else if (!def.catchall) {
				if (ctx.io === "output") json.additionalProperties = false;
			} else if (def.catchall) json.additionalProperties = process(def.catchall, ctx, {
				...params,
				path: [...params.path, "additionalProperties"]
			});
		};
		const unionProcessor = (schema, ctx, json, params) => {
			const def = schema._zod.def;
			const isExclusive = def.inclusive === false;
			const options = def.options.map((x, i) => process(x, ctx, {
				...params,
				path: [
					...params.path,
					isExclusive ? "oneOf" : "anyOf",
					i
				]
			}));
			if (isExclusive) json.oneOf = options;
			else json.anyOf = options;
		};
		const intersectionProcessor = (schema, ctx, json, params) => {
			const def = schema._zod.def;
			const a = process(def.left, ctx, {
				...params,
				path: [
					...params.path,
					"allOf",
					0
				]
			});
			const b = process(def.right, ctx, {
				...params,
				path: [
					...params.path,
					"allOf",
					1
				]
			});
			const isSimpleIntersection = (val) => "allOf" in val && Object.keys(val).length === 1;
			json.allOf = [...isSimpleIntersection(a) ? a.allOf : [a], ...isSimpleIntersection(b) ? b.allOf : [b]];
		};
		const recordProcessor = (schema, ctx, _json, params) => {
			const json = _json;
			const def = schema._zod.def;
			json.type = "object";
			const keyType = def.keyType;
			const patterns = keyType._zod.bag?.patterns;
			if (def.mode === "loose" && patterns && patterns.size > 0) {
				const valueSchema = process(def.valueType, ctx, {
					...params,
					path: [
						...params.path,
						"patternProperties",
						"*"
					]
				});
				json.patternProperties = {};
				for (const pattern of patterns) json.patternProperties[pattern.source] = valueSchema;
			} else {
				if (ctx.target === "draft-07" || ctx.target === "draft-2020-12") json.propertyNames = process(def.keyType, ctx, {
					...params,
					path: [...params.path, "propertyNames"]
				});
				json.additionalProperties = process(def.valueType, ctx, {
					...params,
					path: [...params.path, "additionalProperties"]
				});
			}
			const keyValues = keyType._zod.values;
			if (keyValues) {
				const validKeyValues = [...keyValues].filter((v) => typeof v === "string" || typeof v === "number");
				if (validKeyValues.length > 0) json.required = validKeyValues;
			}
		};
		const nullableProcessor = (schema, ctx, json, params) => {
			const def = schema._zod.def;
			const inner = process(def.innerType, ctx, params);
			const seen = ctx.seen.get(schema);
			if (ctx.target === "openapi-3.0") {
				seen.ref = def.innerType;
				json.nullable = true;
			} else json.anyOf = [inner, { type: "null" }];
		};
		const nonoptionalProcessor = (schema, ctx, _json, params) => {
			const def = schema._zod.def;
			process(def.innerType, ctx, params);
			const seen = ctx.seen.get(schema);
			seen.ref = def.innerType;
		};
		const defaultProcessor = (schema, ctx, json, params) => {
			const def = schema._zod.def;
			process(def.innerType, ctx, params);
			const seen = ctx.seen.get(schema);
			seen.ref = def.innerType;
			json.default = JSON.parse(JSON.stringify(def.defaultValue));
		};
		const prefaultProcessor = (schema, ctx, json, params) => {
			const def = schema._zod.def;
			process(def.innerType, ctx, params);
			const seen = ctx.seen.get(schema);
			seen.ref = def.innerType;
			if (ctx.io === "input") json._prefault = JSON.parse(JSON.stringify(def.defaultValue));
		};
		const catchProcessor = (schema, ctx, json, params) => {
			const def = schema._zod.def;
			process(def.innerType, ctx, params);
			const seen = ctx.seen.get(schema);
			seen.ref = def.innerType;
			let catchValue;
			try {
				catchValue = def.catchValue(void 0);
			} catch {
				throw new Error("Dynamic catch values are not supported in JSON Schema");
			}
			json.default = catchValue;
		};
		const pipeProcessor = (schema, ctx, _json, params) => {
			const def = schema._zod.def;
			const inIsTransform = def.in._zod.traits.has("$ZodTransform");
			const innerType = ctx.io === "input" ? inIsTransform ? def.out : def.in : def.out;
			process(innerType, ctx, params);
			const seen = ctx.seen.get(schema);
			seen.ref = innerType;
		};
		const readonlyProcessor = (schema, ctx, json, params) => {
			const def = schema._zod.def;
			process(def.innerType, ctx, params);
			const seen = ctx.seen.get(schema);
			seen.ref = def.innerType;
			json.readOnly = true;
		};
		const optionalProcessor = (schema, ctx, _json, params) => {
			const def = schema._zod.def;
			process(def.innerType, ctx, params);
			const seen = ctx.seen.get(schema);
			seen.ref = def.innerType;
		};
		const lazyProcessor = (schema, ctx, _json, params) => {
			const innerType = schema._zod.innerType;
			process(innerType, ctx, params);
			const seen = ctx.seen.get(schema);
			seen.ref = innerType;
		};
		//#endregion
		//#region ../../../node_modules/.pnpm/zod@4.4.3/node_modules/zod/v4/classic/iso.js
		const ZodISODateTime = /*@__PURE__*/ $constructor("ZodISODateTime", (inst, def) => {
			$ZodISODateTime.init(inst, def);
			ZodStringFormat.init(inst, def);
		});
		function datetime(params) {
			return /* @__PURE__ */ _isoDateTime(ZodISODateTime, params);
		}
		const ZodISODate = /*@__PURE__*/ $constructor("ZodISODate", (inst, def) => {
			$ZodISODate.init(inst, def);
			ZodStringFormat.init(inst, def);
		});
		function date(params) {
			return /* @__PURE__ */ _isoDate(ZodISODate, params);
		}
		const ZodISOTime = /*@__PURE__*/ $constructor("ZodISOTime", (inst, def) => {
			$ZodISOTime.init(inst, def);
			ZodStringFormat.init(inst, def);
		});
		function time(params) {
			return /* @__PURE__ */ _isoTime(ZodISOTime, params);
		}
		const ZodISODuration = /*@__PURE__*/ $constructor("ZodISODuration", (inst, def) => {
			$ZodISODuration.init(inst, def);
			ZodStringFormat.init(inst, def);
		});
		function duration(params) {
			return /* @__PURE__ */ _isoDuration(ZodISODuration, params);
		}
		//#endregion
		//#region ../../../node_modules/.pnpm/zod@4.4.3/node_modules/zod/v4/classic/errors.js
		const initializer = (inst, issues) => {
			$ZodError.init(inst, issues);
			inst.name = "ZodError";
			Object.defineProperties(inst, {
				format: { value: (mapper) => formatError(inst, mapper) },
				flatten: { value: (mapper) => flattenError(inst, mapper) },
				addIssue: { value: (issue) => {
					inst.issues.push(issue);
					inst.message = JSON.stringify(inst.issues, jsonStringifyReplacer, 2);
				} },
				addIssues: { value: (issues) => {
					inst.issues.push(...issues);
					inst.message = JSON.stringify(inst.issues, jsonStringifyReplacer, 2);
				} },
				isEmpty: { get() {
					return inst.issues.length === 0;
				} }
			});
		};
		const ZodRealError = /*@__PURE__*/ $constructor("ZodError", initializer, { Parent: Error });
		//#endregion
		//#region ../../../node_modules/.pnpm/zod@4.4.3/node_modules/zod/v4/classic/parse.js
		const parse = /* @__PURE__ */ _parse(ZodRealError);
		const parseAsync = /* @__PURE__ */ _parseAsync(ZodRealError);
		const safeParse = /* @__PURE__ */ _safeParse(ZodRealError);
		const safeParseAsync = /* @__PURE__ */ _safeParseAsync(ZodRealError);
		const encode = /* @__PURE__ */ _encode(ZodRealError);
		const decode = /* @__PURE__ */ _decode(ZodRealError);
		const encodeAsync = /* @__PURE__ */ _encodeAsync(ZodRealError);
		const decodeAsync = /* @__PURE__ */ _decodeAsync(ZodRealError);
		const safeEncode = /* @__PURE__ */ _safeEncode(ZodRealError);
		const safeDecode = /* @__PURE__ */ _safeDecode(ZodRealError);
		const safeEncodeAsync = /* @__PURE__ */ _safeEncodeAsync(ZodRealError);
		const safeDecodeAsync = /* @__PURE__ */ _safeDecodeAsync(ZodRealError);
		//#endregion
		//#region ../../../node_modules/.pnpm/zod@4.4.3/node_modules/zod/v4/classic/schemas.js
		const _installedGroups = /* @__PURE__ */ new WeakMap();
		function _installLazyMethods(inst, group, methods) {
			const proto = Object.getPrototypeOf(inst);
			let installed = _installedGroups.get(proto);
			if (!installed) {
				installed = /* @__PURE__ */ new Set();
				_installedGroups.set(proto, installed);
			}
			if (installed.has(group)) return;
			installed.add(group);
			for (const key in methods) {
				const fn = methods[key];
				Object.defineProperty(proto, key, {
					configurable: true,
					enumerable: false,
					get() {
						const bound = fn.bind(this);
						Object.defineProperty(this, key, {
							configurable: true,
							writable: true,
							enumerable: true,
							value: bound
						});
						return bound;
					},
					set(v) {
						Object.defineProperty(this, key, {
							configurable: true,
							writable: true,
							enumerable: true,
							value: v
						});
					}
				});
			}
		}
		const ZodType = /*@__PURE__*/ $constructor("ZodType", (inst, def) => {
			$ZodType.init(inst, def);
			Object.assign(inst["~standard"], { jsonSchema: {
				input: createStandardJSONSchemaMethod(inst, "input"),
				output: createStandardJSONSchemaMethod(inst, "output")
			} });
			inst.toJSONSchema = createToJSONSchemaMethod(inst, {});
			inst.def = def;
			inst.type = def.type;
			Object.defineProperty(inst, "_def", { value: def });
			inst.parse = (data, params) => parse(inst, data, params, { callee: inst.parse });
			inst.safeParse = (data, params) => safeParse(inst, data, params);
			inst.parseAsync = async (data, params) => parseAsync(inst, data, params, { callee: inst.parseAsync });
			inst.safeParseAsync = async (data, params) => safeParseAsync(inst, data, params);
			inst.spa = inst.safeParseAsync;
			inst.encode = (data, params) => encode(inst, data, params);
			inst.decode = (data, params) => decode(inst, data, params);
			inst.encodeAsync = async (data, params) => encodeAsync(inst, data, params);
			inst.decodeAsync = async (data, params) => decodeAsync(inst, data, params);
			inst.safeEncode = (data, params) => safeEncode(inst, data, params);
			inst.safeDecode = (data, params) => safeDecode(inst, data, params);
			inst.safeEncodeAsync = async (data, params) => safeEncodeAsync(inst, data, params);
			inst.safeDecodeAsync = async (data, params) => safeDecodeAsync(inst, data, params);
			_installLazyMethods(inst, "ZodType", {
				check(...chks) {
					const def = this.def;
					return this.clone(mergeDefs(def, { checks: [...def.checks ?? [], ...chks.map((ch) => typeof ch === "function" ? { _zod: {
						check: ch,
						def: { check: "custom" },
						onattach: []
					} } : ch)] }), { parent: true });
				},
				with(...chks) {
					return this.check(...chks);
				},
				clone(def, params) {
					return clone(this, def, params);
				},
				brand() {
					return this;
				},
				register(reg, meta) {
					reg.add(this, meta);
					return this;
				},
				refine(check, params) {
					return this.check(refine(check, params));
				},
				superRefine(refinement, params) {
					return this.check(superRefine(refinement, params));
				},
				overwrite(fn) {
					return this.check(/* @__PURE__ */ _overwrite(fn));
				},
				optional() {
					return optional(this);
				},
				exactOptional() {
					return exactOptional(this);
				},
				nullable() {
					return nullable(this);
				},
				nullish() {
					return optional(nullable(this));
				},
				nonoptional(params) {
					return nonoptional(this, params);
				},
				array() {
					return array(this);
				},
				or(arg) {
					return union([this, arg]);
				},
				and(arg) {
					return intersection(this, arg);
				},
				transform(tx) {
					return pipe(this, transform(tx));
				},
				default(d) {
					return _default(this, d);
				},
				prefault(d) {
					return prefault(this, d);
				},
				catch(params) {
					return _catch(this, params);
				},
				pipe(target) {
					return pipe(this, target);
				},
				readonly() {
					return readonly(this);
				},
				describe(description) {
					const cl = this.clone();
					globalRegistry.add(cl, { description });
					return cl;
				},
				meta(...args) {
					if (args.length === 0) return globalRegistry.get(this);
					const cl = this.clone();
					globalRegistry.add(cl, args[0]);
					return cl;
				},
				isOptional() {
					return this.safeParse(void 0).success;
				},
				isNullable() {
					return this.safeParse(null).success;
				},
				apply(fn) {
					return fn(this);
				}
			});
			Object.defineProperty(inst, "description", {
				get() {
					return globalRegistry.get(inst)?.description;
				},
				configurable: true
			});
			return inst;
		});
		/** @internal */
		const _ZodString = /*@__PURE__*/ $constructor("_ZodString", (inst, def) => {
			$ZodString.init(inst, def);
			ZodType.init(inst, def);
			inst._zod.processJSONSchema = (ctx, json, params) => stringProcessor(inst, ctx, json, params);
			const bag = inst._zod.bag;
			inst.format = bag.format ?? null;
			inst.minLength = bag.minimum ?? null;
			inst.maxLength = bag.maximum ?? null;
			_installLazyMethods(inst, "_ZodString", {
				regex(...args) {
					return this.check(/* @__PURE__ */ _regex(...args));
				},
				includes(...args) {
					return this.check(/* @__PURE__ */ _includes(...args));
				},
				startsWith(...args) {
					return this.check(/* @__PURE__ */ _startsWith(...args));
				},
				endsWith(...args) {
					return this.check(/* @__PURE__ */ _endsWith(...args));
				},
				min(...args) {
					return this.check(/* @__PURE__ */ _minLength(...args));
				},
				max(...args) {
					return this.check(/* @__PURE__ */ _maxLength(...args));
				},
				length(...args) {
					return this.check(/* @__PURE__ */ _length(...args));
				},
				nonempty(...args) {
					return this.check(/* @__PURE__ */ _minLength(1, ...args));
				},
				lowercase(params) {
					return this.check(/* @__PURE__ */ _lowercase(params));
				},
				uppercase(params) {
					return this.check(/* @__PURE__ */ _uppercase(params));
				},
				trim() {
					return this.check(/* @__PURE__ */ _trim());
				},
				normalize(...args) {
					return this.check(/* @__PURE__ */ _normalize(...args));
				},
				toLowerCase() {
					return this.check(/* @__PURE__ */ _toLowerCase());
				},
				toUpperCase() {
					return this.check(/* @__PURE__ */ _toUpperCase());
				},
				slugify() {
					return this.check(/* @__PURE__ */ _slugify());
				}
			});
		});
		const ZodString = /*@__PURE__*/ $constructor("ZodString", (inst, def) => {
			$ZodString.init(inst, def);
			_ZodString.init(inst, def);
			inst.email = (params) => inst.check(/* @__PURE__ */ _email(ZodEmail, params));
			inst.url = (params) => inst.check(/* @__PURE__ */ _url(ZodURL, params));
			inst.jwt = (params) => inst.check(/* @__PURE__ */ _jwt(ZodJWT, params));
			inst.emoji = (params) => inst.check(/* @__PURE__ */ _emoji(ZodEmoji, params));
			inst.guid = (params) => inst.check(/* @__PURE__ */ _guid(ZodGUID, params));
			inst.uuid = (params) => inst.check(/* @__PURE__ */ _uuid(ZodUUID, params));
			inst.uuidv4 = (params) => inst.check(/* @__PURE__ */ _uuidv4(ZodUUID, params));
			inst.uuidv6 = (params) => inst.check(/* @__PURE__ */ _uuidv6(ZodUUID, params));
			inst.uuidv7 = (params) => inst.check(/* @__PURE__ */ _uuidv7(ZodUUID, params));
			inst.nanoid = (params) => inst.check(/* @__PURE__ */ _nanoid(ZodNanoID, params));
			inst.guid = (params) => inst.check(/* @__PURE__ */ _guid(ZodGUID, params));
			inst.cuid = (params) => inst.check(/* @__PURE__ */ _cuid(ZodCUID, params));
			inst.cuid2 = (params) => inst.check(/* @__PURE__ */ _cuid2(ZodCUID2, params));
			inst.ulid = (params) => inst.check(/* @__PURE__ */ _ulid(ZodULID, params));
			inst.base64 = (params) => inst.check(/* @__PURE__ */ _base64(ZodBase64, params));
			inst.base64url = (params) => inst.check(/* @__PURE__ */ _base64url(ZodBase64URL, params));
			inst.xid = (params) => inst.check(/* @__PURE__ */ _xid(ZodXID, params));
			inst.ksuid = (params) => inst.check(/* @__PURE__ */ _ksuid(ZodKSUID, params));
			inst.ipv4 = (params) => inst.check(/* @__PURE__ */ _ipv4(ZodIPv4, params));
			inst.ipv6 = (params) => inst.check(/* @__PURE__ */ _ipv6(ZodIPv6, params));
			inst.cidrv4 = (params) => inst.check(/* @__PURE__ */ _cidrv4(ZodCIDRv4, params));
			inst.cidrv6 = (params) => inst.check(/* @__PURE__ */ _cidrv6(ZodCIDRv6, params));
			inst.e164 = (params) => inst.check(/* @__PURE__ */ _e164(ZodE164, params));
			inst.datetime = (params) => inst.check(datetime(params));
			inst.date = (params) => inst.check(date(params));
			inst.time = (params) => inst.check(time(params));
			inst.duration = (params) => inst.check(duration(params));
		});
		function string(params) {
			return /* @__PURE__ */ _string(ZodString, params);
		}
		const ZodStringFormat = /*@__PURE__*/ $constructor("ZodStringFormat", (inst, def) => {
			$ZodStringFormat.init(inst, def);
			_ZodString.init(inst, def);
		});
		const ZodEmail = /*@__PURE__*/ $constructor("ZodEmail", (inst, def) => {
			$ZodEmail.init(inst, def);
			ZodStringFormat.init(inst, def);
		});
		const ZodGUID = /*@__PURE__*/ $constructor("ZodGUID", (inst, def) => {
			$ZodGUID.init(inst, def);
			ZodStringFormat.init(inst, def);
		});
		const ZodUUID = /*@__PURE__*/ $constructor("ZodUUID", (inst, def) => {
			$ZodUUID.init(inst, def);
			ZodStringFormat.init(inst, def);
		});
		const ZodURL = /*@__PURE__*/ $constructor("ZodURL", (inst, def) => {
			$ZodURL.init(inst, def);
			ZodStringFormat.init(inst, def);
		});
		const ZodEmoji = /*@__PURE__*/ $constructor("ZodEmoji", (inst, def) => {
			$ZodEmoji.init(inst, def);
			ZodStringFormat.init(inst, def);
		});
		const ZodNanoID = /*@__PURE__*/ $constructor("ZodNanoID", (inst, def) => {
			$ZodNanoID.init(inst, def);
			ZodStringFormat.init(inst, def);
		});
		/**
		* @deprecated CUID v1 is deprecated by its authors due to information leakage
		* (timestamps embedded in the id). Use {@link ZodCUID2} instead.
		* See https://github.com/paralleldrive/cuid.
		*/
		const ZodCUID = /*@__PURE__*/ $constructor("ZodCUID", (inst, def) => {
			$ZodCUID.init(inst, def);
			ZodStringFormat.init(inst, def);
		});
		const ZodCUID2 = /*@__PURE__*/ $constructor("ZodCUID2", (inst, def) => {
			$ZodCUID2.init(inst, def);
			ZodStringFormat.init(inst, def);
		});
		const ZodULID = /*@__PURE__*/ $constructor("ZodULID", (inst, def) => {
			$ZodULID.init(inst, def);
			ZodStringFormat.init(inst, def);
		});
		const ZodXID = /*@__PURE__*/ $constructor("ZodXID", (inst, def) => {
			$ZodXID.init(inst, def);
			ZodStringFormat.init(inst, def);
		});
		const ZodKSUID = /*@__PURE__*/ $constructor("ZodKSUID", (inst, def) => {
			$ZodKSUID.init(inst, def);
			ZodStringFormat.init(inst, def);
		});
		const ZodIPv4 = /*@__PURE__*/ $constructor("ZodIPv4", (inst, def) => {
			$ZodIPv4.init(inst, def);
			ZodStringFormat.init(inst, def);
		});
		const ZodIPv6 = /*@__PURE__*/ $constructor("ZodIPv6", (inst, def) => {
			$ZodIPv6.init(inst, def);
			ZodStringFormat.init(inst, def);
		});
		const ZodCIDRv4 = /*@__PURE__*/ $constructor("ZodCIDRv4", (inst, def) => {
			$ZodCIDRv4.init(inst, def);
			ZodStringFormat.init(inst, def);
		});
		const ZodCIDRv6 = /*@__PURE__*/ $constructor("ZodCIDRv6", (inst, def) => {
			$ZodCIDRv6.init(inst, def);
			ZodStringFormat.init(inst, def);
		});
		const ZodBase64 = /*@__PURE__*/ $constructor("ZodBase64", (inst, def) => {
			$ZodBase64.init(inst, def);
			ZodStringFormat.init(inst, def);
		});
		const ZodBase64URL = /*@__PURE__*/ $constructor("ZodBase64URL", (inst, def) => {
			$ZodBase64URL.init(inst, def);
			ZodStringFormat.init(inst, def);
		});
		const ZodE164 = /*@__PURE__*/ $constructor("ZodE164", (inst, def) => {
			$ZodE164.init(inst, def);
			ZodStringFormat.init(inst, def);
		});
		const ZodJWT = /*@__PURE__*/ $constructor("ZodJWT", (inst, def) => {
			$ZodJWT.init(inst, def);
			ZodStringFormat.init(inst, def);
		});
		const ZodNumber = /*@__PURE__*/ $constructor("ZodNumber", (inst, def) => {
			$ZodNumber.init(inst, def);
			ZodType.init(inst, def);
			inst._zod.processJSONSchema = (ctx, json, params) => numberProcessor(inst, ctx, json, params);
			_installLazyMethods(inst, "ZodNumber", {
				gt(value, params) {
					return this.check(/* @__PURE__ */ _gt(value, params));
				},
				gte(value, params) {
					return this.check(/* @__PURE__ */ _gte(value, params));
				},
				min(value, params) {
					return this.check(/* @__PURE__ */ _gte(value, params));
				},
				lt(value, params) {
					return this.check(/* @__PURE__ */ _lt(value, params));
				},
				lte(value, params) {
					return this.check(/* @__PURE__ */ _lte(value, params));
				},
				max(value, params) {
					return this.check(/* @__PURE__ */ _lte(value, params));
				},
				int(params) {
					return this.check(int(params));
				},
				safe(params) {
					return this.check(int(params));
				},
				positive(params) {
					return this.check(/* @__PURE__ */ _gt(0, params));
				},
				nonnegative(params) {
					return this.check(/* @__PURE__ */ _gte(0, params));
				},
				negative(params) {
					return this.check(/* @__PURE__ */ _lt(0, params));
				},
				nonpositive(params) {
					return this.check(/* @__PURE__ */ _lte(0, params));
				},
				multipleOf(value, params) {
					return this.check(/* @__PURE__ */ _multipleOf(value, params));
				},
				step(value, params) {
					return this.check(/* @__PURE__ */ _multipleOf(value, params));
				},
				finite() {
					return this;
				}
			});
			const bag = inst._zod.bag;
			inst.minValue = Math.max(bag.minimum ?? Number.NEGATIVE_INFINITY, bag.exclusiveMinimum ?? Number.NEGATIVE_INFINITY) ?? null;
			inst.maxValue = Math.min(bag.maximum ?? Number.POSITIVE_INFINITY, bag.exclusiveMaximum ?? Number.POSITIVE_INFINITY) ?? null;
			inst.isInt = (bag.format ?? "").includes("int") || Number.isSafeInteger(bag.multipleOf ?? .5);
			inst.isFinite = true;
			inst.format = bag.format ?? null;
		});
		function number(params) {
			return /* @__PURE__ */ _number(ZodNumber, params);
		}
		const ZodNumberFormat = /*@__PURE__*/ $constructor("ZodNumberFormat", (inst, def) => {
			$ZodNumberFormat.init(inst, def);
			ZodNumber.init(inst, def);
		});
		function int(params) {
			return /* @__PURE__ */ _int(ZodNumberFormat, params);
		}
		const ZodBoolean = /*@__PURE__*/ $constructor("ZodBoolean", (inst, def) => {
			$ZodBoolean.init(inst, def);
			ZodType.init(inst, def);
			inst._zod.processJSONSchema = (ctx, json, params) => booleanProcessor(inst, ctx, json, params);
		});
		function boolean(params) {
			return /* @__PURE__ */ _boolean(ZodBoolean, params);
		}
		const ZodUndefined = /*@__PURE__*/ $constructor("ZodUndefined", (inst, def) => {
			$ZodUndefined.init(inst, def);
			ZodType.init(inst, def);
			inst._zod.processJSONSchema = (ctx, json, params) => undefinedProcessor(inst, ctx, json, params);
		});
		function _undefined(params) {
			return /* @__PURE__ */ _undefined$1(ZodUndefined, params);
		}
		const ZodUnknown = /*@__PURE__*/ $constructor("ZodUnknown", (inst, def) => {
			$ZodUnknown.init(inst, def);
			ZodType.init(inst, def);
			inst._zod.processJSONSchema = (ctx, json, params) => void 0;
		});
		function unknown() {
			return /* @__PURE__ */ _unknown(ZodUnknown);
		}
		const ZodNever = /*@__PURE__*/ $constructor("ZodNever", (inst, def) => {
			$ZodNever.init(inst, def);
			ZodType.init(inst, def);
			inst._zod.processJSONSchema = (ctx, json, params) => neverProcessor(inst, ctx, json, params);
		});
		function never(params) {
			return /* @__PURE__ */ _never(ZodNever, params);
		}
		const ZodVoid = /*@__PURE__*/ $constructor("ZodVoid", (inst, def) => {
			$ZodVoid.init(inst, def);
			ZodType.init(inst, def);
			inst._zod.processJSONSchema = (ctx, json, params) => voidProcessor(inst, ctx, json, params);
		});
		function _void(params) {
			return /* @__PURE__ */ _void$1(ZodVoid, params);
		}
		const ZodArray = /*@__PURE__*/ $constructor("ZodArray", (inst, def) => {
			$ZodArray.init(inst, def);
			ZodType.init(inst, def);
			inst._zod.processJSONSchema = (ctx, json, params) => arrayProcessor(inst, ctx, json, params);
			inst.element = def.element;
			_installLazyMethods(inst, "ZodArray", {
				min(n, params) {
					return this.check(/* @__PURE__ */ _minLength(n, params));
				},
				nonempty(params) {
					return this.check(/* @__PURE__ */ _minLength(1, params));
				},
				max(n, params) {
					return this.check(/* @__PURE__ */ _maxLength(n, params));
				},
				length(n, params) {
					return this.check(/* @__PURE__ */ _length(n, params));
				},
				unwrap() {
					return this.element;
				}
			});
		});
		function array(element, params) {
			return /* @__PURE__ */ _array(ZodArray, element, params);
		}
		const ZodObject = /*@__PURE__*/ $constructor("ZodObject", (inst, def) => {
			$ZodObjectJIT.init(inst, def);
			ZodType.init(inst, def);
			inst._zod.processJSONSchema = (ctx, json, params) => objectProcessor(inst, ctx, json, params);
			defineLazy(inst, "shape", () => {
				return def.shape;
			});
			_installLazyMethods(inst, "ZodObject", {
				keyof() {
					return _enum(Object.keys(this._zod.def.shape));
				},
				catchall(catchall) {
					return this.clone({
						...this._zod.def,
						catchall
					});
				},
				passthrough() {
					return this.clone({
						...this._zod.def,
						catchall: unknown()
					});
				},
				loose() {
					return this.clone({
						...this._zod.def,
						catchall: unknown()
					});
				},
				strict() {
					return this.clone({
						...this._zod.def,
						catchall: never()
					});
				},
				strip() {
					return this.clone({
						...this._zod.def,
						catchall: void 0
					});
				},
				extend(incoming) {
					return extend(this, incoming);
				},
				safeExtend(incoming) {
					return safeExtend(this, incoming);
				},
				merge(other) {
					return merge(this, other);
				},
				pick(mask) {
					return pick(this, mask);
				},
				omit(mask) {
					return omit(this, mask);
				},
				partial(...args) {
					return partial(ZodOptional, this, args[0]);
				},
				required(...args) {
					return required(ZodNonOptional, this, args[0]);
				}
			});
		});
		function object(shape, params) {
			return new ZodObject({
				type: "object",
				shape: shape ?? {},
				...normalizeParams(params)
			});
		}
		const ZodUnion = /*@__PURE__*/ $constructor("ZodUnion", (inst, def) => {
			$ZodUnion.init(inst, def);
			ZodType.init(inst, def);
			inst._zod.processJSONSchema = (ctx, json, params) => unionProcessor(inst, ctx, json, params);
			inst.options = def.options;
		});
		function union(options, params) {
			return new ZodUnion({
				type: "union",
				options,
				...normalizeParams(params)
			});
		}
		const ZodIntersection = /*@__PURE__*/ $constructor("ZodIntersection", (inst, def) => {
			$ZodIntersection.init(inst, def);
			ZodType.init(inst, def);
			inst._zod.processJSONSchema = (ctx, json, params) => intersectionProcessor(inst, ctx, json, params);
		});
		function intersection(left, right) {
			return new ZodIntersection({
				type: "intersection",
				left,
				right
			});
		}
		const ZodRecord = /*@__PURE__*/ $constructor("ZodRecord", (inst, def) => {
			$ZodRecord.init(inst, def);
			ZodType.init(inst, def);
			inst._zod.processJSONSchema = (ctx, json, params) => recordProcessor(inst, ctx, json, params);
			inst.keyType = def.keyType;
			inst.valueType = def.valueType;
		});
		function record(keyType, valueType, params) {
			if (!valueType || !valueType._zod) return new ZodRecord({
				type: "record",
				keyType: string(),
				valueType: keyType,
				...normalizeParams(valueType)
			});
			return new ZodRecord({
				type: "record",
				keyType,
				valueType,
				...normalizeParams(params)
			});
		}
		const ZodEnum = /*@__PURE__*/ $constructor("ZodEnum", (inst, def) => {
			$ZodEnum.init(inst, def);
			ZodType.init(inst, def);
			inst._zod.processJSONSchema = (ctx, json, params) => enumProcessor(inst, ctx, json, params);
			inst.enum = def.entries;
			inst.options = Object.values(def.entries);
			const keys = new Set(Object.keys(def.entries));
			inst.extract = (values, params) => {
				const newEntries = {};
				for (const value of values) if (keys.has(value)) newEntries[value] = def.entries[value];
				else throw new Error(`Key ${value} not found in enum`);
				return new ZodEnum({
					...def,
					checks: [],
					...normalizeParams(params),
					entries: newEntries
				});
			};
			inst.exclude = (values, params) => {
				const newEntries = { ...def.entries };
				for (const value of values) if (keys.has(value)) delete newEntries[value];
				else throw new Error(`Key ${value} not found in enum`);
				return new ZodEnum({
					...def,
					checks: [],
					...normalizeParams(params),
					entries: newEntries
				});
			};
		});
		function _enum(values, params) {
			return new ZodEnum({
				type: "enum",
				entries: Array.isArray(values) ? Object.fromEntries(values.map((v) => [v, v])) : values,
				...normalizeParams(params)
			});
		}
		const ZodLiteral = /*@__PURE__*/ $constructor("ZodLiteral", (inst, def) => {
			$ZodLiteral.init(inst, def);
			ZodType.init(inst, def);
			inst._zod.processJSONSchema = (ctx, json, params) => literalProcessor(inst, ctx, json, params);
			inst.values = new Set(def.values);
			Object.defineProperty(inst, "value", { get() {
				if (def.values.length > 1) throw new Error("This schema contains multiple valid literal values. Use `.values` instead.");
				return def.values[0];
			} });
		});
		function literal(value, params) {
			return new ZodLiteral({
				type: "literal",
				values: Array.isArray(value) ? value : [value],
				...normalizeParams(params)
			});
		}
		const ZodTransform = /*@__PURE__*/ $constructor("ZodTransform", (inst, def) => {
			$ZodTransform.init(inst, def);
			ZodType.init(inst, def);
			inst._zod.processJSONSchema = (ctx, json, params) => transformProcessor(inst, ctx, json, params);
			inst._zod.parse = (payload, _ctx) => {
				if (_ctx.direction === "backward") throw new $ZodEncodeError(inst.constructor.name);
				payload.addIssue = (issue$1) => {
					if (typeof issue$1 === "string") payload.issues.push(issue(issue$1, payload.value, def));
					else {
						const _issue = issue$1;
						if (_issue.fatal) _issue.continue = false;
						_issue.code ?? (_issue.code = "custom");
						_issue.input ?? (_issue.input = payload.value);
						_issue.inst ?? (_issue.inst = inst);
						payload.issues.push(issue(_issue));
					}
				};
				const output = def.transform(payload.value, payload);
				if (output instanceof Promise) return output.then((output) => {
					payload.value = output;
					payload.fallback = true;
					return payload;
				});
				payload.value = output;
				payload.fallback = true;
				return payload;
			};
		});
		function transform(fn) {
			return new ZodTransform({
				type: "transform",
				transform: fn
			});
		}
		const ZodOptional = /*@__PURE__*/ $constructor("ZodOptional", (inst, def) => {
			$ZodOptional.init(inst, def);
			ZodType.init(inst, def);
			inst._zod.processJSONSchema = (ctx, json, params) => optionalProcessor(inst, ctx, json, params);
			inst.unwrap = () => inst._zod.def.innerType;
		});
		function optional(innerType) {
			return new ZodOptional({
				type: "optional",
				innerType
			});
		}
		const ZodExactOptional = /*@__PURE__*/ $constructor("ZodExactOptional", (inst, def) => {
			$ZodExactOptional.init(inst, def);
			ZodType.init(inst, def);
			inst._zod.processJSONSchema = (ctx, json, params) => optionalProcessor(inst, ctx, json, params);
			inst.unwrap = () => inst._zod.def.innerType;
		});
		function exactOptional(innerType) {
			return new ZodExactOptional({
				type: "optional",
				innerType
			});
		}
		const ZodNullable = /*@__PURE__*/ $constructor("ZodNullable", (inst, def) => {
			$ZodNullable.init(inst, def);
			ZodType.init(inst, def);
			inst._zod.processJSONSchema = (ctx, json, params) => nullableProcessor(inst, ctx, json, params);
			inst.unwrap = () => inst._zod.def.innerType;
		});
		function nullable(innerType) {
			return new ZodNullable({
				type: "nullable",
				innerType
			});
		}
		const ZodDefault = /*@__PURE__*/ $constructor("ZodDefault", (inst, def) => {
			$ZodDefault.init(inst, def);
			ZodType.init(inst, def);
			inst._zod.processJSONSchema = (ctx, json, params) => defaultProcessor(inst, ctx, json, params);
			inst.unwrap = () => inst._zod.def.innerType;
			inst.removeDefault = inst.unwrap;
		});
		function _default(innerType, defaultValue) {
			return new ZodDefault({
				type: "default",
				innerType,
				get defaultValue() {
					return typeof defaultValue === "function" ? defaultValue() : shallowClone(defaultValue);
				}
			});
		}
		const ZodPrefault = /*@__PURE__*/ $constructor("ZodPrefault", (inst, def) => {
			$ZodPrefault.init(inst, def);
			ZodType.init(inst, def);
			inst._zod.processJSONSchema = (ctx, json, params) => prefaultProcessor(inst, ctx, json, params);
			inst.unwrap = () => inst._zod.def.innerType;
		});
		function prefault(innerType, defaultValue) {
			return new ZodPrefault({
				type: "prefault",
				innerType,
				get defaultValue() {
					return typeof defaultValue === "function" ? defaultValue() : shallowClone(defaultValue);
				}
			});
		}
		const ZodNonOptional = /*@__PURE__*/ $constructor("ZodNonOptional", (inst, def) => {
			$ZodNonOptional.init(inst, def);
			ZodType.init(inst, def);
			inst._zod.processJSONSchema = (ctx, json, params) => nonoptionalProcessor(inst, ctx, json, params);
			inst.unwrap = () => inst._zod.def.innerType;
		});
		function nonoptional(innerType, params) {
			return new ZodNonOptional({
				type: "nonoptional",
				innerType,
				...normalizeParams(params)
			});
		}
		const ZodCatch = /*@__PURE__*/ $constructor("ZodCatch", (inst, def) => {
			$ZodCatch.init(inst, def);
			ZodType.init(inst, def);
			inst._zod.processJSONSchema = (ctx, json, params) => catchProcessor(inst, ctx, json, params);
			inst.unwrap = () => inst._zod.def.innerType;
			inst.removeCatch = inst.unwrap;
		});
		function _catch(innerType, catchValue) {
			return new ZodCatch({
				type: "catch",
				innerType,
				catchValue: typeof catchValue === "function" ? catchValue : () => catchValue
			});
		}
		const ZodPipe = /*@__PURE__*/ $constructor("ZodPipe", (inst, def) => {
			$ZodPipe.init(inst, def);
			ZodType.init(inst, def);
			inst._zod.processJSONSchema = (ctx, json, params) => pipeProcessor(inst, ctx, json, params);
			inst.in = def.in;
			inst.out = def.out;
		});
		function pipe(in_, out) {
			return new ZodPipe({
				type: "pipe",
				in: in_,
				out
			});
		}
		const ZodReadonly = /*@__PURE__*/ $constructor("ZodReadonly", (inst, def) => {
			$ZodReadonly.init(inst, def);
			ZodType.init(inst, def);
			inst._zod.processJSONSchema = (ctx, json, params) => readonlyProcessor(inst, ctx, json, params);
			inst.unwrap = () => inst._zod.def.innerType;
		});
		function readonly(innerType) {
			return new ZodReadonly({
				type: "readonly",
				innerType
			});
		}
		const ZodLazy = /*@__PURE__*/ $constructor("ZodLazy", (inst, def) => {
			$ZodLazy.init(inst, def);
			ZodType.init(inst, def);
			inst._zod.processJSONSchema = (ctx, json, params) => lazyProcessor(inst, ctx, json, params);
			inst.unwrap = () => inst._zod.def.getter();
		});
		function lazy(getter) {
			return new ZodLazy({
				type: "lazy",
				getter
			});
		}
		const ZodCustom = /*@__PURE__*/ $constructor("ZodCustom", (inst, def) => {
			$ZodCustom.init(inst, def);
			ZodType.init(inst, def);
			inst._zod.processJSONSchema = (ctx, json, params) => customProcessor(inst, ctx, json, params);
		});
		function refine(fn, _params = {}) {
			return /* @__PURE__ */ _refine(ZodCustom, fn, _params);
		}
		function superRefine(fn, params) {
			return /* @__PURE__ */ _superRefine(fn, params);
		}
		function _instanceof(cls, params = {}) {
			const inst = new ZodCustom({
				type: "custom",
				check: "custom",
				fn: (data) => data instanceof cls,
				abort: true,
				...normalizeParams(params)
			});
			inst._zod.bag.Class = cls;
			inst._zod.check = (payload) => {
				if (!(payload.value instanceof cls)) payload.issues.push({
					code: "invalid_type",
					expected: cls.name,
					input: payload.value,
					inst,
					path: [...inst._zod.def.path ?? []]
				});
			};
			return inst;
		}
		//#endregion
		//#region ../../client/product-analytics/lib/typert.remote-client.js
		let _deepseek_ai_dsh_client_product_analytics_productAnalytics_enabled_result$schema$value;
		const _deepseek_ai_dsh_client_product_analytics_productAnalytics_enabled_result$schema = () => _deepseek_ai_dsh_client_product_analytics_productAnalytics_enabled_result$schema$value ??= boolean();
		let _deepseek_ai_dsh_client_product_analytics_productAnalytics_report_parameter_0$schema$value;
		const _deepseek_ai_dsh_client_product_analytics_productAnalytics_report_parameter_0$schema = () => _deepseek_ai_dsh_client_product_analytics_productAnalytics_report_parameter_0$schema$value ??= union([
			object({
				"eventName": literal("desktop_app_launch"),
				"attributes": record(string(), never()),
				"timestamp": number()
			}),
			object({
				"eventName": literal("auth_page_view"),
				"attributes": record(string(), never()),
				"timestamp": number()
			}),
			object({
				"eventName": literal("auth_page_click"),
				"attributes": object({ "button_name": union([literal("sign_in"), literal("api-key")]) }),
				"timestamp": number()
			}),
			object({
				"eventName": literal("api_key_save_click"),
				"attributes": record(string(), never()),
				"timestamp": number()
			}),
			object({
				"eventName": literal("onboarding_page_view"),
				"attributes": object({ "page_name": union([
					literal("onboarding_welcome"),
					literal("onboarding_recharge"),
					literal("onboarding_use_case"),
					literal("onboarding_process")
				]) }),
				"timestamp": number()
			}),
			object({
				"eventName": literal("onboarding_page_click"),
				"attributes": object({
					"page_name": union([
						literal("onboarding_welcome"),
						literal("onboarding_recharge"),
						literal("onboarding_use_case"),
						literal("onboarding_process")
					]),
					"button_name": union([
						literal("next"),
						literal("back"),
						literal("skip"),
						literal("charge"),
						literal("later"),
						literal("continue")
					]),
					"selected_content": union([
						literal("office"),
						literal("code"),
						literal("code_office"),
						literal("focus_result"),
						literal("key_detail"),
						literal("full_process")
					]).optional()
				}),
				"timestamp": number()
			}),
			object({
				"eventName": literal("onboarding_popup_view"),
				"attributes": object({ "popup_name": union([literal("skip_charge"), literal("skip_setting")]) }),
				"timestamp": number()
			}),
			object({
				"eventName": literal("onboarding_popup_click"),
				"attributes": object({
					"popup_name": union([literal("skip_charge"), literal("skip_setting")]),
					"button_name": union([
						literal("charge"),
						literal("know"),
						literal("enter"),
						literal("setting"),
						literal("close")
					])
				}),
				"timestamp": number()
			}),
			object({
				"eventName": literal("desktop_upgrade_click"),
				"attributes": record(string(), never()),
				"timestamp": number()
			}),
			object({
				"eventName": literal("desktop_upgrade_download_result"),
				"attributes": object({
					"is_success": boolean(),
					"error_reason": string().optional()
				}),
				"timestamp": number()
			}),
			object({
				"eventName": literal("desktop_upgrade_install_restart_click"),
				"attributes": record(string(), never()),
				"timestamp": number()
			}),
			object({
				"eventName": literal("send_button_click"),
				"attributes": object({
					"session_id": intersection(string(), unknown()).optional(),
					"model_name": string().optional(),
					"thinking_effort": string().optional(),
					"run_mode": union([
						literal("goal"),
						literal("plan"),
						literal("default")
					]),
					"msg_type": union([
						literal("queue"),
						literal("steer"),
						literal("default")
					])
				}),
				"timestamp": number()
			}),
			object({
				"eventName": literal("model_switch"),
				"attributes": object({
					"session_id": intersection(string(), unknown()).optional(),
					"switch_from": string(),
					"switch_to": string()
				}),
				"timestamp": number()
			}),
			object({
				"eventName": literal("thinking_level_switch"),
				"attributes": object({
					"session_id": intersection(string(), unknown()).optional(),
					"switch_from": string(),
					"switch_to": string(),
					"model_name": string()
				}),
				"timestamp": number()
			}),
			object({
				"eventName": literal("context_compression"),
				"attributes": object({
					"session_id": intersection(string(), unknown()),
					"trigger_type": union([literal("auto"), literal("manual")])
				}),
				"timestamp": number()
			}),
			object({
				"eventName": literal("branch_session_click"),
				"attributes": object({
					"session_id": intersection(string(), unknown()),
					"parent_session_id": intersection(string(), unknown()),
					"parent_message_id": intersection(string(), unknown()).optional(),
					"click_position": union([literal("footer"), literal("sidebar")])
				}),
				"timestamp": number()
			}),
			object({
				"eventName": literal("sidebar_menu_click"),
				"attributes": object({ "menu_name": union([literal("plugin"), literal("cron")]) }),
				"timestamp": number()
			}),
			object({
				"eventName": literal("plugin_toggle"),
				"attributes": object({
					"plugin_name": string(),
					"plugin_type": union([literal("plugin"), literal("bundle")]),
					"is_enabled": boolean(),
					"is_builtin": boolean()
				}),
				"timestamp": number()
			}),
			object({
				"eventName": literal("plugin_add_button_click"),
				"attributes": record(string(), never()),
				"timestamp": number()
			}),
			object({
				"eventName": literal("plugin_install_click"),
				"attributes": object({ "input_value": string() }),
				"timestamp": number()
			}),
			object({
				"eventName": literal("install_plugin_result"),
				"attributes": object({
					"input_value": string(),
					"is_success": boolean(),
					"error_reason": string().optional(),
					"duration": number(),
					"plugin_name": string().optional()
				}),
				"timestamp": number()
			}),
			object({
				"eventName": literal("confirm_uninstall_plugin"),
				"attributes": object({ "plugin_name": string() }),
				"timestamp": number()
			})
		]);
		let _deepseek_ai_dsh_client_product_analytics_productAnalytics_report_result$schema$value;
		const _deepseek_ai_dsh_client_product_analytics_productAnalytics_report_result$schema = () => _deepseek_ai_dsh_client_product_analytics_productAnalytics_report_result$schema$value ??= _void();
		let _deepseek_ai_dsh_client_product_analytics_productAnalytics_watchPolicy_result$schema$value;
		const _deepseek_ai_dsh_client_product_analytics_productAnalytics_watchPolicy_result$schema = () => _deepseek_ai_dsh_client_product_analytics_productAnalytics_watchPolicy_result$schema$value ??= boolean();
		const TYPERT_REMOTE$24 = {
			package: "@deepseek-ai/dsh-client-product-analytics",
			descriptors: [
				{
					id: "@deepseek-ai/dsh-client-product-analytics#productAnalytics/enabled",
					service: "productAnalytics",
					namespace: "productAnalytics",
					method: "enabled",
					invocation: { kind: "direct" },
					parameters: [],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-client-product-analytics#productAnalytics/enabled:result",
						create: _deepseek_ai_dsh_client_product_analytics_productAnalytics_enabled_result$schema
					},
					sourceLocation: {
						"file": "packages/client/product-analytics/src/index.ts",
						"line": 51,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-client-product-analytics#productAnalytics/report",
					service: "productAnalytics",
					namespace: "productAnalytics",
					method: "report",
					invocation: { kind: "direct" },
					parameters: [{
						name: "event",
						wire: "event",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-client-product-analytics/types#ProductEvent",
							create: _deepseek_ai_dsh_client_product_analytics_productAnalytics_report_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-client-product-analytics#productAnalytics/report:result",
						create: _deepseek_ai_dsh_client_product_analytics_productAnalytics_report_result$schema
					},
					sourceLocation: {
						"file": "packages/client/product-analytics/src/index.ts",
						"line": 82,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-client-product-analytics#productAnalytics/watchPolicy",
					service: "productAnalytics",
					namespace: "productAnalytics",
					method: "watchPolicy",
					mode: "stream",
					invocation: { kind: "direct" },
					parameters: [],
					cancellation: { parameter: "signal" },
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-client-product-analytics#productAnalytics/watchPolicy:result",
						create: _deepseek_ai_dsh_client_product_analytics_productAnalytics_watchPolicy_result$schema
					},
					sourceLocation: {
						"file": "packages/client/product-analytics/src/index.ts",
						"line": 59,
						"column": 10
					}
				}
			]
		};
		//#endregion
		//#region ../../preset/agent-preset-registry/lib/typert.remote-client.js
		let _deepseek_ai_dsh_agent_preset_registry_agentPresets_list_result$schema$value;
		const _deepseek_ai_dsh_agent_preset_registry_agentPresets_list_result$schema = () => _deepseek_ai_dsh_agent_preset_registry_agentPresets_list_result$schema$value ??= object({ "presets": array(object({
			"id": string().readonly(),
			"isDefault": boolean().readonly(),
			"name": string().readonly().optional(),
			"description": string().readonly().optional(),
			"broken": string().readonly().optional()
		})).readonly() });
		let _deepseek_ai_dsh_agent_preset_registry_agentPresets_read_parameter_0$schema$value;
		const _deepseek_ai_dsh_agent_preset_registry_agentPresets_read_parameter_0$schema = () => _deepseek_ai_dsh_agent_preset_registry_agentPresets_read_parameter_0$schema$value ??= string();
		let _deepseek_ai_dsh_agent_preset_registry_agentPresets_read_result$schema$value;
		const _deepseek_ai_dsh_agent_preset_registry_agentPresets_read_result$schema = () => _deepseek_ai_dsh_agent_preset_registry_agentPresets_read_result$schema$value ??= object({
			"agentPreset": string().readonly(),
			"content": string().readonly(),
			"name": string().readonly().optional(),
			"description": string().readonly().optional()
		});
		let _deepseek_ai_dsh_agent_preset_registry_agentPresets_select_parameter_0$schema$value;
		const _deepseek_ai_dsh_agent_preset_registry_agentPresets_select_parameter_0$schema = () => _deepseek_ai_dsh_agent_preset_registry_agentPresets_select_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_agent_preset_registry_agentPresets_select_parameter_1$schema$value;
		const _deepseek_ai_dsh_agent_preset_registry_agentPresets_select_parameter_1$schema = () => _deepseek_ai_dsh_agent_preset_registry_agentPresets_select_parameter_1$schema$value ??= string();
		let _deepseek_ai_dsh_agent_preset_registry_agentPresets_select_result$schema$value;
		const _deepseek_ai_dsh_agent_preset_registry_agentPresets_select_result$schema = () => _deepseek_ai_dsh_agent_preset_registry_agentPresets_select_result$schema$value ??= string();
		const TYPERT_REMOTE$23 = {
			package: "@deepseek-ai/dsh-agent-preset-registry",
			descriptors: [
				{
					id: "@deepseek-ai/dsh-agent-preset-registry#agentPresets/list",
					service: "agentPresets",
					namespace: "agentPresets",
					method: "list",
					implementation: "remoteExportList",
					invocation: { kind: "direct" },
					parameters: [],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-agent-preset-registry/types#AgentPresetRoster",
						create: _deepseek_ai_dsh_agent_preset_registry_agentPresets_list_result$schema
					},
					sourceLocation: {
						"file": "packages/preset/agent-preset-registry/src/index.ts",
						"line": 171,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-agent-preset-registry#agentPresets/read",
					service: "agentPresets",
					namespace: "agentPresets",
					method: "read",
					implementation: "readDocument",
					invocation: { kind: "direct" },
					parameters: [{
						name: "agentPreset",
						wire: "agentPreset",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-agent-preset-registry#agentPresets/read:agentPreset",
							create: _deepseek_ai_dsh_agent_preset_registry_agentPresets_read_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-agent-preset-registry/types#AgentPresetDocument",
						create: _deepseek_ai_dsh_agent_preset_registry_agentPresets_read_result$schema
					},
					sourceLocation: {
						"file": "packages/preset/agent-preset-registry/src/index.ts",
						"line": 194,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-agent-preset-registry#agentPresets/select",
					service: "agentPresets",
					namespace: "agentPresets",
					method: "select",
					invocation: { kind: "direct" },
					scope: {
						context: "agent",
						wire: "agentId"
					},
					parameters: [{
						name: "agent",
						wire: "agentId",
						source: "lookup",
						lookup: "agent",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
							create: _deepseek_ai_dsh_agent_preset_registry_agentPresets_select_parameter_0$schema
						}
					}, {
						name: "agentPreset",
						wire: "agentPreset",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-agent-preset-registry#agentPresets/select:agentPreset",
							create: _deepseek_ai_dsh_agent_preset_registry_agentPresets_select_parameter_1$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-agent-preset-registry#agentPresets/select:result",
						create: _deepseek_ai_dsh_agent_preset_registry_agentPresets_select_result$schema
					},
					sourceLocation: {
						"file": "packages/preset/agent-preset-registry/src/index.ts",
						"line": 319,
						"column": 9
					}
				}
			]
		};
		//#endregion
		//#region ../../interaction/user-questions/lib/typert.remote-client.js
		let _deepseek_ai_dsh_user_questions_userQuestions_answer_parameter_0$schema$value;
		const _deepseek_ai_dsh_user_questions_userQuestions_answer_parameter_0$schema = () => _deepseek_ai_dsh_user_questions_userQuestions_answer_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_user_questions_userQuestions_answer_parameter_1$schema$value;
		const _deepseek_ai_dsh_user_questions_userQuestions_answer_parameter_1$schema = () => _deepseek_ai_dsh_user_questions_userQuestions_answer_parameter_1$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_user_questions_userQuestions_answer_parameter_2$schema$value;
		const _deepseek_ai_dsh_user_questions_userQuestions_answer_parameter_2$schema = () => _deepseek_ai_dsh_user_questions_userQuestions_answer_parameter_2$schema$value ??= object({ "answers": array(object({
			"id": string(),
			"selected": array(string()),
			"custom": string().optional()
		})) });
		let _deepseek_ai_dsh_user_questions_userQuestions_answer_result$schema$value;
		const _deepseek_ai_dsh_user_questions_userQuestions_answer_result$schema = () => _deepseek_ai_dsh_user_questions_userQuestions_answer_result$schema$value ??= boolean();
		let _deepseek_ai_dsh_user_questions_userQuestions_attachWait_parameter_0$schema$value;
		const _deepseek_ai_dsh_user_questions_userQuestions_attachWait_parameter_0$schema = () => _deepseek_ai_dsh_user_questions_userQuestions_attachWait_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_user_questions_userQuestions_attachWait_parameter_1$schema$value;
		const _deepseek_ai_dsh_user_questions_userQuestions_attachWait_parameter_1$schema = () => _deepseek_ai_dsh_user_questions_userQuestions_attachWait_parameter_1$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_user_questions_userQuestions_attachWait_result$schema$value;
		const _deepseek_ai_dsh_user_questions_userQuestions_attachWait_result$schema = () => _deepseek_ai_dsh_user_questions_userQuestions_attachWait_result$schema$value ??= object({ "remainingMs": number() });
		const TYPERT_REMOTE$22 = {
			package: "@deepseek-ai/dsh-user-questions",
			descriptors: [{
				id: "@deepseek-ai/dsh-user-questions#userQuestions/answer",
				service: "userQuestions",
				namespace: "userQuestions",
				method: "answer",
				invocation: { kind: "direct" },
				scope: {
					context: "agent",
					wire: "agentId"
				},
				parameters: [
					{
						name: "agent",
						wire: "agentId",
						source: "lookup",
						lookup: "agent",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
							create: _deepseek_ai_dsh_user_questions_userQuestions_answer_parameter_0$schema
						}
					},
					{
						name: "callId",
						wire: "callId",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-llm/brand#ToolCallId",
							create: _deepseek_ai_dsh_user_questions_userQuestions_answer_parameter_1$schema
						}
					},
					{
						name: "answer",
						wire: "answer",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-user-questions/types#AskUserQuestionAnswer",
							create: _deepseek_ai_dsh_user_questions_userQuestions_answer_parameter_2$schema
						}
					}
				],
				result: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-user-questions#userQuestions/answer:result",
					create: _deepseek_ai_dsh_user_questions_userQuestions_answer_result$schema
				},
				sourceLocation: {
					"file": "packages/interaction/user-questions/src/index.ts",
					"line": 165,
					"column": 3
				}
			}, {
				id: "@deepseek-ai/dsh-user-questions#userQuestions/attachWait",
				service: "userQuestions",
				namespace: "userQuestions",
				method: "attachWait",
				mode: "stream",
				invocation: { kind: "direct" },
				scope: {
					context: "agent",
					wire: "agentId"
				},
				parameters: [{
					name: "agent",
					wire: "agentId",
					source: "lookup",
					lookup: "agent",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
						create: _deepseek_ai_dsh_user_questions_userQuestions_attachWait_parameter_0$schema
					}
				}, {
					name: "callId",
					wire: "callId",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-llm/brand#ToolCallId",
						create: _deepseek_ai_dsh_user_questions_userQuestions_attachWait_parameter_1$schema
					}
				}],
				cancellation: { parameter: "signal" },
				result: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-user-questions#userQuestions/attachWait:result",
					create: _deepseek_ai_dsh_user_questions_userQuestions_attachWait_result$schema
				},
				sourceLocation: {
					"file": "packages/interaction/user-questions/src/index.ts",
					"line": 216,
					"column": 10
				}
			}]
		};
		//#endregion
		//#region ../../interaction/commands/lib/typert.remote-client.js
		let _deepseek_ai_dsh_commands_commands_execute_parameter_0$schema$value;
		const _deepseek_ai_dsh_commands_commands_execute_parameter_0$schema = () => _deepseek_ai_dsh_commands_commands_execute_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_commands_commands_execute_parameter_1$schema$value;
		const _deepseek_ai_dsh_commands_commands_execute_parameter_1$schema = () => _deepseek_ai_dsh_commands_commands_execute_parameter_1$schema$value ??= string();
		let _deepseek_ai_dsh_commands_commands_execute_parameter_2$schema$value;
		const _deepseek_ai_dsh_commands_commands_execute_parameter_2$schema = () => _deepseek_ai_dsh_commands_commands_execute_parameter_2$schema$value ??= array(union([intersection(object({ "type": literal("image").readonly() }), object({
			"mediaType": union([
				literal("image/png"),
				literal("image/jpeg"),
				literal("image/webp"),
				literal("image/gif")
			]),
			"data": string(),
			"name": string().optional()
		})), object({
			"type": literal("file").readonly(),
			"receiptId": string().readonly()
		})]));
		let _deepseek_ai_dsh_commands_commands_execute_result$schema$value;
		const _deepseek_ai_dsh_commands_commands_execute_result$schema = () => _deepseek_ai_dsh_commands_commands_execute_result$schema$value ??= union([_undefined(), object({
			"commandId": intersection(string(), unknown()).readonly(),
			"result": union([object({
				"kind": literal("success").readonly(),
				"text": string().readonly().optional(),
				"sourceEventSeq": intersection(number(), unknown()).readonly().optional()
			}), object({
				"kind": literal("error").readonly(),
				"text": string().readonly()
			})]).readonly()
		})]);
		let _deepseek_ai_dsh_commands_commands_list_parameter_0$schema$value;
		const _deepseek_ai_dsh_commands_commands_list_parameter_0$schema = () => _deepseek_ai_dsh_commands_commands_list_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_commands_commands_list_result$schema$value;
		const _deepseek_ai_dsh_commands_commands_list_result$schema = () => _deepseek_ai_dsh_commands_commands_list_result$schema$value ??= array(object({
			"definitionId": intersection(string(), unknown()).readonly().optional(),
			"name": string().readonly(),
			"description": string().readonly(),
			"input": object({
				"hint": string().readonly(),
				"attachments": boolean().readonly().optional()
			}).readonly().optional()
		}));
		const TYPERT_REMOTE$21 = {
			package: "@deepseek-ai/dsh-commands",
			descriptors: [{
				id: "@deepseek-ai/dsh-commands#commands/execute",
				service: "commands",
				namespace: "commands",
				method: "execute",
				invocation: { kind: "direct" },
				scope: {
					context: "agent",
					wire: "agentId"
				},
				parameters: [
					{
						name: "agent",
						wire: "agentId",
						source: "lookup",
						lookup: "agent",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
							create: _deepseek_ai_dsh_commands_commands_execute_parameter_0$schema
						}
					},
					{
						name: "line",
						wire: "line",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-commands#commands/execute:line",
							create: _deepseek_ai_dsh_commands_commands_execute_parameter_1$schema
						}
					},
					{
						name: "submittedAttachments",
						wire: "submittedAttachments",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-commands#commands/execute:submittedAttachments",
							create: _deepseek_ai_dsh_commands_commands_execute_parameter_2$schema
						}
					}
				],
				cancellation: { parameter: "signal" },
				result: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-commands#commands/execute:result",
					create: _deepseek_ai_dsh_commands_commands_execute_result$schema
				},
				sourceLocation: {
					"file": "packages/interaction/commands/src/index.ts",
					"line": 361,
					"column": 9
				}
			}, {
				id: "@deepseek-ai/dsh-commands#commands/list",
				service: "commands",
				namespace: "commands",
				method: "list",
				invocation: { kind: "direct" },
				scope: {
					context: "agent",
					wire: "agentId"
				},
				parameters: [{
					name: "agent",
					wire: "agentId",
					source: "lookup",
					lookup: "agent",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
						create: _deepseek_ai_dsh_commands_commands_list_parameter_0$schema
					}
				}],
				result: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-commands#commands/list:result",
					create: _deepseek_ai_dsh_commands_commands_list_result$schema
				},
				sourceLocation: {
					"file": "packages/interaction/commands/src/index.ts",
					"line": 315,
					"column": 3
				}
			}]
		};
		//#endregion
		//#region ../account-controller/lib/typert.remote-client.js
		let _deepseek_ai_dsh_api_account_controller_account_ackBonusNotified_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_account_controller_account_ackBonusNotified_parameter_0$schema = () => _deepseek_ai_dsh_api_account_controller_account_ackBonusNotified_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_api_account_controller_account_ackBonusNotified_parameter_1$schema$value;
		const _deepseek_ai_dsh_api_account_controller_account_ackBonusNotified_parameter_1$schema = () => _deepseek_ai_dsh_api_account_controller_account_ackBonusNotified_parameter_1$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_api_account_controller_account_ackBonusNotified_parameter_2$schema$value;
		const _deepseek_ai_dsh_api_account_controller_account_ackBonusNotified_parameter_2$schema = () => _deepseek_ai_dsh_api_account_controller_account_ackBonusNotified_parameter_2$schema$value ??= object({
			"version": string().readonly(),
			"locale": string().readonly(),
			"timezoneOffsetSeconds": number().readonly()
		});
		let _deepseek_ai_dsh_api_account_controller_account_ackBonusNotified_result$schema$value;
		const _deepseek_ai_dsh_api_account_controller_account_ackBonusNotified_result$schema = () => _deepseek_ai_dsh_api_account_controller_account_ackBonusNotified_result$schema$value ??= boolean();
		let _deepseek_ai_dsh_api_account_controller_account_cancelSignIn_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_account_controller_account_cancelSignIn_parameter_0$schema = () => _deepseek_ai_dsh_api_account_controller_account_cancelSignIn_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_api_account_controller_account_cancelSignIn_result$schema$value;
		const _deepseek_ai_dsh_api_account_controller_account_cancelSignIn_result$schema = () => _deepseek_ai_dsh_api_account_controller_account_cancelSignIn_result$schema$value ??= object({
			"status": union([literal("signed-out"), literal("credential-stored")]).readonly(),
			"links": object({
				"usageUrl": string().readonly(),
				"topUpUrl": string().readonly()
			}).readonly(),
			"attempt": union([literal(null), object({
				"id": intersection(string(), unknown()).readonly(),
				"phase": union([
					literal("initializing"),
					literal("waiting-browser"),
					literal("exchanging"),
					literal("committing"),
					literal("succeeded"),
					literal("cancelled"),
					literal("expired"),
					literal("failed")
				]).readonly(),
				"authorizeUrl": string().readonly().optional(),
				"expiresAt": number().readonly().optional(),
				"errorCode": union([
					literal("expired"),
					literal("network"),
					literal("protocol"),
					literal("storage")
				]).readonly().optional()
			})]).readonly()
		});
		let _deepseek_ai_dsh_api_account_controller_account_getBalance_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_account_controller_account_getBalance_parameter_0$schema = () => _deepseek_ai_dsh_api_account_controller_account_getBalance_parameter_0$schema$value ??= object({
			"version": string().readonly(),
			"locale": string().readonly(),
			"timezoneOffsetSeconds": number().readonly()
		});
		let _deepseek_ai_dsh_api_account_controller_account_getBalance_result$schema$value;
		const _deepseek_ai_dsh_api_account_controller_account_getBalance_result$schema = () => _deepseek_ai_dsh_api_account_controller_account_getBalance_result$schema$value ??= union([
			literal(null),
			object({
				"status": literal("ready").readonly(),
				"value": array(object({
					"currency": union([literal("CNY"), literal("USD")]).readonly(),
					"balance": string().readonly()
				})).readonly(),
				"bonusWallets": array(object({
					"currency": union([literal("CNY"), literal("USD")]).readonly(),
					"balance": string().readonly()
				})).readonly()
			}),
			object({ "status": literal("failed").readonly() })
		]);
		let _deepseek_ai_dsh_api_account_controller_account_getProfile_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_account_controller_account_getProfile_parameter_0$schema = () => _deepseek_ai_dsh_api_account_controller_account_getProfile_parameter_0$schema$value ??= object({
			"version": string().readonly(),
			"locale": string().readonly(),
			"timezoneOffsetSeconds": number().readonly()
		});
		let _deepseek_ai_dsh_api_account_controller_account_getProfile_result$schema$value;
		const _deepseek_ai_dsh_api_account_controller_account_getProfile_result$schema = () => _deepseek_ai_dsh_api_account_controller_account_getProfile_result$schema$value ??= union([
			literal(null),
			object({
				"status": literal("ready").readonly(),
				"value": object({
					"id": union([literal(null), intersection(string(), unknown())]).readonly(),
					"name": union([literal(null), string()]).readonly(),
					"contact": union([literal(null), string()]).readonly(),
					"avatarUrl": union([literal(null), string()]).readonly().optional()
				}).readonly()
			}),
			object({ "status": literal("failed").readonly() })
		]);
		let _deepseek_ai_dsh_api_account_controller_account_getState_result$schema$value;
		const _deepseek_ai_dsh_api_account_controller_account_getState_result$schema = () => _deepseek_ai_dsh_api_account_controller_account_getState_result$schema$value ??= object({
			"status": union([literal("signed-out"), literal("credential-stored")]).readonly(),
			"links": object({
				"usageUrl": string().readonly(),
				"topUpUrl": string().readonly()
			}).readonly(),
			"attempt": union([literal(null), object({
				"id": intersection(string(), unknown()).readonly(),
				"phase": union([
					literal("initializing"),
					literal("waiting-browser"),
					literal("exchanging"),
					literal("committing"),
					literal("succeeded"),
					literal("cancelled"),
					literal("expired"),
					literal("failed")
				]).readonly(),
				"authorizeUrl": string().readonly().optional(),
				"expiresAt": number().readonly().optional(),
				"errorCode": union([
					literal("expired"),
					literal("network"),
					literal("protocol"),
					literal("storage")
				]).readonly().optional()
			})]).readonly()
		});
		let _deepseek_ai_dsh_api_account_controller_account_getUnnotifiedBonuses_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_account_controller_account_getUnnotifiedBonuses_parameter_0$schema = () => _deepseek_ai_dsh_api_account_controller_account_getUnnotifiedBonuses_parameter_0$schema$value ??= object({
			"version": string().readonly(),
			"locale": string().readonly(),
			"timezoneOffsetSeconds": number().readonly()
		});
		let _deepseek_ai_dsh_api_account_controller_account_getUnnotifiedBonuses_result$schema$value;
		const _deepseek_ai_dsh_api_account_controller_account_getUnnotifiedBonuses_result$schema = () => _deepseek_ai_dsh_api_account_controller_account_getUnnotifiedBonuses_result$schema$value ??= union([literal(null), object({
			"accountId": intersection(string(), unknown()).readonly(),
			"bonuses": array(object({
				"orderId": intersection(string(), unknown()).readonly(),
				"campaign": string().readonly(),
				"amount": string().readonly(),
				"currency": union([literal("CNY"), literal("USD")]).readonly(),
				"grantedAt": string().readonly(),
				"expiresAt": string().readonly(),
				"message": string().readonly()
			})).readonly()
		})]);
		let _deepseek_ai_dsh_api_account_controller_account_hasRunningAccountTasks_result$schema$value;
		const _deepseek_ai_dsh_api_account_controller_account_hasRunningAccountTasks_result$schema = () => _deepseek_ai_dsh_api_account_controller_account_hasRunningAccountTasks_result$schema$value ??= boolean();
		let _deepseek_ai_dsh_api_account_controller_account_signOut_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_account_controller_account_signOut_parameter_0$schema = () => _deepseek_ai_dsh_api_account_controller_account_signOut_parameter_0$schema$value ??= object({
			"version": string().readonly(),
			"locale": string().readonly(),
			"timezoneOffsetSeconds": number().readonly()
		});
		let _deepseek_ai_dsh_api_account_controller_account_signOut_result$schema$value;
		const _deepseek_ai_dsh_api_account_controller_account_signOut_result$schema = () => _deepseek_ai_dsh_api_account_controller_account_signOut_result$schema$value ??= object({
			"status": union([literal("signed-out"), literal("credential-stored")]).readonly(),
			"links": object({
				"usageUrl": string().readonly(),
				"topUpUrl": string().readonly()
			}).readonly(),
			"attempt": union([literal(null), object({
				"id": intersection(string(), unknown()).readonly(),
				"phase": union([
					literal("initializing"),
					literal("waiting-browser"),
					literal("exchanging"),
					literal("committing"),
					literal("succeeded"),
					literal("cancelled"),
					literal("expired"),
					literal("failed")
				]).readonly(),
				"authorizeUrl": string().readonly().optional(),
				"expiresAt": number().readonly().optional(),
				"errorCode": union([
					literal("expired"),
					literal("network"),
					literal("protocol"),
					literal("storage")
				]).readonly().optional()
			})]).readonly()
		});
		let _deepseek_ai_dsh_api_account_controller_account_startSignIn_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_account_controller_account_startSignIn_parameter_0$schema = () => _deepseek_ai_dsh_api_account_controller_account_startSignIn_parameter_0$schema$value ??= object({
			"version": string().readonly(),
			"locale": string().readonly(),
			"timezoneOffsetSeconds": number().readonly()
		});
		let _deepseek_ai_dsh_api_account_controller_account_startSignIn_parameter_1$schema$value;
		const _deepseek_ai_dsh_api_account_controller_account_startSignIn_parameter_1$schema = () => _deepseek_ai_dsh_api_account_controller_account_startSignIn_parameter_1$schema$value ??= string();
		let _deepseek_ai_dsh_api_account_controller_account_startSignIn_parameter_2$schema$value;
		const _deepseek_ai_dsh_api_account_controller_account_startSignIn_parameter_2$schema = () => _deepseek_ai_dsh_api_account_controller_account_startSignIn_parameter_2$schema$value ??= union([literal("web"), literal("desktop")]);
		let _deepseek_ai_dsh_api_account_controller_account_startSignIn_result$schema$value;
		const _deepseek_ai_dsh_api_account_controller_account_startSignIn_result$schema = () => _deepseek_ai_dsh_api_account_controller_account_startSignIn_result$schema$value ??= object({
			"status": union([literal("signed-out"), literal("credential-stored")]).readonly(),
			"links": object({
				"usageUrl": string().readonly(),
				"topUpUrl": string().readonly()
			}).readonly(),
			"attempt": union([literal(null), object({
				"id": intersection(string(), unknown()).readonly(),
				"phase": union([
					literal("initializing"),
					literal("waiting-browser"),
					literal("exchanging"),
					literal("committing"),
					literal("succeeded"),
					literal("cancelled"),
					literal("expired"),
					literal("failed")
				]).readonly(),
				"authorizeUrl": string().readonly().optional(),
				"expiresAt": number().readonly().optional(),
				"errorCode": union([
					literal("expired"),
					literal("network"),
					literal("protocol"),
					literal("storage")
				]).readonly().optional()
			})]).readonly()
		});
		let _deepseek_ai_dsh_api_account_controller_account_watch_result$schema$value;
		const _deepseek_ai_dsh_api_account_controller_account_watch_result$schema = () => _deepseek_ai_dsh_api_account_controller_account_watch_result$schema$value ??= object({
			"status": union([literal("signed-out"), literal("credential-stored")]).readonly(),
			"links": object({
				"usageUrl": string().readonly(),
				"topUpUrl": string().readonly()
			}).readonly(),
			"attempt": union([literal(null), object({
				"id": intersection(string(), unknown()).readonly(),
				"phase": union([
					literal("initializing"),
					literal("waiting-browser"),
					literal("exchanging"),
					literal("committing"),
					literal("succeeded"),
					literal("cancelled"),
					literal("expired"),
					literal("failed")
				]).readonly(),
				"authorizeUrl": string().readonly().optional(),
				"expiresAt": number().readonly().optional(),
				"errorCode": union([
					literal("expired"),
					literal("network"),
					literal("protocol"),
					literal("storage")
				]).readonly().optional()
			})]).readonly()
		});
		let _deepseek_ai_dsh_api_account_controller_account_watchExpiry_result$schema$value;
		const _deepseek_ai_dsh_api_account_controller_account_watchExpiry_result$schema = () => _deepseek_ai_dsh_api_account_controller_account_watchExpiry_result$schema$value ??= literal("session-expired");
		const TYPERT_REMOTE$20 = {
			package: "@deepseek-ai/dsh-api-account-controller",
			descriptors: [
				{
					id: "@deepseek-ai/dsh-api-account-controller#account/ackBonusNotified",
					service: "accountController",
					namespace: "account",
					method: "ackBonusNotified",
					invocation: { kind: "direct" },
					parameters: [
						{
							name: "accountId",
							wire: "accountId",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-deepseek-account/types#AccountUserId",
								create: _deepseek_ai_dsh_api_account_controller_account_ackBonusNotified_parameter_0$schema
							}
						},
						{
							name: "orderId",
							wire: "orderId",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-deepseek-account/types#AccountBonusOrderId",
								create: _deepseek_ai_dsh_api_account_controller_account_ackBonusNotified_parameter_1$schema
							}
						},
						{
							name: "client",
							wire: "client",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-deepseek-account/types#AccountClientMetadata",
								create: _deepseek_ai_dsh_api_account_controller_account_ackBonusNotified_parameter_2$schema
							}
						}
					],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-account-controller#account/ackBonusNotified:result",
						create: _deepseek_ai_dsh_api_account_controller_account_ackBonusNotified_result$schema
					},
					sourceLocation: {
						"file": "packages/api/account-controller/src/index.ts",
						"line": 55,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-account-controller#account/cancelSignIn",
					service: "accountController",
					namespace: "account",
					method: "cancelSignIn",
					invocation: { kind: "direct" },
					parameters: [{
						name: "attemptId",
						wire: "attemptId",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-deepseek-account/types#SignInAttemptId",
							create: _deepseek_ai_dsh_api_account_controller_account_cancelSignIn_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-deepseek-account/types#AccountView",
						create: _deepseek_ai_dsh_api_account_controller_account_cancelSignIn_result$schema
					},
					sourceLocation: {
						"file": "packages/api/account-controller/src/index.ts",
						"line": 75,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-account-controller#account/getBalance",
					service: "accountController",
					namespace: "account",
					method: "getBalance",
					invocation: { kind: "direct" },
					parameters: [{
						name: "client",
						wire: "client",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-deepseek-account/types#AccountClientMetadata",
							create: _deepseek_ai_dsh_api_account_controller_account_getBalance_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-account-controller#account/getBalance:result",
						create: _deepseek_ai_dsh_api_account_controller_account_getBalance_result$schema
					},
					sourceLocation: {
						"file": "packages/api/account-controller/src/index.ts",
						"line": 35,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-account-controller#account/getProfile",
					service: "accountController",
					namespace: "account",
					method: "getProfile",
					invocation: { kind: "direct" },
					parameters: [{
						name: "client",
						wire: "client",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-deepseek-account/types#AccountClientMetadata",
							create: _deepseek_ai_dsh_api_account_controller_account_getProfile_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-account-controller#account/getProfile:result",
						create: _deepseek_ai_dsh_api_account_controller_account_getProfile_result$schema
					},
					sourceLocation: {
						"file": "packages/api/account-controller/src/index.ts",
						"line": 26,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-account-controller#account/getState",
					service: "accountController",
					namespace: "account",
					method: "getState",
					invocation: { kind: "direct" },
					parameters: [],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-deepseek-account/types#AccountView",
						create: _deepseek_ai_dsh_api_account_controller_account_getState_result$schema
					},
					sourceLocation: {
						"file": "packages/api/account-controller/src/index.ts",
						"line": 19,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-account-controller#account/getUnnotifiedBonuses",
					service: "accountController",
					namespace: "account",
					method: "getUnnotifiedBonuses",
					invocation: { kind: "direct" },
					parameters: [{
						name: "client",
						wire: "client",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-deepseek-account/types#AccountClientMetadata",
							create: _deepseek_ai_dsh_api_account_controller_account_getUnnotifiedBonuses_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-account-controller#account/getUnnotifiedBonuses:result",
						create: _deepseek_ai_dsh_api_account_controller_account_getUnnotifiedBonuses_result$schema
					},
					sourceLocation: {
						"file": "packages/api/account-controller/src/index.ts",
						"line": 44,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-account-controller#account/hasRunningAccountTasks",
					service: "accountController",
					namespace: "account",
					method: "hasRunningAccountTasks",
					invocation: { kind: "direct" },
					parameters: [],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-account-controller#account/hasRunningAccountTasks:result",
						create: _deepseek_ai_dsh_api_account_controller_account_hasRunningAccountTasks_result$schema
					},
					sourceLocation: {
						"file": "packages/api/account-controller/src/index.ts",
						"line": 81,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-account-controller#account/signOut",
					service: "accountController",
					namespace: "account",
					method: "signOut",
					invocation: { kind: "direct" },
					parameters: [{
						name: "client",
						wire: "client",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-deepseek-account/types#AccountClientMetadata",
							create: _deepseek_ai_dsh_api_account_controller_account_signOut_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-deepseek-account/types#AccountView",
						create: _deepseek_ai_dsh_api_account_controller_account_signOut_result$schema
					},
					sourceLocation: {
						"file": "packages/api/account-controller/src/index.ts",
						"line": 90,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-account-controller#account/startSignIn",
					service: "accountController",
					namespace: "account",
					method: "startSignIn",
					invocation: { kind: "direct" },
					parameters: [
						{
							name: "client",
							wire: "client",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-deepseek-account/types#AccountClientMetadata",
								create: _deepseek_ai_dsh_api_account_controller_account_startSignIn_parameter_0$schema
							}
						},
						{
							name: "callbackOrigin",
							wire: "callbackOrigin",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-api-account-controller#account/startSignIn:callbackOrigin",
								create: _deepseek_ai_dsh_api_account_controller_account_startSignIn_parameter_1$schema
							}
						},
						{
							name: "loginSource",
							wire: "loginSource",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-api-account-controller#account/startSignIn:loginSource",
								create: _deepseek_ai_dsh_api_account_controller_account_startSignIn_parameter_2$schema
							}
						}
					],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-deepseek-account/types#AccountView",
						create: _deepseek_ai_dsh_api_account_controller_account_startSignIn_result$schema
					},
					sourceLocation: {
						"file": "packages/api/account-controller/src/index.ts",
						"line": 66,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-account-controller#account/watch",
					service: "accountController",
					namespace: "account",
					method: "watch",
					mode: "stream",
					invocation: { kind: "direct" },
					parameters: [],
					cancellation: { parameter: "signal" },
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-deepseek-account/types#AccountView",
						create: _deepseek_ai_dsh_api_account_controller_account_watch_result$schema
					},
					sourceLocation: {
						"file": "packages/api/account-controller/src/index.ts",
						"line": 119,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-account-controller#account/watchExpiry",
					service: "accountController",
					namespace: "account",
					method: "watchExpiry",
					mode: "stream",
					invocation: { kind: "direct" },
					parameters: [],
					cancellation: { parameter: "signal" },
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-account-controller#account/watchExpiry:result",
						create: _deepseek_ai_dsh_api_account_controller_account_watchExpiry_result$schema
					},
					sourceLocation: {
						"file": "packages/api/account-controller/src/index.ts",
						"line": 97,
						"column": 10
					}
				}
			]
		};
		//#endregion
		//#region ../settings-controller/lib/typert.remote-client.js
		let JsonValueRemoteCodec$schema$value$2;
		const JsonValueRemoteCodec$schema$2 = () => JsonValueRemoteCodec$schema$value$2 ??= union([
			literal(null),
			string(),
			number(),
			literal(false),
			literal(true),
			array(lazy(() => JsonValueRemoteCodec$schema$2())),
			record(string(), lazy(() => JsonValueRemoteCodec$schema$2()))
		]);
		let JsonValueRemoteCodec$schema2$value$2;
		const JsonValueRemoteCodec$schema2$2 = () => JsonValueRemoteCodec$schema2$value$2 ??= union([
			literal(null),
			string(),
			number(),
			literal(false),
			literal(true),
			array(lazy(() => JsonValueRemoteCodec$schema2$2())),
			record(string(), lazy(() => JsonValueRemoteCodec$schema2$2()))
		]);
		let JsonValueRemoteCodec$schema3$value$2;
		const JsonValueRemoteCodec$schema3$2 = () => JsonValueRemoteCodec$schema3$value$2 ??= union([
			literal(null),
			string(),
			number(),
			literal(false),
			literal(true),
			array(lazy(() => JsonValueRemoteCodec$schema3$2())),
			record(string(), lazy(() => JsonValueRemoteCodec$schema3$2()))
		]);
		let JsonValueRemoteCodec$schema4$value$2;
		const JsonValueRemoteCodec$schema4$2 = () => JsonValueRemoteCodec$schema4$value$2 ??= union([
			literal(null),
			string(),
			number(),
			literal(false),
			literal(true),
			array(lazy(() => JsonValueRemoteCodec$schema4$2())),
			record(string(), lazy(() => JsonValueRemoteCodec$schema4$2()))
		]);
		let JsonValueRemoteCodec$schema5$value$1;
		const JsonValueRemoteCodec$schema5$1 = () => JsonValueRemoteCodec$schema5$value$1 ??= union([
			literal(null),
			string(),
			number(),
			literal(false),
			literal(true),
			array(lazy(() => JsonValueRemoteCodec$schema5$1())),
			record(string(), lazy(() => JsonValueRemoteCodec$schema5$1()))
		]);
		let JsonValueRemoteCodec$schema6$value;
		const JsonValueRemoteCodec$schema6 = () => JsonValueRemoteCodec$schema6$value ??= union([
			literal(null),
			string(),
			number(),
			literal(false),
			literal(true),
			array(lazy(() => JsonValueRemoteCodec$schema6())),
			record(string(), lazy(() => JsonValueRemoteCodec$schema6()))
		]);
		let JsonValueRemoteCodec$schema7$value;
		const JsonValueRemoteCodec$schema7 = () => JsonValueRemoteCodec$schema7$value ??= union([
			literal(null),
			string(),
			number(),
			literal(false),
			literal(true),
			array(lazy(() => JsonValueRemoteCodec$schema7())),
			record(string(), lazy(() => JsonValueRemoteCodec$schema7()))
		]);
		let _deepseek_ai_dsh_api_settings_controller_credentials_describe_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_settings_controller_credentials_describe_parameter_0$schema = () => _deepseek_ai_dsh_api_settings_controller_credentials_describe_parameter_0$schema$value ??= array(string());
		let _deepseek_ai_dsh_api_settings_controller_credentials_describe_result$schema$value;
		const _deepseek_ai_dsh_api_settings_controller_credentials_describe_result$schema = () => _deepseek_ai_dsh_api_settings_controller_credentials_describe_result$schema$value ??= record(string(), object({
			"configured": boolean(),
			"source": string().optional(),
			"writable": boolean()
		}));
		let _deepseek_ai_dsh_api_settings_controller_credentials_set_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_settings_controller_credentials_set_parameter_0$schema = () => _deepseek_ai_dsh_api_settings_controller_credentials_set_parameter_0$schema$value ??= string();
		let _deepseek_ai_dsh_api_settings_controller_credentials_set_parameter_1$schema$value;
		const _deepseek_ai_dsh_api_settings_controller_credentials_set_parameter_1$schema = () => _deepseek_ai_dsh_api_settings_controller_credentials_set_parameter_1$schema$value ??= string();
		let _deepseek_ai_dsh_api_settings_controller_credentials_set_result$schema$value;
		const _deepseek_ai_dsh_api_settings_controller_credentials_set_result$schema = () => _deepseek_ai_dsh_api_settings_controller_credentials_set_result$schema$value ??= _void();
		let _deepseek_ai_dsh_api_settings_controller_credentials_unset_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_settings_controller_credentials_unset_parameter_0$schema = () => _deepseek_ai_dsh_api_settings_controller_credentials_unset_parameter_0$schema$value ??= string();
		let _deepseek_ai_dsh_api_settings_controller_credentials_unset_result$schema$value;
		const _deepseek_ai_dsh_api_settings_controller_credentials_unset_result$schema = () => _deepseek_ai_dsh_api_settings_controller_credentials_unset_result$schema$value ??= _void();
		let _deepseek_ai_dsh_api_settings_controller_settings_describe_result$schema$value;
		const _deepseek_ai_dsh_api_settings_controller_settings_describe_result$schema = () => _deepseek_ai_dsh_api_settings_controller_settings_describe_result$schema$value ??= object({
			"writable": boolean(),
			"hasDocument": boolean(),
			"namespaces": array(object({
				"autoGenerate": boolean(),
				"ns": string(),
				"schema": union([
					literal(null),
					string(),
					number(),
					literal(false),
					literal(true),
					array(lazy(() => JsonValueRemoteCodec$schema7())),
					record(string(), lazy(() => JsonValueRemoteCodec$schema7()))
				]),
				"value": union([
					literal(null),
					string(),
					number(),
					literal(false),
					literal(true),
					array(lazy(() => JsonValueRemoteCodec$schema7())),
					record(string(), lazy(() => JsonValueRemoteCodec$schema7()))
				]),
				"base": union([
					literal(null),
					string(),
					number(),
					literal(false),
					literal(true),
					array(lazy(() => JsonValueRemoteCodec$schema7())),
					record(string(), lazy(() => JsonValueRemoteCodec$schema7()))
				]).optional(),
				"user": union([
					literal(null),
					string(),
					number(),
					literal(false),
					literal(true),
					array(lazy(() => JsonValueRemoteCodec$schema7())),
					record(string(), lazy(() => JsonValueRemoteCodec$schema7()))
				]).optional(),
				"applies": literal("live"),
				"secrets": array(object({
					"path": array(string()),
					"set": boolean()
				})),
				"revision": number()
			}))
		});
		let _deepseek_ai_dsh_api_settings_controller_settings_mutate_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_settings_controller_settings_mutate_parameter_0$schema = () => _deepseek_ai_dsh_api_settings_controller_settings_mutate_parameter_0$schema$value ??= string();
		let _deepseek_ai_dsh_api_settings_controller_settings_mutate_parameter_1$schema$value;
		const _deepseek_ai_dsh_api_settings_controller_settings_mutate_parameter_1$schema = () => _deepseek_ai_dsh_api_settings_controller_settings_mutate_parameter_1$schema$value ??= array(union([object({
			"op": literal("set"),
			"path": array(string()),
			"value": union([
				literal(null),
				string(),
				number(),
				literal(false),
				literal(true),
				array(lazy(() => JsonValueRemoteCodec$schema5$1())),
				record(string(), lazy(() => JsonValueRemoteCodec$schema5$1()))
			])
		}), object({
			"op": literal("unset"),
			"path": array(string())
		})]));
		let _deepseek_ai_dsh_api_settings_controller_settings_mutate_parameter_2$schema$value;
		const _deepseek_ai_dsh_api_settings_controller_settings_mutate_parameter_2$schema = () => _deepseek_ai_dsh_api_settings_controller_settings_mutate_parameter_2$schema$value ??= union([_undefined(), number()]);
		let _deepseek_ai_dsh_api_settings_controller_settings_mutate_result$schema$value;
		const _deepseek_ai_dsh_api_settings_controller_settings_mutate_result$schema = () => _deepseek_ai_dsh_api_settings_controller_settings_mutate_result$schema$value ??= object({
			"autoGenerate": boolean(),
			"ns": string(),
			"schema": union([
				literal(null),
				string(),
				number(),
				literal(false),
				literal(true),
				array(lazy(() => JsonValueRemoteCodec$schema6())),
				record(string(), lazy(() => JsonValueRemoteCodec$schema6()))
			]),
			"value": union([
				literal(null),
				string(),
				number(),
				literal(false),
				literal(true),
				array(lazy(() => JsonValueRemoteCodec$schema6())),
				record(string(), lazy(() => JsonValueRemoteCodec$schema6()))
			]),
			"base": union([
				literal(null),
				string(),
				number(),
				literal(false),
				literal(true),
				array(lazy(() => JsonValueRemoteCodec$schema6())),
				record(string(), lazy(() => JsonValueRemoteCodec$schema6()))
			]).optional(),
			"user": union([
				literal(null),
				string(),
				number(),
				literal(false),
				literal(true),
				array(lazy(() => JsonValueRemoteCodec$schema6())),
				record(string(), lazy(() => JsonValueRemoteCodec$schema6()))
			]).optional(),
			"applies": literal("live"),
			"secrets": array(object({
				"path": array(string()),
				"set": boolean()
			})),
			"revision": number()
		});
		let _deepseek_ai_dsh_api_settings_controller_settings_openSettingsDocument_result$schema$value;
		const _deepseek_ai_dsh_api_settings_controller_settings_openSettingsDocument_result$schema = () => _deepseek_ai_dsh_api_settings_controller_settings_openSettingsDocument_result$schema$value ??= object({ "opened": literal(true).readonly() });
		let _deepseek_ai_dsh_api_settings_controller_settings_replace_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_settings_controller_settings_replace_parameter_0$schema = () => _deepseek_ai_dsh_api_settings_controller_settings_replace_parameter_0$schema$value ??= string();
		let _deepseek_ai_dsh_api_settings_controller_settings_replace_parameter_1$schema$value;
		const _deepseek_ai_dsh_api_settings_controller_settings_replace_parameter_1$schema = () => _deepseek_ai_dsh_api_settings_controller_settings_replace_parameter_1$schema$value ??= record(string(), union([
			literal(null),
			string(),
			number(),
			literal(false),
			literal(true),
			array(lazy(() => JsonValueRemoteCodec$schema3$2())),
			record(string(), lazy(() => JsonValueRemoteCodec$schema3$2()))
		]));
		let _deepseek_ai_dsh_api_settings_controller_settings_replace_parameter_2$schema$value;
		const _deepseek_ai_dsh_api_settings_controller_settings_replace_parameter_2$schema = () => _deepseek_ai_dsh_api_settings_controller_settings_replace_parameter_2$schema$value ??= union([_undefined(), number()]);
		let _deepseek_ai_dsh_api_settings_controller_settings_replace_result$schema$value;
		const _deepseek_ai_dsh_api_settings_controller_settings_replace_result$schema = () => _deepseek_ai_dsh_api_settings_controller_settings_replace_result$schema$value ??= object({
			"autoGenerate": boolean(),
			"ns": string(),
			"schema": union([
				literal(null),
				string(),
				number(),
				literal(false),
				literal(true),
				array(lazy(() => JsonValueRemoteCodec$schema4$2())),
				record(string(), lazy(() => JsonValueRemoteCodec$schema4$2()))
			]),
			"value": union([
				literal(null),
				string(),
				number(),
				literal(false),
				literal(true),
				array(lazy(() => JsonValueRemoteCodec$schema4$2())),
				record(string(), lazy(() => JsonValueRemoteCodec$schema4$2()))
			]),
			"base": union([
				literal(null),
				string(),
				number(),
				literal(false),
				literal(true),
				array(lazy(() => JsonValueRemoteCodec$schema4$2())),
				record(string(), lazy(() => JsonValueRemoteCodec$schema4$2()))
			]).optional(),
			"user": union([
				literal(null),
				string(),
				number(),
				literal(false),
				literal(true),
				array(lazy(() => JsonValueRemoteCodec$schema4$2())),
				record(string(), lazy(() => JsonValueRemoteCodec$schema4$2()))
			]).optional(),
			"applies": literal("live"),
			"secrets": array(object({
				"path": array(string()),
				"set": boolean()
			})),
			"revision": number()
		});
		let _deepseek_ai_dsh_api_settings_controller_settings_update_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_settings_controller_settings_update_parameter_0$schema = () => _deepseek_ai_dsh_api_settings_controller_settings_update_parameter_0$schema$value ??= string();
		let _deepseek_ai_dsh_api_settings_controller_settings_update_parameter_1$schema$value;
		const _deepseek_ai_dsh_api_settings_controller_settings_update_parameter_1$schema = () => _deepseek_ai_dsh_api_settings_controller_settings_update_parameter_1$schema$value ??= record(string(), union([
			literal(null),
			string(),
			number(),
			literal(false),
			literal(true),
			array(lazy(() => JsonValueRemoteCodec$schema$2())),
			record(string(), lazy(() => JsonValueRemoteCodec$schema$2()))
		]));
		let _deepseek_ai_dsh_api_settings_controller_settings_update_parameter_2$schema$value;
		const _deepseek_ai_dsh_api_settings_controller_settings_update_parameter_2$schema = () => _deepseek_ai_dsh_api_settings_controller_settings_update_parameter_2$schema$value ??= union([_undefined(), number()]);
		let _deepseek_ai_dsh_api_settings_controller_settings_update_result$schema$value;
		const _deepseek_ai_dsh_api_settings_controller_settings_update_result$schema = () => _deepseek_ai_dsh_api_settings_controller_settings_update_result$schema$value ??= object({
			"autoGenerate": boolean(),
			"ns": string(),
			"schema": union([
				literal(null),
				string(),
				number(),
				literal(false),
				literal(true),
				array(lazy(() => JsonValueRemoteCodec$schema2$2())),
				record(string(), lazy(() => JsonValueRemoteCodec$schema2$2()))
			]),
			"value": union([
				literal(null),
				string(),
				number(),
				literal(false),
				literal(true),
				array(lazy(() => JsonValueRemoteCodec$schema2$2())),
				record(string(), lazy(() => JsonValueRemoteCodec$schema2$2()))
			]),
			"base": union([
				literal(null),
				string(),
				number(),
				literal(false),
				literal(true),
				array(lazy(() => JsonValueRemoteCodec$schema2$2())),
				record(string(), lazy(() => JsonValueRemoteCodec$schema2$2()))
			]).optional(),
			"user": union([
				literal(null),
				string(),
				number(),
				literal(false),
				literal(true),
				array(lazy(() => JsonValueRemoteCodec$schema2$2())),
				record(string(), lazy(() => JsonValueRemoteCodec$schema2$2()))
			]).optional(),
			"applies": literal("live"),
			"secrets": array(object({
				"path": array(string()),
				"set": boolean()
			})),
			"revision": number()
		});
		const TYPERT_REMOTE$19 = {
			package: "@deepseek-ai/dsh-api-settings-controller",
			descriptors: [
				{
					id: "@deepseek-ai/dsh-api-settings-controller#credentials/describe",
					service: "credentialsController",
					namespace: "credentials",
					method: "describe",
					invocation: { kind: "direct" },
					parameters: [{
						name: "refs",
						wire: "refs",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-settings-controller#credentials/describe:refs",
							create: _deepseek_ai_dsh_api_settings_controller_credentials_describe_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-settings-controller#credentials/describe:result",
						create: _deepseek_ai_dsh_api_settings_controller_credentials_describe_result$schema
					},
					sourceLocation: {
						"file": "packages/api/settings-controller/src/credentials.ts",
						"line": 83,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-api-settings-controller#credentials/set",
					service: "credentialsController",
					namespace: "credentials",
					method: "set",
					invocation: { kind: "direct" },
					parameters: [{
						name: "ref",
						wire: "ref",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-settings-controller#credentials/set:ref",
							create: _deepseek_ai_dsh_api_settings_controller_credentials_set_parameter_0$schema
						}
					}, {
						name: "value",
						wire: "value",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-settings-controller#credentials/set:value",
							create: _deepseek_ai_dsh_api_settings_controller_credentials_set_parameter_1$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-settings-controller#credentials/set:result",
						create: _deepseek_ai_dsh_api_settings_controller_credentials_set_result$schema
					},
					sourceLocation: {
						"file": "packages/api/settings-controller/src/credentials.ts",
						"line": 100,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-api-settings-controller#credentials/unset",
					service: "credentialsController",
					namespace: "credentials",
					method: "unset",
					invocation: { kind: "direct" },
					parameters: [{
						name: "ref",
						wire: "ref",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-settings-controller#credentials/unset:ref",
							create: _deepseek_ai_dsh_api_settings_controller_credentials_unset_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-settings-controller#credentials/unset:result",
						create: _deepseek_ai_dsh_api_settings_controller_credentials_unset_result$schema
					},
					sourceLocation: {
						"file": "packages/api/settings-controller/src/credentials.ts",
						"line": 113,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-api-settings-controller#settings/describe",
					service: "settingsController",
					namespace: "settings",
					method: "describe",
					invocation: { kind: "direct" },
					parameters: [],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-settings/types#SettingsDescribeValue",
						create: _deepseek_ai_dsh_api_settings_controller_settings_describe_result$schema
					},
					sourceLocation: {
						"file": "packages/api/settings-controller/src/index.ts",
						"line": 98,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-settings-controller#settings/mutate",
					service: "settingsController",
					namespace: "settings",
					method: "mutate",
					invocation: { kind: "direct" },
					parameters: [
						{
							name: "ns",
							wire: "ns",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-api-settings-controller#settings/mutate:ns",
								create: _deepseek_ai_dsh_api_settings_controller_settings_mutate_parameter_0$schema
							}
						},
						{
							name: "ops",
							wire: "ops",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-api-settings-controller#settings/mutate:ops",
								create: _deepseek_ai_dsh_api_settings_controller_settings_mutate_parameter_1$schema
							}
						},
						{
							name: "expectedRevision",
							wire: "expectedRevision",
							source: "json",
							acceptsUndefined: true,
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-api-settings-controller#settings/mutate:expectedRevision",
								create: _deepseek_ai_dsh_api_settings_controller_settings_mutate_parameter_2$schema
							}
						}
					],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-settings/types#SettingsNamespaceView",
						create: _deepseek_ai_dsh_api_settings_controller_settings_mutate_result$schema
					},
					sourceLocation: {
						"file": "packages/api/settings-controller/src/index.ts",
						"line": 152,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-api-settings-controller#settings/openSettingsDocument",
					service: "settingsController",
					namespace: "settings",
					method: "openSettingsDocument",
					invocation: { kind: "direct" },
					parameters: [],
					cancellation: { parameter: "signal" },
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-settings-controller/types#SettingsDocumentOpenValue",
						create: _deepseek_ai_dsh_api_settings_controller_settings_openSettingsDocument_result$schema
					},
					sourceLocation: {
						"file": "packages/api/settings-controller/src/index.ts",
						"line": 167,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-api-settings-controller#settings/replace",
					service: "settingsController",
					namespace: "settings",
					method: "replace",
					invocation: { kind: "direct" },
					parameters: [
						{
							name: "ns",
							wire: "ns",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-api-settings-controller#settings/replace:ns",
								create: _deepseek_ai_dsh_api_settings_controller_settings_replace_parameter_0$schema
							}
						},
						{
							name: "section",
							wire: "section",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-api-settings-controller#settings/replace:section",
								create: _deepseek_ai_dsh_api_settings_controller_settings_replace_parameter_1$schema
							}
						},
						{
							name: "expectedRevision",
							wire: "expectedRevision",
							source: "json",
							acceptsUndefined: true,
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-api-settings-controller#settings/replace:expectedRevision",
								create: _deepseek_ai_dsh_api_settings_controller_settings_replace_parameter_2$schema
							}
						}
					],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-settings/types#SettingsNamespaceView",
						create: _deepseek_ai_dsh_api_settings_controller_settings_replace_result$schema
					},
					sourceLocation: {
						"file": "packages/api/settings-controller/src/index.ts",
						"line": 133,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-settings-controller#settings/update",
					service: "settingsController",
					namespace: "settings",
					method: "update",
					invocation: { kind: "direct" },
					parameters: [
						{
							name: "ns",
							wire: "ns",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-api-settings-controller#settings/update:ns",
								create: _deepseek_ai_dsh_api_settings_controller_settings_update_parameter_0$schema
							}
						},
						{
							name: "patch",
							wire: "patch",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-api-settings-controller#settings/update:patch",
								create: _deepseek_ai_dsh_api_settings_controller_settings_update_parameter_1$schema
							}
						},
						{
							name: "expectedRevision",
							wire: "expectedRevision",
							source: "json",
							acceptsUndefined: true,
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-api-settings-controller#settings/update:expectedRevision",
								create: _deepseek_ai_dsh_api_settings_controller_settings_update_parameter_2$schema
							}
						}
					],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-settings/types#SettingsNamespaceView",
						create: _deepseek_ai_dsh_api_settings_controller_settings_update_result$schema
					},
					sourceLocation: {
						"file": "packages/api/settings-controller/src/index.ts",
						"line": 116,
						"column": 3
					}
				}
			]
		};
		//#endregion
		//#region ../../document/office-to-pdf/lib/typert.remote-client.js
		let _deepseek_ai_dsh_office_to_pdf_officeToPdf_generation_result$schema$value;
		const _deepseek_ai_dsh_office_to_pdf_officeToPdf_generation_result$schema = () => _deepseek_ai_dsh_office_to_pdf_officeToPdf_generation_result$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_office_to_pdf_officeToPdf_render_parameter_0$schema$value;
		const _deepseek_ai_dsh_office_to_pdf_officeToPdf_render_parameter_0$schema = () => _deepseek_ai_dsh_office_to_pdf_officeToPdf_render_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_office_to_pdf_officeToPdf_render_parameter_1$schema$value;
		const _deepseek_ai_dsh_office_to_pdf_officeToPdf_render_parameter_1$schema = () => _deepseek_ai_dsh_office_to_pdf_officeToPdf_render_parameter_1$schema$value ??= string();
		let _deepseek_ai_dsh_office_to_pdf_officeToPdf_render_parameter_2$schema$value;
		const _deepseek_ai_dsh_office_to_pdf_officeToPdf_render_parameter_2$schema = () => _deepseek_ai_dsh_office_to_pdf_officeToPdf_render_parameter_2$schema$value ??= union([literal("foreground"), literal("background")]);
		let _deepseek_ai_dsh_office_to_pdf_officeToPdf_render_result$schema$value;
		const _deepseek_ai_dsh_office_to_pdf_officeToPdf_render_result$schema = () => _deepseek_ai_dsh_office_to_pdf_officeToPdf_render_result$schema$value ??= object({
			"missingFonts": array(string()).readonly(),
			"generation": intersection(string(), unknown()).readonly(),
			"offset": number().readonly(),
			"data": _instanceof(Uint8Array),
			"eof": boolean().readonly(),
			"absolutePath": string().readonly(),
			"version": string().readonly(),
			"bytes": number().readonly().optional()
		});
		const $resultSnapshot$1 = (input, path) => {
			if (input === null || typeof input !== "object" || input instanceof Uint8Array) return input;
			const toJSON = input.toJSON;
			const value = typeof toJSON === "function" ? toJSON.call(input, path.at(-1)?.toString() ?? "value") : input;
			if (value === null || typeof value !== "object" || value instanceof Uint8Array) return value;
			if (Array.isArray(value)) {
				const items = [];
				for (let index = 0, length = value.length; index < length; index++) items.push(value[index]);
				return items;
			}
			const fields = {};
			for (const key of Object.keys(value)) {
				const item = key === "toJSON" && value === input ? toJSON : value[key];
				if (key === "toJSON" && typeof item === "function") continue;
				Object.defineProperty(fields, key, {
					value: item,
					enumerable: true,
					writable: true,
					configurable: true
				});
			}
			return fields;
		};
		const $resultContainer$1 = (input, path, ancestors, project, snapshot) => {
			if (input === null || typeof input !== "object") return project(input);
			const owner = !ancestors.has(input);
			if (!owner && ancestors.get(input) !== path.length) throw new TypeError("Remote result contains a circular object");
			if (owner) ancestors.set(input, path.length);
			try {
				return project(snapshot ? $resultSnapshot$1(input, path) : input);
			} finally {
				if (owner) ancestors.delete(input);
			}
		};
		const $encode1$1 = (value, writeBytes, path, ancestors) => {
			return value instanceof Uint8Array ? writeBytes(value, path) : value;
		};
		const $encode0$1 = (value, writeBytes, path, ancestors) => {
			return $resultContainer$1(value, path, ancestors, (value) => {
				if (value === null || typeof value !== "object" || Array.isArray(value) || value instanceof Uint8Array) return value;
				if (Object.hasOwn(value, "data")) value["data"] = $encode1$1(value["data"], writeBytes, [...path, "data"], ancestors);
				return value;
			}, true);
		};
		const TYPERT_REMOTE$18 = {
			package: "@deepseek-ai/dsh-office-to-pdf",
			descriptors: [{
				id: "@deepseek-ai/dsh-office-to-pdf#officeToPdf/generation",
				service: "officeToPdf",
				namespace: "officeToPdf",
				method: "generation",
				implementation: "getGeneration",
				invocation: { kind: "direct" },
				parameters: [],
				cancellation: { parameter: "signal" },
				result: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-office-to-pdf/types#OfficeToPdfGeneration",
					create: _deepseek_ai_dsh_office_to_pdf_officeToPdf_generation_result$schema
				},
				sourceLocation: {
					"file": "packages/document/office-to-pdf/src/index.ts",
					"line": 175,
					"column": 3
				}
			}, {
				id: "@deepseek-ai/dsh-office-to-pdf#officeToPdf/render",
				service: "officeToPdf",
				namespace: "officeToPdf",
				method: "render",
				invocation: { kind: "direct" },
				parameters: [
					{
						name: "workspaceFileScope",
						wire: "workspaceFileScopeId",
						source: "lookup",
						lookup: "workspaceFileScope",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
							create: _deepseek_ai_dsh_office_to_pdf_officeToPdf_render_parameter_0$schema
						}
					},
					{
						name: "path",
						wire: "path",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-office-to-pdf#officeToPdf/render:path",
							create: _deepseek_ai_dsh_office_to_pdf_officeToPdf_render_parameter_1$schema
						}
					},
					{
						name: "priority",
						wire: "priority",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-office-to-pdf/types#OfficeToPdfPriority",
							create: _deepseek_ai_dsh_office_to_pdf_officeToPdf_render_parameter_2$schema
						}
					}
				],
				cancellation: { parameter: "signal" },
				result: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-office-to-pdf/types#RenderedDocumentBytes",
					create: _deepseek_ai_dsh_office_to_pdf_officeToPdf_render_result$schema,
					decode: (value) => _deepseek_ai_dsh_office_to_pdf_officeToPdf_render_result$schema().parse(value),
					encode: (value, writeBytes) => $encode0$1(value, writeBytes, [], /* @__PURE__ */ new Map())
				},
				sourceLocation: {
					"file": "packages/document/office-to-pdf/src/index.ts",
					"line": 160,
					"column": 9
				}
			}]
		};
		//#endregion
		//#region ../../goal/goal/lib/typert.remote-client.js
		let _deepseek_ai_dsh_goal_goals_clear_parameter_0$schema$value;
		const _deepseek_ai_dsh_goal_goals_clear_parameter_0$schema = () => _deepseek_ai_dsh_goal_goals_clear_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_goal_goals_clear_parameter_1$schema$value;
		const _deepseek_ai_dsh_goal_goals_clear_parameter_1$schema = () => _deepseek_ai_dsh_goal_goals_clear_parameter_1$schema$value ??= object({
			"id": intersection(string(), unknown()).readonly(),
			"revision": number().readonly()
		});
		let _deepseek_ai_dsh_goal_goals_clear_result$schema$value;
		const _deepseek_ai_dsh_goal_goals_clear_result$schema = () => _deepseek_ai_dsh_goal_goals_clear_result$schema$value ??= object({
			"id": intersection(string(), unknown()).readonly(),
			"revision": number().readonly()
		});
		let _deepseek_ai_dsh_goal_goals_complete_parameter_0$schema$value;
		const _deepseek_ai_dsh_goal_goals_complete_parameter_0$schema = () => _deepseek_ai_dsh_goal_goals_complete_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_goal_goals_complete_parameter_1$schema$value;
		const _deepseek_ai_dsh_goal_goals_complete_parameter_1$schema = () => _deepseek_ai_dsh_goal_goals_complete_parameter_1$schema$value ??= object({
			"id": intersection(string(), unknown()).readonly(),
			"revision": number().readonly()
		});
		let _deepseek_ai_dsh_goal_goals_complete_result$schema$value;
		const _deepseek_ai_dsh_goal_goals_complete_result$schema = () => _deepseek_ai_dsh_goal_goals_complete_result$schema$value ??= object({
			"roundsStarted": number().readonly(),
			"createdAt": number().readonly(),
			"updatedAt": number().readonly(),
			"activation": union([literal("armed"), literal("disarmed")]).readonly(),
			"objective": string().readonly(),
			"phase": union([
				literal("active"),
				literal("paused"),
				literal("blocked"),
				literal("complete")
			]).readonly(),
			"blockedReason": object({
				"code": string().readonly(),
				"message": string().readonly()
			}).readonly().optional(),
			"maxGoalRounds": number().readonly(),
			"id": intersection(string(), unknown()).readonly(),
			"revision": number().readonly()
		});
		let _deepseek_ai_dsh_goal_goals_create_parameter_0$schema$value;
		const _deepseek_ai_dsh_goal_goals_create_parameter_0$schema = () => _deepseek_ai_dsh_goal_goals_create_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_goal_goals_create_parameter_1$schema$value;
		const _deepseek_ai_dsh_goal_goals_create_parameter_1$schema = () => _deepseek_ai_dsh_goal_goals_create_parameter_1$schema$value ??= object({
			"objective": string().readonly(),
			"maxGoalRounds": number().readonly().optional()
		});
		let _deepseek_ai_dsh_goal_goals_create_result$schema$value;
		const _deepseek_ai_dsh_goal_goals_create_result$schema = () => _deepseek_ai_dsh_goal_goals_create_result$schema$value ??= object({ "ref": object({
			"id": intersection(string(), unknown()).readonly(),
			"revision": number().readonly()
		}).readonly() });
		let _deepseek_ai_dsh_goal_goals_edit_parameter_0$schema$value;
		const _deepseek_ai_dsh_goal_goals_edit_parameter_0$schema = () => _deepseek_ai_dsh_goal_goals_edit_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_goal_goals_edit_parameter_1$schema$value;
		const _deepseek_ai_dsh_goal_goals_edit_parameter_1$schema = () => _deepseek_ai_dsh_goal_goals_edit_parameter_1$schema$value ??= object({
			"id": intersection(string(), unknown()).readonly(),
			"revision": number().readonly()
		});
		let _deepseek_ai_dsh_goal_goals_edit_parameter_2$schema$value;
		const _deepseek_ai_dsh_goal_goals_edit_parameter_2$schema = () => _deepseek_ai_dsh_goal_goals_edit_parameter_2$schema$value ??= object({
			"objective": string().readonly().optional(),
			"maxGoalRounds": number().readonly().optional()
		});
		let _deepseek_ai_dsh_goal_goals_edit_result$schema$value;
		const _deepseek_ai_dsh_goal_goals_edit_result$schema = () => _deepseek_ai_dsh_goal_goals_edit_result$schema$value ??= object({
			"roundsStarted": number().readonly(),
			"createdAt": number().readonly(),
			"updatedAt": number().readonly(),
			"activation": union([literal("armed"), literal("disarmed")]).readonly(),
			"objective": string().readonly(),
			"phase": union([
				literal("active"),
				literal("paused"),
				literal("blocked"),
				literal("complete")
			]).readonly(),
			"blockedReason": object({
				"code": string().readonly(),
				"message": string().readonly()
			}).readonly().optional(),
			"maxGoalRounds": number().readonly(),
			"id": intersection(string(), unknown()).readonly(),
			"revision": number().readonly()
		});
		let _deepseek_ai_dsh_goal_goals_get_parameter_0$schema$value;
		const _deepseek_ai_dsh_goal_goals_get_parameter_0$schema = () => _deepseek_ai_dsh_goal_goals_get_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_goal_goals_get_result$schema$value;
		const _deepseek_ai_dsh_goal_goals_get_result$schema = () => _deepseek_ai_dsh_goal_goals_get_result$schema$value ??= union([_undefined(), object({
			"roundsStarted": number().readonly(),
			"createdAt": number().readonly(),
			"updatedAt": number().readonly(),
			"activation": union([literal("armed"), literal("disarmed")]).readonly(),
			"objective": string().readonly(),
			"phase": union([
				literal("active"),
				literal("paused"),
				literal("blocked"),
				literal("complete")
			]).readonly(),
			"blockedReason": object({
				"code": string().readonly(),
				"message": string().readonly()
			}).readonly().optional(),
			"maxGoalRounds": number().readonly(),
			"id": intersection(string(), unknown()).readonly(),
			"revision": number().readonly()
		})]);
		let _deepseek_ai_dsh_goal_goals_pause_parameter_0$schema$value;
		const _deepseek_ai_dsh_goal_goals_pause_parameter_0$schema = () => _deepseek_ai_dsh_goal_goals_pause_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_goal_goals_pause_parameter_1$schema$value;
		const _deepseek_ai_dsh_goal_goals_pause_parameter_1$schema = () => _deepseek_ai_dsh_goal_goals_pause_parameter_1$schema$value ??= object({
			"id": intersection(string(), unknown()).readonly(),
			"revision": number().readonly()
		});
		let _deepseek_ai_dsh_goal_goals_pause_result$schema$value;
		const _deepseek_ai_dsh_goal_goals_pause_result$schema = () => _deepseek_ai_dsh_goal_goals_pause_result$schema$value ??= object({
			"roundsStarted": number().readonly(),
			"createdAt": number().readonly(),
			"updatedAt": number().readonly(),
			"activation": union([literal("armed"), literal("disarmed")]).readonly(),
			"objective": string().readonly(),
			"phase": union([
				literal("active"),
				literal("paused"),
				literal("blocked"),
				literal("complete")
			]).readonly(),
			"blockedReason": object({
				"code": string().readonly(),
				"message": string().readonly()
			}).readonly().optional(),
			"maxGoalRounds": number().readonly(),
			"id": intersection(string(), unknown()).readonly(),
			"revision": number().readonly()
		});
		let _deepseek_ai_dsh_goal_goals_resume_parameter_0$schema$value;
		const _deepseek_ai_dsh_goal_goals_resume_parameter_0$schema = () => _deepseek_ai_dsh_goal_goals_resume_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_goal_goals_resume_parameter_1$schema$value;
		const _deepseek_ai_dsh_goal_goals_resume_parameter_1$schema = () => _deepseek_ai_dsh_goal_goals_resume_parameter_1$schema$value ??= object({
			"id": intersection(string(), unknown()).readonly(),
			"revision": number().readonly()
		});
		let _deepseek_ai_dsh_goal_goals_resume_result$schema$value;
		const _deepseek_ai_dsh_goal_goals_resume_result$schema = () => _deepseek_ai_dsh_goal_goals_resume_result$schema$value ??= object({
			"roundsStarted": number().readonly(),
			"createdAt": number().readonly(),
			"updatedAt": number().readonly(),
			"activation": union([literal("armed"), literal("disarmed")]).readonly(),
			"objective": string().readonly(),
			"phase": union([
				literal("active"),
				literal("paused"),
				literal("blocked"),
				literal("complete")
			]).readonly(),
			"blockedReason": object({
				"code": string().readonly(),
				"message": string().readonly()
			}).readonly().optional(),
			"maxGoalRounds": number().readonly(),
			"id": intersection(string(), unknown()).readonly(),
			"revision": number().readonly()
		});
		const TYPERT_REMOTE$17 = {
			package: "@deepseek-ai/dsh-goal",
			descriptors: [
				{
					id: "@deepseek-ai/dsh-goal#goals/clear",
					service: "goals",
					namespace: "goals",
					method: "clear",
					invocation: { kind: "direct" },
					scope: {
						context: "agent",
						wire: "agentId"
					},
					parameters: [{
						name: "agent",
						wire: "agentId",
						source: "lookup",
						lookup: "agent",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
							create: _deepseek_ai_dsh_goal_goals_clear_parameter_0$schema
						}
					}, {
						name: "ref",
						wire: "ref",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-goal/client#GoalRef",
							create: _deepseek_ai_dsh_goal_goals_clear_parameter_1$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-goal/client#GoalRef",
						create: _deepseek_ai_dsh_goal_goals_clear_result$schema
					},
					sourceLocation: {
						"file": "packages/goal/goal/src/index.ts",
						"line": 433,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-goal#goals/complete",
					service: "goals",
					namespace: "goals",
					method: "complete",
					invocation: { kind: "direct" },
					scope: {
						context: "agent",
						wire: "agentId"
					},
					parameters: [{
						name: "agent",
						wire: "agentId",
						source: "lookup",
						lookup: "agent",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
							create: _deepseek_ai_dsh_goal_goals_complete_parameter_0$schema
						}
					}, {
						name: "ref",
						wire: "ref",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-goal/client#GoalRef",
							create: _deepseek_ai_dsh_goal_goals_complete_parameter_1$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-goal/client#GoalView",
						create: _deepseek_ai_dsh_goal_goals_complete_result$schema
					},
					sourceLocation: {
						"file": "packages/goal/goal/src/index.ts",
						"line": 391,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-goal#goals/create",
					service: "goals",
					namespace: "goals",
					method: "create",
					implementation: "remoteExportCreate",
					invocation: { kind: "direct" },
					scope: {
						context: "agent",
						wire: "agentId"
					},
					parameters: [{
						name: "agent",
						wire: "agentId",
						source: "lookup",
						lookup: "agent",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
							create: _deepseek_ai_dsh_goal_goals_create_parameter_0$schema
						}
					}, {
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-goal/client#CreateGoalRequest",
							create: _deepseek_ai_dsh_goal_goals_create_parameter_1$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-goal/client#CreateGoalResult",
						create: _deepseek_ai_dsh_goal_goals_create_result$schema
					},
					sourceLocation: {
						"file": "packages/goal/goal/src/index.ts",
						"line": 647,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-goal#goals/edit",
					service: "goals",
					namespace: "goals",
					method: "edit",
					invocation: { kind: "direct" },
					scope: {
						context: "agent",
						wire: "agentId"
					},
					parameters: [
						{
							name: "agent",
							wire: "agentId",
							source: "lookup",
							lookup: "agent",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
								create: _deepseek_ai_dsh_goal_goals_edit_parameter_0$schema
							}
						},
						{
							name: "ref",
							wire: "ref",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-goal/client#GoalRef",
								create: _deepseek_ai_dsh_goal_goals_edit_parameter_1$schema
							}
						},
						{
							name: "request",
							wire: "request",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-goal/client#EditGoalRequest",
								create: _deepseek_ai_dsh_goal_goals_edit_parameter_2$schema
							}
						}
					],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-goal/client#GoalView",
						create: _deepseek_ai_dsh_goal_goals_edit_result$schema
					},
					sourceLocation: {
						"file": "packages/goal/goal/src/index.ts",
						"line": 329,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-goal#goals/get",
					service: "goals",
					namespace: "goals",
					method: "get",
					invocation: { kind: "direct" },
					scope: {
						context: "agent",
						wire: "agentId"
					},
					parameters: [{
						name: "agent",
						wire: "agentId",
						source: "lookup",
						lookup: "agent",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
							create: _deepseek_ai_dsh_goal_goals_get_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-goal#goals/get:result",
						create: _deepseek_ai_dsh_goal_goals_get_result$schema
					},
					sourceLocation: {
						"file": "packages/goal/goal/src/index.ts",
						"line": 277,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-goal#goals/pause",
					service: "goals",
					namespace: "goals",
					method: "pause",
					invocation: { kind: "direct" },
					scope: {
						context: "agent",
						wire: "agentId"
					},
					parameters: [{
						name: "agent",
						wire: "agentId",
						source: "lookup",
						lookup: "agent",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
							create: _deepseek_ai_dsh_goal_goals_pause_parameter_0$schema
						}
					}, {
						name: "ref",
						wire: "ref",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-goal/client#GoalRef",
							create: _deepseek_ai_dsh_goal_goals_pause_parameter_1$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-goal/client#GoalView",
						create: _deepseek_ai_dsh_goal_goals_pause_result$schema
					},
					sourceLocation: {
						"file": "packages/goal/goal/src/index.ts",
						"line": 352,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-goal#goals/resume",
					service: "goals",
					namespace: "goals",
					method: "resume",
					invocation: { kind: "direct" },
					scope: {
						context: "agent",
						wire: "agentId"
					},
					parameters: [{
						name: "agent",
						wire: "agentId",
						source: "lookup",
						lookup: "agent",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
							create: _deepseek_ai_dsh_goal_goals_resume_parameter_0$schema
						}
					}, {
						name: "ref",
						wire: "ref",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-goal/client#GoalRef",
							create: _deepseek_ai_dsh_goal_goals_resume_parameter_1$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-goal/client#GoalView",
						create: _deepseek_ai_dsh_goal_goals_resume_result$schema
					},
					sourceLocation: {
						"file": "packages/goal/goal/src/index.ts",
						"line": 364,
						"column": 3
					}
				}
			]
		};
		//#endregion
		//#region ../../schedule/schedule/lib/typert.remote-client.js
		let _deepseek_ai_dsh_schedule_schedule_catalog_result$schema$value;
		const _deepseek_ai_dsh_schedule_schedule_catalog_result$schema = () => _deepseek_ai_dsh_schedule_schedule_catalog_result$schema$value ??= array(union([
			intersection(object({
				"id": intersection(string(), unknown()).readonly(),
				"kind": literal("after").readonly(),
				"title": string().readonly(),
				"prompt": string().readonly(),
				"afterSeconds": number().readonly(),
				"scheduledAt": string().readonly()
			}), object({
				"sessionId": intersection(string(), unknown()).readonly(),
				"status": union([literal("active"), literal("inactive")]).readonly(),
				"lastDelivery": object({
					"scheduledAt": string().readonly(),
					"deliveredAt": string().readonly(),
					"messageId": intersection(string(), unknown()).readonly()
				}).readonly().optional()
			})),
			intersection(object({
				"id": intersection(string(), unknown()).readonly(),
				"kind": literal("at").readonly(),
				"title": string().readonly(),
				"prompt": string().readonly(),
				"scheduledAt": string().readonly()
			}), object({
				"sessionId": intersection(string(), unknown()).readonly(),
				"status": union([literal("active"), literal("inactive")]).readonly(),
				"lastDelivery": object({
					"scheduledAt": string().readonly(),
					"deliveredAt": string().readonly(),
					"messageId": intersection(string(), unknown()).readonly()
				}).readonly().optional()
			})),
			intersection(object({
				"id": intersection(string(), unknown()).readonly(),
				"kind": literal("every").readonly(),
				"title": string().readonly(),
				"prompt": string().readonly(),
				"everySeconds": number().readonly(),
				"scheduledAt": string().readonly()
			}), object({
				"sessionId": intersection(string(), unknown()).readonly(),
				"status": union([literal("active"), literal("inactive")]).readonly(),
				"lastDelivery": object({
					"scheduledAt": string().readonly(),
					"deliveredAt": string().readonly(),
					"messageId": intersection(string(), unknown()).readonly()
				}).readonly().optional()
			})),
			intersection(object({
				"id": intersection(string(), unknown()).readonly(),
				"kind": literal("daily").readonly(),
				"title": string().readonly(),
				"prompt": string().readonly(),
				"time": string().readonly(),
				"timeZone": string().readonly(),
				"scheduledAt": string().readonly()
			}), object({
				"sessionId": intersection(string(), unknown()).readonly(),
				"status": union([literal("active"), literal("inactive")]).readonly(),
				"lastDelivery": object({
					"scheduledAt": string().readonly(),
					"deliveredAt": string().readonly(),
					"messageId": intersection(string(), unknown()).readonly()
				}).readonly().optional()
			})),
			intersection(object({
				"id": intersection(string(), unknown()).readonly(),
				"kind": literal("weekly").readonly(),
				"title": string().readonly(),
				"prompt": string().readonly(),
				"time": string().readonly(),
				"timeZone": string().readonly(),
				"weekdays": array(number()).readonly(),
				"scheduledAt": string().readonly()
			}), object({
				"sessionId": intersection(string(), unknown()).readonly(),
				"status": union([literal("active"), literal("inactive")]).readonly(),
				"lastDelivery": object({
					"scheduledAt": string().readonly(),
					"deliveredAt": string().readonly(),
					"messageId": intersection(string(), unknown()).readonly()
				}).readonly().optional()
			})),
			intersection(object({
				"id": intersection(string(), unknown()).readonly(),
				"kind": literal("cron").readonly(),
				"title": string().readonly(),
				"prompt": string().readonly(),
				"expression": string().readonly(),
				"timeZone": string().readonly(),
				"scheduledAt": string().readonly()
			}), object({
				"sessionId": intersection(string(), unknown()).readonly(),
				"status": union([literal("active"), literal("inactive")]).readonly(),
				"lastDelivery": object({
					"scheduledAt": string().readonly(),
					"deliveredAt": string().readonly(),
					"messageId": intersection(string(), unknown()).readonly()
				}).readonly().optional()
			}))
		]));
		let _deepseek_ai_dsh_schedule_schedule_delete_parameter_0$schema$value;
		const _deepseek_ai_dsh_schedule_schedule_delete_parameter_0$schema = () => _deepseek_ai_dsh_schedule_schedule_delete_parameter_0$schema$value ??= object({
			"id": intersection(string(), unknown()),
			"sessionId": intersection(string(), unknown())
		});
		let _deepseek_ai_dsh_schedule_schedule_delete_result$schema$value;
		const _deepseek_ai_dsh_schedule_schedule_delete_result$schema = () => _deepseek_ai_dsh_schedule_schedule_delete_result$schema$value ??= union([object({
			"id": intersection(string(), unknown()).readonly(),
			"deleted": literal(true).readonly()
		}), object({
			"id": intersection(string(), unknown()).readonly(),
			"deleted": literal(false).readonly(),
			"code": literal("schedule_not_found").readonly()
		})]);
		let _deepseek_ai_dsh_schedule_schedule_history_parameter_0$schema$value;
		const _deepseek_ai_dsh_schedule_schedule_history_parameter_0$schema = () => _deepseek_ai_dsh_schedule_schedule_history_parameter_0$schema$value ??= object({
			"limit": number(),
			"before": intersection(string(), unknown()).optional(),
			"id": intersection(string(), unknown()),
			"sessionId": intersection(string(), unknown())
		});
		let _deepseek_ai_dsh_schedule_schedule_history_result$schema$value;
		const _deepseek_ai_dsh_schedule_schedule_history_result$schema = () => _deepseek_ai_dsh_schedule_schedule_history_result$schema$value ??= union([object({
			"id": intersection(string(), unknown()).readonly(),
			"records": array(object({
				"prompt": string().readonly().optional(),
				"scheduledAt": string().readonly(),
				"deliveredAt": string().readonly(),
				"messageId": intersection(string(), unknown()).readonly()
			})).readonly(),
			"earlierRecordsUnavailable": boolean().readonly(),
			"earlierRecordsPruned": boolean().readonly(),
			"retention": object({
				"days": number().readonly(),
				"records": number().readonly()
			}).readonly(),
			"nextBefore": intersection(string(), unknown()).readonly().optional()
		}), object({
			"id": intersection(string(), unknown()).readonly(),
			"code": union([literal("schedule_not_found"), literal("delivery_cursor_not_found")]).readonly()
		})]);
		let _deepseek_ai_dsh_schedule_schedule_list_parameter_0$schema$value;
		const _deepseek_ai_dsh_schedule_schedule_list_parameter_0$schema = () => _deepseek_ai_dsh_schedule_schedule_list_parameter_0$schema$value ??= object({ "sessionId": intersection(string(), unknown()) });
		let _deepseek_ai_dsh_schedule_schedule_list_result$schema$value;
		const _deepseek_ai_dsh_schedule_schedule_list_result$schema = () => _deepseek_ai_dsh_schedule_schedule_list_result$schema$value ??= array(union([
			object({
				"id": intersection(string(), unknown()).readonly(),
				"kind": literal("after").readonly(),
				"title": string().readonly(),
				"prompt": string().readonly(),
				"afterSeconds": number().readonly(),
				"scheduledAt": string().readonly()
			}),
			object({
				"id": intersection(string(), unknown()).readonly(),
				"kind": literal("at").readonly(),
				"title": string().readonly(),
				"prompt": string().readonly(),
				"scheduledAt": string().readonly()
			}),
			object({
				"id": intersection(string(), unknown()).readonly(),
				"kind": literal("every").readonly(),
				"title": string().readonly(),
				"prompt": string().readonly(),
				"everySeconds": number().readonly(),
				"scheduledAt": string().readonly()
			}),
			object({
				"id": intersection(string(), unknown()).readonly(),
				"kind": literal("daily").readonly(),
				"title": string().readonly(),
				"prompt": string().readonly(),
				"time": string().readonly(),
				"timeZone": string().readonly(),
				"scheduledAt": string().readonly()
			}),
			object({
				"id": intersection(string(), unknown()).readonly(),
				"kind": literal("weekly").readonly(),
				"title": string().readonly(),
				"prompt": string().readonly(),
				"time": string().readonly(),
				"timeZone": string().readonly(),
				"weekdays": array(number()).readonly(),
				"scheduledAt": string().readonly()
			}),
			object({
				"id": intersection(string(), unknown()).readonly(),
				"kind": literal("cron").readonly(),
				"title": string().readonly(),
				"prompt": string().readonly(),
				"expression": string().readonly(),
				"timeZone": string().readonly(),
				"scheduledAt": string().readonly()
			})
		]));
		let _deepseek_ai_dsh_schedule_schedule_update_parameter_0$schema$value;
		const _deepseek_ai_dsh_schedule_schedule_update_parameter_0$schema = () => _deepseek_ai_dsh_schedule_schedule_update_parameter_0$schema$value ??= object({
			"expected": union([
				object({
					"id": intersection(string(), unknown()).readonly(),
					"kind": literal("after").readonly(),
					"title": string().readonly(),
					"prompt": string().readonly(),
					"afterSeconds": number().readonly(),
					"scheduledAt": string().readonly()
				}),
				object({
					"id": intersection(string(), unknown()).readonly(),
					"kind": literal("at").readonly(),
					"title": string().readonly(),
					"prompt": string().readonly(),
					"scheduledAt": string().readonly()
				}),
				object({
					"id": intersection(string(), unknown()).readonly(),
					"kind": literal("every").readonly(),
					"title": string().readonly(),
					"prompt": string().readonly(),
					"everySeconds": number().readonly(),
					"scheduledAt": string().readonly()
				}),
				object({
					"id": intersection(string(), unknown()).readonly(),
					"kind": literal("daily").readonly(),
					"title": string().readonly(),
					"prompt": string().readonly(),
					"time": string().readonly(),
					"timeZone": string().readonly(),
					"scheduledAt": string().readonly()
				}),
				object({
					"id": intersection(string(), unknown()).readonly(),
					"kind": literal("weekly").readonly(),
					"title": string().readonly(),
					"prompt": string().readonly(),
					"time": string().readonly(),
					"timeZone": string().readonly(),
					"weekdays": array(number()).readonly(),
					"scheduledAt": string().readonly()
				}),
				object({
					"id": intersection(string(), unknown()).readonly(),
					"kind": literal("cron").readonly(),
					"title": string().readonly(),
					"prompt": string().readonly(),
					"expression": string().readonly(),
					"timeZone": string().readonly(),
					"scheduledAt": string().readonly()
				})
			]).readonly(),
			"change": union([
				object({
					"kind": literal("at").readonly(),
					"at": union([string(), object({
						"date": string().readonly(),
						"time": string().readonly(),
						"time_zone": string().readonly()
					})]).readonly()
				}),
				object({
					"kind": literal("every").readonly(),
					"every_seconds": number().readonly()
				}),
				object({
					"kind": literal("daily").readonly(),
					"daily": object({
						"time": string().readonly(),
						"time_zone": string().readonly()
					}).readonly()
				}),
				object({
					"kind": literal("weekly").readonly(),
					"weekly": object({
						"time": string().readonly(),
						"time_zone": string().readonly(),
						"weekdays": array(number()).readonly()
					}).readonly()
				}),
				object({
					"kind": literal("cron").readonly(),
					"cron": object({
						"expression": string().readonly(),
						"time_zone": string().readonly()
					}).readonly()
				})
			]).readonly().optional(),
			"id": intersection(string(), unknown()),
			"sessionId": intersection(string(), unknown()),
			"title": string().readonly().optional(),
			"prompt": string().readonly().optional()
		});
		let _deepseek_ai_dsh_schedule_schedule_update_result$schema$value;
		const _deepseek_ai_dsh_schedule_schedule_update_result$schema = () => _deepseek_ai_dsh_schedule_schedule_update_result$schema$value ??= union([
			object({
				"id": intersection(string(), unknown()).readonly(),
				"updated": boolean().readonly(),
				"record": union([
					object({
						"id": intersection(string(), unknown()).readonly(),
						"kind": literal("after").readonly(),
						"title": string().readonly(),
						"prompt": string().readonly(),
						"afterSeconds": number().readonly(),
						"scheduledAt": string().readonly()
					}),
					object({
						"id": intersection(string(), unknown()).readonly(),
						"kind": literal("at").readonly(),
						"title": string().readonly(),
						"prompt": string().readonly(),
						"scheduledAt": string().readonly()
					}),
					object({
						"id": intersection(string(), unknown()).readonly(),
						"kind": literal("every").readonly(),
						"title": string().readonly(),
						"prompt": string().readonly(),
						"everySeconds": number().readonly(),
						"scheduledAt": string().readonly()
					}),
					object({
						"id": intersection(string(), unknown()).readonly(),
						"kind": literal("daily").readonly(),
						"title": string().readonly(),
						"prompt": string().readonly(),
						"time": string().readonly(),
						"timeZone": string().readonly(),
						"scheduledAt": string().readonly()
					}),
					object({
						"id": intersection(string(), unknown()).readonly(),
						"kind": literal("weekly").readonly(),
						"title": string().readonly(),
						"prompt": string().readonly(),
						"time": string().readonly(),
						"timeZone": string().readonly(),
						"weekdays": array(number()).readonly(),
						"scheduledAt": string().readonly()
					}),
					object({
						"id": intersection(string(), unknown()).readonly(),
						"kind": literal("cron").readonly(),
						"title": string().readonly(),
						"prompt": string().readonly(),
						"expression": string().readonly(),
						"timeZone": string().readonly(),
						"scheduledAt": string().readonly()
					})
				]).readonly()
			}),
			object({
				"id": intersection(string(), unknown()).readonly(),
				"updated": literal(false).readonly(),
				"code": union([
					literal("schedule_not_found"),
					literal("schedule_ended"),
					literal("schedule_conflict")
				]).readonly()
			}),
			object({
				"code": literal("invalid_prompt").readonly(),
				"message": string().readonly()
			}),
			object({
				"code": literal("invalid_selector").readonly(),
				"message": string().readonly()
			}),
			object({
				"code": literal("invalid_rule").readonly(),
				"message": string().readonly()
			}),
			object({
				"code": literal("invalid_time_zone").readonly(),
				"message": string().readonly()
			}),
			object({
				"code": literal("not_future").readonly(),
				"message": string().readonly()
			}),
			object({
				"code": literal("time_out_of_range").readonly(),
				"message": string().readonly()
			}),
			object({
				"code": literal("frequency_too_high").readonly(),
				"message": string().readonly()
			}),
			object({
				"code": literal("internal_error").readonly(),
				"message": string().readonly()
			})
		]);
		const TYPERT_REMOTE$16 = {
			package: "@deepseek-ai/dsh-schedule",
			descriptors: [
				{
					id: "@deepseek-ai/dsh-schedule#schedule/catalog",
					service: "schedule",
					namespace: "schedule",
					method: "catalog",
					invocation: { kind: "direct" },
					parameters: [],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-schedule#schedule/catalog:result",
						create: _deepseek_ai_dsh_schedule_schedule_catalog_result$schema
					},
					sourceLocation: {
						"file": "packages/schedule/schedule/src/index.ts",
						"line": 304,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-schedule#schedule/delete",
					service: "schedule",
					namespace: "schedule",
					method: "delete",
					invocation: { kind: "direct" },
					parameters: [{
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-schedule/client#ScheduleDeleteRequest",
							create: _deepseek_ai_dsh_schedule_schedule_delete_parameter_0$schema
						}
					}],
					cancellation: { parameter: "signal" },
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-schedule/client#ScheduleDeleteResult",
						create: _deepseek_ai_dsh_schedule_schedule_delete_result$schema
					},
					sourceLocation: {
						"file": "packages/schedule/schedule/src/index.ts",
						"line": 343,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-schedule#schedule/history",
					service: "schedule",
					namespace: "schedule",
					method: "history",
					invocation: { kind: "direct" },
					parameters: [{
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-schedule/client#ScheduleDeliveryHistoryRequest",
							create: _deepseek_ai_dsh_schedule_schedule_history_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-schedule/client#ScheduleDeliveryHistoryResult",
						create: _deepseek_ai_dsh_schedule_schedule_history_result$schema
					},
					sourceLocation: {
						"file": "packages/schedule/schedule/src/index.ts",
						"line": 322,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-schedule#schedule/list",
					service: "schedule",
					namespace: "schedule",
					method: "list",
					invocation: { kind: "direct" },
					parameters: [{
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-schedule/client#ScheduleListRequest",
							create: _deepseek_ai_dsh_schedule_schedule_list_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-schedule#schedule/list:result",
						create: _deepseek_ai_dsh_schedule_schedule_list_result$schema
					},
					sourceLocation: {
						"file": "packages/schedule/schedule/src/index.ts",
						"line": 290,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-schedule#schedule/update",
					service: "schedule",
					namespace: "schedule",
					method: "update",
					invocation: { kind: "direct" },
					parameters: [{
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-schedule/client#ScheduleUpdateRequest",
							create: _deepseek_ai_dsh_schedule_schedule_update_parameter_0$schema
						}
					}],
					cancellation: { parameter: "signal" },
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-schedule/client#ScheduleUpdateResult",
						create: _deepseek_ai_dsh_schedule_schedule_update_result$schema
					},
					sourceLocation: {
						"file": "packages/schedule/schedule/src/index.ts",
						"line": 370,
						"column": 9
					}
				}
			]
		};
		//#endregion
		//#region ../../llm/llm/lib/typert.remote-client.js
		let _deepseek_ai_dsh_llm_llm_discoverModels_parameter_0$schema$value;
		const _deepseek_ai_dsh_llm_llm_discoverModels_parameter_0$schema = () => _deepseek_ai_dsh_llm_llm_discoverModels_parameter_0$schema$value ??= string();
		let _deepseek_ai_dsh_llm_llm_discoverModels_parameter_1$schema$value;
		const _deepseek_ai_dsh_llm_llm_discoverModels_parameter_1$schema = () => _deepseek_ai_dsh_llm_llm_discoverModels_parameter_1$schema$value ??= object({
			"provider": string().optional(),
			"baseURL": string().optional(),
			"api": string().optional(),
			"apiKey": string().optional()
		});
		let _deepseek_ai_dsh_llm_llm_discoverModels_result$schema$value;
		const _deepseek_ai_dsh_llm_llm_discoverModels_result$schema = () => _deepseek_ai_dsh_llm_llm_discoverModels_result$schema$value ??= array(object({
			"id": string(),
			"name": string().optional(),
			"contextWindow": number().optional(),
			"maxTokens": number().optional(),
			"inputModalities": array(union([literal("text"), literal("image")])).optional()
		}));
		let _deepseek_ai_dsh_llm_llm_listConfigurableProviders_result$schema$value;
		const _deepseek_ai_dsh_llm_llm_listConfigurableProviders_result$schema = () => _deepseek_ai_dsh_llm_llm_listConfigurableProviders_result$schema$value ??= array(object({
			"provider": string(),
			"displayName": string(),
			"settingsNs": string(),
			"settingsPath": array(string()),
			"declared": boolean().optional(),
			"error": string().optional()
		}));
		let _deepseek_ai_dsh_llm_llm_listProviders_result$schema$value;
		const _deepseek_ai_dsh_llm_llm_listProviders_result$schema = () => _deepseek_ai_dsh_llm_llm_listProviders_result$schema$value ??= array(object({
			"id": string(),
			"name": string()
		}));
		const TYPERT_REMOTE$15 = {
			package: "@deepseek-ai/dsh-llm",
			descriptors: [
				{
					id: "@deepseek-ai/dsh-llm#llm/discoverModels",
					service: "llm",
					namespace: "llm",
					method: "discoverModels",
					implementation: "remoteDiscoverModels",
					invocation: { kind: "direct" },
					parameters: [{
						name: "settingsNs",
						wire: "settingsNs",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-llm#llm/discoverModels:settingsNs",
							create: _deepseek_ai_dsh_llm_llm_discoverModels_parameter_0$schema
						}
					}, {
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-llm/types#LlmModelDiscoveryRequest",
							create: _deepseek_ai_dsh_llm_llm_discoverModels_parameter_1$schema
						}
					}],
					cancellation: { parameter: "signal" },
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-llm#llm/discoverModels:result",
						create: _deepseek_ai_dsh_llm_llm_discoverModels_result$schema
					},
					sourceLocation: {
						"file": "packages/llm/llm/src/index.ts",
						"line": 638,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-llm#llm/listConfigurableProviders",
					service: "llm",
					namespace: "llm",
					method: "listConfigurableProviders",
					invocation: { kind: "direct" },
					parameters: [],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-llm#llm/listConfigurableProviders:result",
						create: _deepseek_ai_dsh_llm_llm_listConfigurableProviders_result$schema
					},
					sourceLocation: {
						"file": "packages/llm/llm/src/index.ts",
						"line": 550,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-llm#llm/listProviders",
					service: "llm",
					namespace: "llm",
					method: "listProviders",
					invocation: { kind: "direct" },
					parameters: [],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-llm#llm/listProviders:result",
						create: _deepseek_ai_dsh_llm_llm_listProviders_result$schema
					},
					sourceLocation: {
						"file": "packages/llm/llm/src/index.ts",
						"line": 478,
						"column": 3
					}
				}
			]
		};
		//#endregion
		//#region ../../extensions/cordis-host-runner/lib/typert.remote-client.js
		let JsonValueRemoteCodec$schema$value$1;
		const JsonValueRemoteCodec$schema$1 = () => JsonValueRemoteCodec$schema$value$1 ??= union([
			literal(null),
			string(),
			number(),
			literal(false),
			literal(true),
			array(lazy(() => JsonValueRemoteCodec$schema$1())),
			record(string(), lazy(() => JsonValueRemoteCodec$schema$1()))
		]);
		let JsonValueRemoteCodec$schema2$value$1;
		const JsonValueRemoteCodec$schema2$1 = () => JsonValueRemoteCodec$schema2$value$1 ??= union([
			literal(null),
			string(),
			number(),
			literal(false),
			literal(true),
			array(lazy(() => JsonValueRemoteCodec$schema2$1())),
			record(string(), lazy(() => JsonValueRemoteCodec$schema2$1()))
		]);
		let JsonValueRemoteCodec$schema3$value$1;
		const JsonValueRemoteCodec$schema3$1 = () => JsonValueRemoteCodec$schema3$value$1 ??= union([
			literal(null),
			string(),
			number(),
			literal(false),
			literal(true),
			array(lazy(() => JsonValueRemoteCodec$schema3$1())),
			record(string(), lazy(() => JsonValueRemoteCodec$schema3$1()))
		]);
		let JsonValueRemoteCodec$schema4$value$1;
		const JsonValueRemoteCodec$schema4$1 = () => JsonValueRemoteCodec$schema4$value$1 ??= union([
			literal(null),
			string(),
			number(),
			literal(false),
			literal(true),
			array(lazy(() => JsonValueRemoteCodec$schema4$1())),
			record(string(), lazy(() => JsonValueRemoteCodec$schema4$1()))
		]);
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_getClientCode_parameter_0$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_getClientCode_parameter_0$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_getClientCode_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_getClientCode_parameter_1$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_getClientCode_parameter_1$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_getClientCode_parameter_1$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_getClientCode_parameter_2$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_getClientCode_parameter_2$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_getClientCode_parameter_2$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_getClientCode_result$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_getClientCode_result$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_getClientCode_result$schema$value ??= object({
			"code": string(),
			"name": string(),
			"pluginId": intersection(string(), unknown()),
			"packageId": intersection(string(), unknown()),
			"pluginRunId": intersection(string(), unknown())
		});
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_inventory_result$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_inventory_result$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_inventory_result$schema$value ??= array(object({
			"pluginId": intersection(string(), unknown()),
			"agentId": intersection(string(), unknown()),
			"packages": array(object({
				"packageId": intersection(string(), unknown()),
				"name": string(),
				"purpose": string(),
				"hasHostHalf": boolean(),
				"hasClientHalf": boolean()
			})),
			"currentPackageId": intersection(string(), unknown()).optional(),
			"nextPackageId": intersection(string(), unknown()).optional(),
			"activeRun": object({
				"pluginRunId": intersection(string(), unknown()),
				"packageId": intersection(string(), unknown())
			}).optional(),
			"latestRun": object({
				"pluginRunId": intersection(string(), unknown()),
				"packageId": intersection(string(), unknown()),
				"mode": union([literal("run"), literal("update")]),
				"status": union([
					literal("cancelled"),
					literal("failed"),
					literal("running"),
					literal("rejected"),
					literal("awaiting-approval"),
					literal("starting-host"),
					literal("client-pending"),
					literal("waiting"),
					literal("stopped")
				]),
				"approvalRequestId": intersection(string(), unknown()).optional(),
				"requiresApproval": boolean().optional(),
				"host": object({
					"status": union([
						literal("failed"),
						literal("running"),
						literal("pending"),
						literal("waiting"),
						literal("stopped"),
						literal("absent")
					]),
					"waitingFor": array(string()),
					"error": string().optional()
				}),
				"client": object({
					"status": union([
						literal("failed"),
						literal("running"),
						literal("pending"),
						literal("waiting"),
						literal("stopped"),
						literal("absent")
					]),
					"waitingFor": array(string()),
					"error": string().optional()
				}),
				"error": object({
					"phase": union([
						literal("approval"),
						literal("host-load"),
						literal("host-apply"),
						literal("client-load"),
						literal("client-apply"),
						literal("client-render")
					]),
					"message": string(),
					"stack": string().optional(),
					"pluginId": intersection(string(), unknown()),
					"packageId": intersection(string(), unknown()),
					"pluginRunId": intersection(string(), unknown())
				}).optional()
			}).optional()
		}));
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_invoke_parameter_0$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_invoke_parameter_0$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_invoke_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_invoke_parameter_1$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_invoke_parameter_1$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_invoke_parameter_1$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_invoke_parameter_2$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_invoke_parameter_2$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_invoke_parameter_2$schema$value ??= string();
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_invoke_parameter_3$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_invoke_parameter_3$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_invoke_parameter_3$schema$value ??= union([
			literal(null),
			string(),
			number(),
			literal(false),
			literal(true),
			array(lazy(() => JsonValueRemoteCodec$schema3$1())),
			record(string(), lazy(() => JsonValueRemoteCodec$schema3$1()))
		]);
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_invoke_result$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_invoke_result$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_invoke_result$schema$value ??= union([object({
			"ok": literal(true),
			"value": union([
				literal(null),
				string(),
				number(),
				literal(false),
				literal(true),
				array(lazy(() => JsonValueRemoteCodec$schema4$1())),
				record(string(), lazy(() => JsonValueRemoteCodec$schema4$1()))
			])
		}), intersection(object({
			"ok": literal(false),
			"code": union([
				literal("plugin-not-running"),
				literal("stale-run"),
				literal("method-not-found"),
				literal("handler-error")
			])
		}), object({
			"message": string(),
			"stack": string().optional()
		}))]);
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportClientGuardFailure_parameter_0$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportClientGuardFailure_parameter_0$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportClientGuardFailure_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportClientGuardFailure_parameter_1$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportClientGuardFailure_parameter_1$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportClientGuardFailure_parameter_1$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportClientGuardFailure_parameter_2$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportClientGuardFailure_parameter_2$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportClientGuardFailure_parameter_2$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportClientGuardFailure_parameter_3$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportClientGuardFailure_parameter_3$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportClientGuardFailure_parameter_3$schema$value ??= object({
			"message": string(),
			"stack": string().optional()
		});
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportClientGuardFailure_result$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportClientGuardFailure_result$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportClientGuardFailure_result$schema$value ??= literal(null);
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportRenderFailure_parameter_0$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportRenderFailure_parameter_0$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportRenderFailure_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportRenderFailure_parameter_1$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportRenderFailure_parameter_1$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportRenderFailure_parameter_1$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportRenderFailure_parameter_2$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportRenderFailure_parameter_2$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportRenderFailure_parameter_2$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportRenderFailure_parameter_3$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportRenderFailure_parameter_3$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportRenderFailure_parameter_3$schema$value ??= object({
			"slot": string(),
			"message": string(),
			"stack": string().optional(),
			"abdicated": boolean()
		});
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportRenderFailure_result$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportRenderFailure_result$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportRenderFailure_result$schema$value ??= literal(null);
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveInspectQuery_parameter_0$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveInspectQuery_parameter_0$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveInspectQuery_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveInspectQuery_parameter_1$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveInspectQuery_parameter_1$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveInspectQuery_parameter_1$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveInspectQuery_parameter_2$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveInspectQuery_parameter_2$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveInspectQuery_parameter_2$schema$value ??= union([object({
			"ok": literal(true),
			"data": union([
				literal(null),
				string(),
				number(),
				literal(false),
				literal(true),
				array(lazy(() => JsonValueRemoteCodec$schema2$1())),
				record(string(), lazy(() => JsonValueRemoteCodec$schema2$1()))
			])
		}), object({
			"ok": literal(false),
			"reason": union([
				literal("cancelled"),
				literal("provider-missing"),
				literal("method-missing"),
				literal("invalid-input"),
				literal("provider-error")
			]),
			"message": string()
		})]);
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveInspectQuery_result$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveInspectQuery_result$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveInspectQuery_result$schema$value ??= object({ "accepted": boolean() });
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveRequestRun_parameter_0$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveRequestRun_parameter_0$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveRequestRun_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveRequestRun_parameter_1$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveRequestRun_parameter_1$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveRequestRun_parameter_1$schema$value ??= union([object({
			"ok": literal(true),
			"pluginRunId": intersection(string(), unknown()),
			"waitingFor": array(string()).optional()
		}), object({
			"ok": literal(false),
			"reason": union([
				literal("rejected"),
				literal("host-half-failed"),
				literal("client-half-failed")
			]),
			"pluginRunId": intersection(string(), unknown()).optional(),
			"startedHere": boolean().optional(),
			"message": string().optional(),
			"stack": string().optional()
		})]);
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveRequestRun_result$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveRequestRun_result$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveRequestRun_result$schema$value ??= object({ "accepted": boolean() });
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_0$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_0$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_1$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_1$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_1$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_2$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_2$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_2$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_3$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_3$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_3$schema$value ??= union([literal("run"), literal("update")]);
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_4$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_4$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_4$schema$value ??= union([literal(null), intersection(string(), unknown())]);
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_5$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_5$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_5$schema$value ??= boolean();
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_result$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_result$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_result$schema$value ??= union([object({
			"ok": literal(true),
			"pluginId": intersection(string(), unknown()),
			"packageId": intersection(string(), unknown()),
			"pluginRunId": intersection(string(), unknown()),
			"waitingFor": array(string()),
			"startedHere": boolean()
		}), intersection(object({ "ok": literal(false) }), object({
			"message": string(),
			"stack": string().optional()
		}))]);
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_settleUserRun_parameter_0$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_settleUserRun_parameter_0$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_settleUserRun_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_settleUserRun_parameter_1$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_settleUserRun_parameter_1$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_settleUserRun_parameter_1$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_settleUserRun_parameter_2$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_settleUserRun_parameter_2$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_settleUserRun_parameter_2$schema$value ??= union([object({
			"ok": literal(true),
			"pluginRunId": intersection(string(), unknown()),
			"waitingFor": array(string()).optional()
		}), object({
			"ok": literal(false),
			"reason": union([
				literal("rejected"),
				literal("host-half-failed"),
				literal("client-half-failed")
			]),
			"pluginRunId": intersection(string(), unknown()).optional(),
			"startedHere": boolean().optional(),
			"message": string().optional(),
			"stack": string().optional()
		})]);
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_settleUserRun_result$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_settleUserRun_result$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_settleUserRun_result$schema$value ??= union([object({
			"ok": literal(true),
			"status": union([
				literal("running"),
				literal("awaiting-approval"),
				literal("starting")
			]),
			"pluginId": intersection(string(), unknown()),
			"packageId": intersection(string(), unknown()),
			"pluginRunId": intersection(string(), unknown()),
			"waitingFor": array(string()),
			"clientWaitingFor": array(string()).optional(),
			"currentPackageId": intersection(string(), unknown()).optional(),
			"nextPackageId": intersection(string(), unknown()).optional(),
			"mode": union([literal("run"), literal("update")])
		}), object({
			"ok": literal(false),
			"reason": union([
				literal("cancelled"),
				literal("plugin-missing"),
				literal("rejected"),
				literal("host-half-failed"),
				literal("client-half-failed"),
				literal("package-missing"),
				literal("invalid-mode"),
				literal("transition-in-flight"),
				literal("not-running")
			]),
			"message": string(),
			"stack": string().optional()
		})]);
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_stopFromPanel_parameter_0$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_stopFromPanel_parameter_0$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_stopFromPanel_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_stopFromPanel_parameter_1$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_stopFromPanel_parameter_1$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_stopFromPanel_parameter_1$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_stopFromPanel_result$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_stopFromPanel_result$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_stopFromPanel_result$schema$value ??= union([object({ "ok": literal(true) }), object({
			"ok": literal(false),
			"reason": union([literal("plugin-missing"), literal("not-running")]),
			"message": string()
		})]);
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_syncInspectManifest_parameter_0$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_syncInspectManifest_parameter_0$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_syncInspectManifest_parameter_0$schema$value ??= array(object({
			"id": string(),
			"description": string(),
			"methods": array(object({
				"name": string(),
				"description": string(),
				"inputSchema": union([
					literal(null),
					string(),
					number(),
					literal(false),
					literal(true),
					array(lazy(() => JsonValueRemoteCodec$schema$1())),
					record(string(), lazy(() => JsonValueRemoteCodec$schema$1()))
				]),
				"outputSchema": union([
					literal(null),
					string(),
					number(),
					literal(false),
					literal(true),
					array(lazy(() => JsonValueRemoteCodec$schema$1())),
					record(string(), lazy(() => JsonValueRemoteCodec$schema$1()))
				])
			}))
		}));
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_syncInspectManifest_result$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_syncInspectManifest_result$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_syncInspectManifest_result$schema$value ??= literal(null);
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_undefineFromPanel_parameter_0$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_undefineFromPanel_parameter_0$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_undefineFromPanel_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_undefineFromPanel_parameter_1$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_undefineFromPanel_parameter_1$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_undefineFromPanel_parameter_1$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_undefineFromPanel_result$schema$value;
		const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_undefineFromPanel_result$schema = () => _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_undefineFromPanel_result$schema$value ??= union([object({
			"ok": literal(true),
			"wasRunning": boolean()
		}), object({
			"ok": literal(false),
			"reason": literal("plugin-missing"),
			"message": string()
		})]);
		const TYPERT_REMOTE$14 = {
			package: "@deepseek-ai/dsh-cordis-host-runner",
			descriptors: [
				{
					id: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/getClientCode",
					service: "dynamicCordisRunner",
					namespace: "dynamicCordisRunner",
					method: "getClientCode",
					invocation: { kind: "direct" },
					scope: {
						context: "agent",
						wire: "agentId"
					},
					parameters: [
						{
							name: "agent",
							wire: "agentId",
							source: "lookup",
							lookup: "agent",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
								create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_getClientCode_parameter_0$schema
							}
						},
						{
							name: "pluginId",
							wire: "pluginId",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisDynamicPluginId",
								create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_getClientCode_parameter_1$schema
							}
						},
						{
							name: "pluginRunId",
							wire: "pluginRunId",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisDynamicPluginRunId",
								create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_getClientCode_parameter_2$schema
							}
						}
					],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#DynamicCordisClientSource",
						create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_getClientCode_result$schema
					},
					sourceLocation: {
						"file": "packages/extensions/cordis-host-runner/src/index.ts",
						"line": 392,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/inventory",
					service: "dynamicCordisRunner",
					namespace: "dynamicCordisRunner",
					method: "inventory",
					invocation: { kind: "direct" },
					parameters: [],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/inventory:result",
						create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_inventory_result$schema
					},
					sourceLocation: {
						"file": "packages/extensions/cordis-host-runner/src/index.ts",
						"line": 534,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/invoke",
					service: "dynamicCordisRunner",
					namespace: "dynamicCordisRunner",
					method: "invoke",
					invocation: { kind: "direct" },
					parameters: [
						{
							name: "pluginId",
							wire: "pluginId",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisDynamicPluginId",
								create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_invoke_parameter_0$schema
							}
						},
						{
							name: "pluginRunId",
							wire: "pluginRunId",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisDynamicPluginRunId",
								create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_invoke_parameter_1$schema
							}
						},
						{
							name: "method",
							wire: "method",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/invoke:method",
								create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_invoke_parameter_2$schema
							}
						},
						{
							name: "args",
							wire: "args",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-util-values#JsonValue",
								create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_invoke_parameter_3$schema
							}
						}
					],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#DynamicCordisInvokeResult",
						create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_invoke_result$schema
					},
					sourceLocation: {
						"file": "packages/extensions/cordis-host-runner/src/index.ts",
						"line": 750,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/reportClientGuardFailure",
					service: "dynamicCordisRunner",
					namespace: "dynamicCordisRunner",
					method: "reportClientGuardFailure",
					invocation: { kind: "direct" },
					scope: {
						context: "agent",
						wire: "agentId"
					},
					parameters: [
						{
							name: "agent",
							wire: "agentId",
							source: "lookup",
							lookup: "agent",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
								create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportClientGuardFailure_parameter_0$schema
							}
						},
						{
							name: "pluginId",
							wire: "pluginId",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisDynamicPluginId",
								create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportClientGuardFailure_parameter_1$schema
							}
						},
						{
							name: "pluginRunId",
							wire: "pluginRunId",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisDynamicPluginRunId",
								create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportClientGuardFailure_parameter_2$schema
							}
						},
						{
							name: "failure",
							wire: "failure",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisErrorDetails",
								create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportClientGuardFailure_parameter_3$schema
							}
						}
					],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/reportClientGuardFailure:result",
						create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportClientGuardFailure_result$schema
					},
					sourceLocation: {
						"file": "packages/extensions/cordis-host-runner/src/index.ts",
						"line": 727,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/reportRenderFailure",
					service: "dynamicCordisRunner",
					namespace: "dynamicCordisRunner",
					method: "reportRenderFailure",
					invocation: { kind: "direct" },
					scope: {
						context: "agent",
						wire: "agentId"
					},
					parameters: [
						{
							name: "agent",
							wire: "agentId",
							source: "lookup",
							lookup: "agent",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
								create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportRenderFailure_parameter_0$schema
							}
						},
						{
							name: "pluginId",
							wire: "pluginId",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisDynamicPluginId",
								create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportRenderFailure_parameter_1$schema
							}
						},
						{
							name: "pluginRunId",
							wire: "pluginRunId",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisDynamicPluginRunId",
								create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportRenderFailure_parameter_2$schema
							}
						},
						{
							name: "failure",
							wire: "failure",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#DynamicCordisRenderFailure",
								create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportRenderFailure_parameter_3$schema
							}
						}
					],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/reportRenderFailure:result",
						create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportRenderFailure_result$schema
					},
					sourceLocation: {
						"file": "packages/extensions/cordis-host-runner/src/index.ts",
						"line": 693,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/resolveInspectQuery",
					service: "dynamicCordisRunner",
					namespace: "dynamicCordisRunner",
					method: "resolveInspectQuery",
					invocation: { kind: "direct" },
					scope: {
						context: "agent",
						wire: "agentId"
					},
					parameters: [
						{
							name: "agent",
							wire: "agentId",
							source: "lookup",
							lookup: "agent",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
								create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveInspectQuery_parameter_0$schema
							}
						},
						{
							name: "requestId",
							wire: "requestId",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisInspectRequestId",
								create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveInspectQuery_parameter_1$schema
							}
						},
						{
							name: "resolution",
							wire: "resolution",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisInspectQueryResolution",
								create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveInspectQuery_parameter_2$schema
							}
						}
					],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisInspectResolveAck",
						create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveInspectQuery_result$schema
					},
					sourceLocation: {
						"file": "packages/extensions/cordis-host-runner/src/index.ts",
						"line": 520,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/resolveRequestRun",
					service: "dynamicCordisRunner",
					namespace: "dynamicCordisRunner",
					method: "resolveRequestRun",
					invocation: { kind: "direct" },
					parameters: [{
						name: "requestId",
						wire: "requestId",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#ApprovalRequestId",
							create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveRequestRun_parameter_0$schema
						}
					}, {
						name: "resolution",
						wire: "resolution",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#DynamicCordisRunResolution",
							create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveRequestRun_parameter_1$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#DynamicCordisResolveAck",
						create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveRequestRun_result$schema
					},
					sourceLocation: {
						"file": "packages/extensions/cordis-host-runner/src/index.ts",
						"line": 421,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/runHostHalf",
					service: "dynamicCordisRunner",
					namespace: "dynamicCordisRunner",
					method: "runHostHalf",
					invocation: { kind: "direct" },
					scope: {
						context: "agent",
						wire: "agentId"
					},
					parameters: [
						{
							name: "agent",
							wire: "agentId",
							source: "lookup",
							lookup: "agent",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
								create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_0$schema
							}
						},
						{
							name: "pluginId",
							wire: "pluginId",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisDynamicPluginId",
								create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_1$schema
							}
						},
						{
							name: "packageId",
							wire: "packageId",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisDynamicPackageId",
								create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_2$schema
							}
						},
						{
							name: "mode",
							wire: "mode",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisDynamicRunMode",
								create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_3$schema
							}
						},
						{
							name: "requestId",
							wire: "requestId",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/runHostHalf:requestId",
								create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_4$schema
							}
						},
						{
							name: "approveFutureVersions",
							wire: "approveFutureVersions",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/runHostHalf:approveFutureVersions",
								create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_5$schema
							}
						}
					],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#DynamicCordisHostHalfResult",
						create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_result$schema
					},
					sourceLocation: {
						"file": "packages/extensions/cordis-host-runner/src/index.ts",
						"line": 333,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/settleUserRun",
					service: "dynamicCordisRunner",
					namespace: "dynamicCordisRunner",
					method: "settleUserRun",
					invocation: { kind: "direct" },
					scope: {
						context: "agent",
						wire: "agentId"
					},
					parameters: [
						{
							name: "agent",
							wire: "agentId",
							source: "lookup",
							lookup: "agent",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
								create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_settleUserRun_parameter_0$schema
							}
						},
						{
							name: "pluginId",
							wire: "pluginId",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisDynamicPluginId",
								create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_settleUserRun_parameter_1$schema
							}
						},
						{
							name: "resolution",
							wire: "resolution",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#DynamicCordisRunResolution",
								create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_settleUserRun_parameter_2$schema
							}
						}
					],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#DynamicCordisRunResponse",
						create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_settleUserRun_result$schema
					},
					sourceLocation: {
						"file": "packages/extensions/cordis-host-runner/src/index.ts",
						"line": 446,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/stopFromPanel",
					service: "dynamicCordisRunner",
					namespace: "dynamicCordisRunner",
					method: "stopFromPanel",
					invocation: { kind: "direct" },
					scope: {
						context: "agent",
						wire: "agentId"
					},
					parameters: [{
						name: "agent",
						wire: "agentId",
						source: "lookup",
						lookup: "agent",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
							create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_stopFromPanel_parameter_0$schema
						}
					}, {
						name: "pluginId",
						wire: "pluginId",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisDynamicPluginId",
							create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_stopFromPanel_parameter_1$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#DynamicCordisStopResponse",
						create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_stopFromPanel_result$schema
					},
					sourceLocation: {
						"file": "packages/extensions/cordis-host-runner/src/index.ts",
						"line": 488,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/syncInspectManifest",
					service: "dynamicCordisRunner",
					namespace: "dynamicCordisRunner",
					method: "syncInspectManifest",
					invocation: { kind: "direct" },
					parameters: [{
						name: "providers",
						wire: "providers",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/syncInspectManifest:providers",
							create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_syncInspectManifest_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/syncInspectManifest:result",
						create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_syncInspectManifest_result$schema
					},
					sourceLocation: {
						"file": "packages/extensions/cordis-host-runner/src/index.ts",
						"line": 506,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/undefineFromPanel",
					service: "dynamicCordisRunner",
					namespace: "dynamicCordisRunner",
					method: "undefineFromPanel",
					invocation: { kind: "direct" },
					scope: {
						context: "agent",
						wire: "agentId"
					},
					parameters: [{
						name: "agent",
						wire: "agentId",
						source: "lookup",
						lookup: "agent",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
							create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_undefineFromPanel_parameter_0$schema
						}
					}, {
						name: "pluginId",
						wire: "pluginId",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisDynamicPluginId",
							create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_undefineFromPanel_parameter_1$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#DynamicCordisUndefineReceipt",
						create: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_undefineFromPanel_result$schema
					},
					sourceLocation: {
						"file": "packages/extensions/cordis-host-runner/src/index.ts",
						"line": 235,
						"column": 9
					}
				}
			]
		};
		//#endregion
		//#region ../../boot/plugin-manager/lib/typert.remote-client.js
		let _deepseek_ai_dsh_plugin_manager_pluginManager_cancelInstall_parameter_0$schema$value;
		const _deepseek_ai_dsh_plugin_manager_pluginManager_cancelInstall_parameter_0$schema = () => _deepseek_ai_dsh_plugin_manager_pluginManager_cancelInstall_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_plugin_manager_pluginManager_cancelInstall_result$schema$value;
		const _deepseek_ai_dsh_plugin_manager_pluginManager_cancelInstall_result$schema = () => _deepseek_ai_dsh_plugin_manager_pluginManager_cancelInstall_result$schema$value ??= object({ "status": union([
			literal("cancelled"),
			literal("not-running"),
			literal("too-late")
		]).readonly() });
		let _deepseek_ai_dsh_plugin_manager_pluginManager_inspect_parameter_0$schema$value;
		const _deepseek_ai_dsh_plugin_manager_pluginManager_inspect_parameter_0$schema = () => _deepseek_ai_dsh_plugin_manager_pluginManager_inspect_parameter_0$schema$value ??= string();
		let _deepseek_ai_dsh_plugin_manager_pluginManager_inspect_parameter_1$schema$value;
		const _deepseek_ai_dsh_plugin_manager_pluginManager_inspect_parameter_1$schema = () => _deepseek_ai_dsh_plugin_manager_pluginManager_inspect_parameter_1$schema$value ??= union([_undefined(), object({ "registry": union([literal(null), string()]).readonly().optional() })]);
		let _deepseek_ai_dsh_plugin_manager_pluginManager_inspect_result$schema$value;
		const _deepseek_ai_dsh_plugin_manager_pluginManager_inspect_result$schema = () => _deepseek_ai_dsh_plugin_manager_pluginManager_inspect_result$schema$value ??= union([object({
			"status": literal("accepted").readonly(),
			"kind": union([
				literal("registry"),
				literal("path"),
				literal("git"),
				literal("tarball")
			]).readonly(),
			"name": string().readonly().optional(),
			"version": string().readonly().optional(),
			"description": string().readonly().optional(),
			"bundle": union([
				literal(null),
				literal(false),
				literal(true)
			]).readonly(),
			"registry": union([literal(null), string()]).readonly(),
			"host": string().readonly().optional()
		}), object({
			"status": literal("refused").readonly(),
			"problem": union([
				literal("network"),
				literal("unknown"),
				literal("invalid-spec"),
				literal("not-found"),
				literal("already-installed"),
				literal("not-a-package"),
				literal("not-a-bundle")
			]).readonly(),
			"reason": string().readonly(),
			"registries": array(union([literal(null), string()])).readonly().optional()
		})]);
		let _deepseek_ai_dsh_plugin_manager_pluginManager_installBundle_parameter_0$schema$value;
		const _deepseek_ai_dsh_plugin_manager_pluginManager_installBundle_parameter_0$schema = () => _deepseek_ai_dsh_plugin_manager_pluginManager_installBundle_parameter_0$schema$value ??= string();
		let _deepseek_ai_dsh_plugin_manager_pluginManager_installBundle_parameter_1$schema$value;
		const _deepseek_ai_dsh_plugin_manager_pluginManager_installBundle_parameter_1$schema = () => _deepseek_ai_dsh_plugin_manager_pluginManager_installBundle_parameter_1$schema$value ??= union([_undefined(), object({
			"enabled": boolean().optional(),
			"requestId": intersection(string(), unknown()).optional(),
			"approvedBuilds": array(string()).optional(),
			"registry": union([literal(null), string()]).optional()
		})]);
		let _deepseek_ai_dsh_plugin_manager_pluginManager_installBundle_result$schema$value;
		const _deepseek_ai_dsh_plugin_manager_pluginManager_installBundle_result$schema = () => _deepseek_ai_dsh_plugin_manager_pluginManager_installBundle_result$schema$value ??= object({
			"changed": boolean(),
			"application": union([
				literal("cancelled"),
				literal("failed"),
				literal("applied"),
				literal("restart-required"),
				literal("overridden")
			]),
			"stage": union([
				literal("remove"),
				literal("install"),
				literal("enable")
			]),
			"target": string(),
			"enabled": boolean().optional(),
			"error": object({
				"code": union([
					literal("management-required"),
					literal("unaddressable"),
					literal("unknown-plugin"),
					literal("invalid-spec"),
					literal("ambiguous-install"),
					literal("not-bundle"),
					literal("not-removable"),
					literal("stop-profile"),
					literal("bundle-in-use"),
					literal("stale-approval"),
					literal("incompatible-version"),
					literal("operation-error")
				]),
				"diagnostic": string().optional(),
				"incompatible": array(object({
					"name": string(),
					"version": string(),
					"runtimeVersion": string(),
					"peers": record(string(), string())
				})).optional()
			}).optional(),
			"warnings": array(string()).optional(),
			"packageResult": object({
				"exitCode": number(),
				"output": string(),
				"truncated": boolean(),
				"logPath": string(),
				"kind": union([
					literal("network"),
					literal("unknown"),
					literal("timeout"),
					literal("integrity"),
					literal("pnpm-missing"),
					literal("not-found"),
					literal("no-matching-version"),
					literal("disk-full"),
					literal("permission"),
					literal("build-blocked")
				]).optional(),
				"timedOut": boolean().optional(),
				"incompatible": array(object({
					"name": string(),
					"version": string(),
					"runtimeVersion": string(),
					"peers": record(string(), string())
				})).optional()
			}).optional(),
			"bundle": string().optional(),
			"pendingBuilds": array(string()).optional(),
			"approvedBuilds": array(string()).optional(),
			"registries": array(union([literal(null), string()])).optional(),
			"failedAt": union([literal("registry"), literal("spec-host")]).optional()
		});
		let _deepseek_ai_dsh_plugin_manager_pluginManager_listBundles_result$schema$value;
		const _deepseek_ai_dsh_plugin_manager_pluginManager_listBundles_result$schema = () => _deepseek_ai_dsh_plugin_manager_pluginManager_listBundles_result$schema$value ??= array(object({
			"name": string(),
			"version": string().optional(),
			"meta": object({
				"title": union([string(), intersection(object({ "en": string().readonly() }), record(string(), string()).readonly())]).readonly().optional(),
				"description": union([string(), intersection(object({ "en": string().readonly() }), record(string(), string()).readonly())]).readonly().optional(),
				"icon": string().readonly().optional(),
				"error": string().readonly().optional()
			}).optional(),
			"description": string().optional(),
			"enabled": boolean(),
			"installed": boolean(),
			"optional": boolean(),
			"removable": boolean(),
			"readOnlyReason": union([literal("management-required"), literal("unaddressable")]).optional(),
			"error": object({
				"code": union([
					literal("management-required"),
					literal("unaddressable"),
					literal("unknown-plugin"),
					literal("invalid-spec"),
					literal("ambiguous-install"),
					literal("not-bundle"),
					literal("not-removable"),
					literal("stop-profile"),
					literal("bundle-in-use"),
					literal("stale-approval"),
					literal("incompatible-version"),
					literal("operation-error")
				]),
				"diagnostic": string().optional(),
				"incompatible": array(object({
					"name": string(),
					"version": string(),
					"runtimeVersion": string(),
					"peers": record(string(), string())
				})).optional()
			}).optional(),
			"rows": array(object({
				"rowId": string(),
				"moduleName": string(),
				"meta": object({
					"title": union([string(), intersection(object({ "en": string().readonly() }), record(string(), string()).readonly())]).readonly().optional(),
					"description": union([string(), intersection(object({ "en": string().readonly() }), record(string(), string()).readonly())]).readonly().optional(),
					"icon": string().readonly().optional(),
					"error": string().readonly().optional()
				}).optional(),
				"entryId": intersection(string(), unknown()).optional()
			})),
			"overrides": array(string())
		}));
		let _deepseek_ai_dsh_plugin_manager_pluginManager_listPlugins_result$schema$value;
		const _deepseek_ai_dsh_plugin_manager_pluginManager_listPlugins_result$schema = () => _deepseek_ai_dsh_plugin_manager_pluginManager_listPlugins_result$schema$value ??= array(union([intersection(object({
			"entryId": intersection(string(), unknown()).readonly(),
			"moduleName": string().readonly(),
			"meta": object({
				"title": union([string(), intersection(object({ "en": string().readonly() }), record(string(), string()).readonly())]).readonly().optional(),
				"description": union([string(), intersection(object({ "en": string().readonly() }), record(string(), string()).readonly())]).readonly().optional(),
				"icon": string().readonly().optional(),
				"error": string().readonly().optional()
			}).readonly().optional(),
			"enabled": boolean().readonly(),
			"fiberPhase": union([
				literal(null),
				literal("failed"),
				literal("pending"),
				literal("active"),
				literal("loading"),
				literal("unloading")
			]).readonly()
		}), object({
			"patchId": string(),
			"readOnlyReason": never().optional()
		})), intersection(object({
			"entryId": intersection(string(), unknown()).readonly(),
			"moduleName": string().readonly(),
			"meta": object({
				"title": union([string(), intersection(object({ "en": string().readonly() }), record(string(), string()).readonly())]).readonly().optional(),
				"description": union([string(), intersection(object({ "en": string().readonly() }), record(string(), string()).readonly())]).readonly().optional(),
				"icon": string().readonly().optional(),
				"error": string().readonly().optional()
			}).readonly().optional(),
			"enabled": boolean().readonly(),
			"fiberPhase": union([
				literal(null),
				literal("failed"),
				literal("pending"),
				literal("active"),
				literal("loading"),
				literal("unloading")
			]).readonly()
		}), object({
			"patchId": never().optional(),
			"readOnlyReason": union([literal("management-required"), literal("unaddressable")])
		}))]));
		let _deepseek_ai_dsh_plugin_manager_pluginManager_listVersionExemptions_result$schema$value;
		const _deepseek_ai_dsh_plugin_manager_pluginManager_listVersionExemptions_result$schema = () => _deepseek_ai_dsh_plugin_manager_pluginManager_listVersionExemptions_result$schema$value ??= object({
			"exemptions": record(string(), array(string())),
			"warnings": array(string())
		});
		let _deepseek_ai_dsh_plugin_manager_pluginManager_registries_result$schema$value;
		const _deepseek_ai_dsh_plugin_manager_pluginManager_registries_result$schema = () => _deepseek_ai_dsh_plugin_manager_pluginManager_registries_result$schema$value ??= object({
			"registry": union([literal(null), string()]).readonly(),
			"fallbackRegistries": array(string()).readonly(),
			"resolved": union([literal(null), string()]).readonly()
		});
		let _deepseek_ai_dsh_plugin_manager_pluginManager_removeBundle_parameter_0$schema$value;
		const _deepseek_ai_dsh_plugin_manager_pluginManager_removeBundle_parameter_0$schema = () => _deepseek_ai_dsh_plugin_manager_pluginManager_removeBundle_parameter_0$schema$value ??= string();
		let _deepseek_ai_dsh_plugin_manager_pluginManager_removeBundle_result$schema$value;
		const _deepseek_ai_dsh_plugin_manager_pluginManager_removeBundle_result$schema = () => _deepseek_ai_dsh_plugin_manager_pluginManager_removeBundle_result$schema$value ??= object({
			"changed": boolean(),
			"application": union([
				literal("cancelled"),
				literal("failed"),
				literal("applied"),
				literal("restart-required"),
				literal("overridden")
			]),
			"stage": union([
				literal("remove"),
				literal("install"),
				literal("enable")
			]),
			"target": string(),
			"enabled": boolean().optional(),
			"error": object({
				"code": union([
					literal("management-required"),
					literal("unaddressable"),
					literal("unknown-plugin"),
					literal("invalid-spec"),
					literal("ambiguous-install"),
					literal("not-bundle"),
					literal("not-removable"),
					literal("stop-profile"),
					literal("bundle-in-use"),
					literal("stale-approval"),
					literal("incompatible-version"),
					literal("operation-error")
				]),
				"diagnostic": string().optional(),
				"incompatible": array(object({
					"name": string(),
					"version": string(),
					"runtimeVersion": string(),
					"peers": record(string(), string())
				})).optional()
			}).optional(),
			"warnings": array(string()).optional(),
			"packageResult": object({
				"exitCode": number(),
				"output": string(),
				"truncated": boolean(),
				"logPath": string(),
				"kind": union([
					literal("network"),
					literal("unknown"),
					literal("timeout"),
					literal("integrity"),
					literal("pnpm-missing"),
					literal("not-found"),
					literal("no-matching-version"),
					literal("disk-full"),
					literal("permission"),
					literal("build-blocked")
				]).optional(),
				"timedOut": boolean().optional(),
				"incompatible": array(object({
					"name": string(),
					"version": string(),
					"runtimeVersion": string(),
					"peers": record(string(), string())
				})).optional()
			}).optional(),
			"bundle": string().optional(),
			"pendingBuilds": array(string()).optional(),
			"approvedBuilds": array(string()).optional(),
			"registries": array(union([literal(null), string()])).optional(),
			"failedAt": union([literal("registry"), literal("spec-host")]).optional()
		});
		let _deepseek_ai_dsh_plugin_manager_pluginManager_setBundleEnabled_parameter_0$schema$value;
		const _deepseek_ai_dsh_plugin_manager_pluginManager_setBundleEnabled_parameter_0$schema = () => _deepseek_ai_dsh_plugin_manager_pluginManager_setBundleEnabled_parameter_0$schema$value ??= string();
		let _deepseek_ai_dsh_plugin_manager_pluginManager_setBundleEnabled_parameter_1$schema$value;
		const _deepseek_ai_dsh_plugin_manager_pluginManager_setBundleEnabled_parameter_1$schema = () => _deepseek_ai_dsh_plugin_manager_pluginManager_setBundleEnabled_parameter_1$schema$value ??= boolean();
		let _deepseek_ai_dsh_plugin_manager_pluginManager_setBundleEnabled_result$schema$value;
		const _deepseek_ai_dsh_plugin_manager_pluginManager_setBundleEnabled_result$schema = () => _deepseek_ai_dsh_plugin_manager_pluginManager_setBundleEnabled_result$schema$value ??= object({
			"changed": boolean(),
			"application": union([
				literal("cancelled"),
				literal("failed"),
				literal("applied"),
				literal("restart-required"),
				literal("overridden")
			]),
			"stage": union([
				literal("remove"),
				literal("install"),
				literal("enable")
			]),
			"target": string(),
			"enabled": boolean().optional(),
			"error": object({
				"code": union([
					literal("management-required"),
					literal("unaddressable"),
					literal("unknown-plugin"),
					literal("invalid-spec"),
					literal("ambiguous-install"),
					literal("not-bundle"),
					literal("not-removable"),
					literal("stop-profile"),
					literal("bundle-in-use"),
					literal("stale-approval"),
					literal("incompatible-version"),
					literal("operation-error")
				]),
				"diagnostic": string().optional(),
				"incompatible": array(object({
					"name": string(),
					"version": string(),
					"runtimeVersion": string(),
					"peers": record(string(), string())
				})).optional()
			}).optional(),
			"warnings": array(string()).optional(),
			"packageResult": object({
				"exitCode": number(),
				"output": string(),
				"truncated": boolean(),
				"logPath": string(),
				"kind": union([
					literal("network"),
					literal("unknown"),
					literal("timeout"),
					literal("integrity"),
					literal("pnpm-missing"),
					literal("not-found"),
					literal("no-matching-version"),
					literal("disk-full"),
					literal("permission"),
					literal("build-blocked")
				]).optional(),
				"timedOut": boolean().optional(),
				"incompatible": array(object({
					"name": string(),
					"version": string(),
					"runtimeVersion": string(),
					"peers": record(string(), string())
				})).optional()
			}).optional(),
			"bundle": string().optional(),
			"pendingBuilds": array(string()).optional(),
			"approvedBuilds": array(string()).optional(),
			"registries": array(union([literal(null), string()])).optional(),
			"failedAt": union([literal("registry"), literal("spec-host")]).optional()
		});
		let _deepseek_ai_dsh_plugin_manager_pluginManager_setPluginEnabled_parameter_0$schema$value;
		const _deepseek_ai_dsh_plugin_manager_pluginManager_setPluginEnabled_parameter_0$schema = () => _deepseek_ai_dsh_plugin_manager_pluginManager_setPluginEnabled_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_plugin_manager_pluginManager_setPluginEnabled_parameter_1$schema$value;
		const _deepseek_ai_dsh_plugin_manager_pluginManager_setPluginEnabled_parameter_1$schema = () => _deepseek_ai_dsh_plugin_manager_pluginManager_setPluginEnabled_parameter_1$schema$value ??= boolean();
		let _deepseek_ai_dsh_plugin_manager_pluginManager_setPluginEnabled_result$schema$value;
		const _deepseek_ai_dsh_plugin_manager_pluginManager_setPluginEnabled_result$schema = () => _deepseek_ai_dsh_plugin_manager_pluginManager_setPluginEnabled_result$schema$value ??= object({
			"changed": boolean(),
			"application": union([
				literal("cancelled"),
				literal("failed"),
				literal("applied"),
				literal("restart-required"),
				literal("overridden")
			]),
			"stage": union([
				literal("remove"),
				literal("install"),
				literal("enable")
			]),
			"target": string(),
			"enabled": boolean().optional(),
			"error": object({
				"code": union([
					literal("management-required"),
					literal("unaddressable"),
					literal("unknown-plugin"),
					literal("invalid-spec"),
					literal("ambiguous-install"),
					literal("not-bundle"),
					literal("not-removable"),
					literal("stop-profile"),
					literal("bundle-in-use"),
					literal("stale-approval"),
					literal("incompatible-version"),
					literal("operation-error")
				]),
				"diagnostic": string().optional(),
				"incompatible": array(object({
					"name": string(),
					"version": string(),
					"runtimeVersion": string(),
					"peers": record(string(), string())
				})).optional()
			}).optional(),
			"warnings": array(string()).optional(),
			"packageResult": object({
				"exitCode": number(),
				"output": string(),
				"truncated": boolean(),
				"logPath": string(),
				"kind": union([
					literal("network"),
					literal("unknown"),
					literal("timeout"),
					literal("integrity"),
					literal("pnpm-missing"),
					literal("not-found"),
					literal("no-matching-version"),
					literal("disk-full"),
					literal("permission"),
					literal("build-blocked")
				]).optional(),
				"timedOut": boolean().optional(),
				"incompatible": array(object({
					"name": string(),
					"version": string(),
					"runtimeVersion": string(),
					"peers": record(string(), string())
				})).optional()
			}).optional(),
			"bundle": string().optional(),
			"pendingBuilds": array(string()).optional(),
			"approvedBuilds": array(string()).optional(),
			"registries": array(union([literal(null), string()])).optional(),
			"failedAt": union([literal("registry"), literal("spec-host")]).optional()
		});
		let _deepseek_ai_dsh_plugin_manager_pluginManager_setVersionExemption_parameter_0$schema$value;
		const _deepseek_ai_dsh_plugin_manager_pluginManager_setVersionExemption_parameter_0$schema = () => _deepseek_ai_dsh_plugin_manager_pluginManager_setVersionExemption_parameter_0$schema$value ??= string();
		let _deepseek_ai_dsh_plugin_manager_pluginManager_setVersionExemption_parameter_1$schema$value;
		const _deepseek_ai_dsh_plugin_manager_pluginManager_setVersionExemption_parameter_1$schema = () => _deepseek_ai_dsh_plugin_manager_pluginManager_setVersionExemption_parameter_1$schema$value ??= string();
		let _deepseek_ai_dsh_plugin_manager_pluginManager_setVersionExemption_parameter_2$schema$value;
		const _deepseek_ai_dsh_plugin_manager_pluginManager_setVersionExemption_parameter_2$schema = () => _deepseek_ai_dsh_plugin_manager_pluginManager_setVersionExemption_parameter_2$schema$value ??= boolean();
		let _deepseek_ai_dsh_plugin_manager_pluginManager_setVersionExemption_parameter_3$schema$value;
		const _deepseek_ai_dsh_plugin_manager_pluginManager_setVersionExemption_parameter_3$schema = () => _deepseek_ai_dsh_plugin_manager_pluginManager_setVersionExemption_parameter_3$schema$value ??= union([
			_undefined(),
			literal(false),
			literal(true)
		]);
		let _deepseek_ai_dsh_plugin_manager_pluginManager_setVersionExemption_result$schema$value;
		const _deepseek_ai_dsh_plugin_manager_pluginManager_setVersionExemption_result$schema = () => _deepseek_ai_dsh_plugin_manager_pluginManager_setVersionExemption_result$schema$value ??= object({
			"changed": boolean(),
			"application": union([
				literal("cancelled"),
				literal("failed"),
				literal("applied"),
				literal("restart-required"),
				literal("overridden")
			]),
			"stage": union([
				literal("remove"),
				literal("install"),
				literal("enable")
			]),
			"target": string(),
			"enabled": boolean().optional(),
			"error": object({
				"code": union([
					literal("management-required"),
					literal("unaddressable"),
					literal("unknown-plugin"),
					literal("invalid-spec"),
					literal("ambiguous-install"),
					literal("not-bundle"),
					literal("not-removable"),
					literal("stop-profile"),
					literal("bundle-in-use"),
					literal("stale-approval"),
					literal("incompatible-version"),
					literal("operation-error")
				]),
				"diagnostic": string().optional(),
				"incompatible": array(object({
					"name": string(),
					"version": string(),
					"runtimeVersion": string(),
					"peers": record(string(), string())
				})).optional()
			}).optional(),
			"warnings": array(string()).optional(),
			"packageResult": object({
				"exitCode": number(),
				"output": string(),
				"truncated": boolean(),
				"logPath": string(),
				"kind": union([
					literal("network"),
					literal("unknown"),
					literal("timeout"),
					literal("integrity"),
					literal("pnpm-missing"),
					literal("not-found"),
					literal("no-matching-version"),
					literal("disk-full"),
					literal("permission"),
					literal("build-blocked")
				]).optional(),
				"timedOut": boolean().optional(),
				"incompatible": array(object({
					"name": string(),
					"version": string(),
					"runtimeVersion": string(),
					"peers": record(string(), string())
				})).optional()
			}).optional(),
			"bundle": string().optional(),
			"pendingBuilds": array(string()).optional(),
			"approvedBuilds": array(string()).optional(),
			"registries": array(union([literal(null), string()])).optional(),
			"failedAt": union([literal("registry"), literal("spec-host")]).optional()
		});
		let _deepseek_ai_dsh_plugin_manager_pluginManager_waitForInstall_parameter_0$schema$value;
		const _deepseek_ai_dsh_plugin_manager_pluginManager_waitForInstall_parameter_0$schema = () => _deepseek_ai_dsh_plugin_manager_pluginManager_waitForInstall_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_plugin_manager_pluginManager_waitForInstall_result$schema$value;
		const _deepseek_ai_dsh_plugin_manager_pluginManager_waitForInstall_result$schema = () => _deepseek_ai_dsh_plugin_manager_pluginManager_waitForInstall_result$schema$value ??= union([literal(null), object({
			"changed": boolean(),
			"application": union([
				literal("cancelled"),
				literal("failed"),
				literal("applied"),
				literal("restart-required"),
				literal("overridden")
			]),
			"stage": union([
				literal("remove"),
				literal("install"),
				literal("enable")
			]),
			"target": string(),
			"enabled": boolean().optional(),
			"error": object({
				"code": union([
					literal("management-required"),
					literal("unaddressable"),
					literal("unknown-plugin"),
					literal("invalid-spec"),
					literal("ambiguous-install"),
					literal("not-bundle"),
					literal("not-removable"),
					literal("stop-profile"),
					literal("bundle-in-use"),
					literal("stale-approval"),
					literal("incompatible-version"),
					literal("operation-error")
				]),
				"diagnostic": string().optional(),
				"incompatible": array(object({
					"name": string(),
					"version": string(),
					"runtimeVersion": string(),
					"peers": record(string(), string())
				})).optional()
			}).optional(),
			"warnings": array(string()).optional(),
			"packageResult": object({
				"exitCode": number(),
				"output": string(),
				"truncated": boolean(),
				"logPath": string(),
				"kind": union([
					literal("network"),
					literal("unknown"),
					literal("timeout"),
					literal("integrity"),
					literal("pnpm-missing"),
					literal("not-found"),
					literal("no-matching-version"),
					literal("disk-full"),
					literal("permission"),
					literal("build-blocked")
				]).optional(),
				"timedOut": boolean().optional(),
				"incompatible": array(object({
					"name": string(),
					"version": string(),
					"runtimeVersion": string(),
					"peers": record(string(), string())
				})).optional()
			}).optional(),
			"bundle": string().optional(),
			"pendingBuilds": array(string()).optional(),
			"approvedBuilds": array(string()).optional(),
			"registries": array(union([literal(null), string()])).optional(),
			"failedAt": union([literal("registry"), literal("spec-host")]).optional()
		})]);
		const TYPERT_REMOTE$13 = {
			package: "@deepseek-ai/dsh-plugin-manager",
			descriptors: [
				{
					id: "@deepseek-ai/dsh-plugin-manager#pluginManager/cancelInstall",
					service: "pluginManager",
					namespace: "pluginManager",
					method: "cancelInstall",
					invocation: { kind: "direct" },
					parameters: [{
						name: "requestId",
						wire: "requestId",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-plugin-manager/types#PluginInstallRequestId",
							create: _deepseek_ai_dsh_plugin_manager_pluginManager_cancelInstall_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-plugin-manager/types#PluginInstallCancellation",
						create: _deepseek_ai_dsh_plugin_manager_pluginManager_cancelInstall_result$schema
					},
					sourceLocation: {
						"file": "packages/boot/plugin-manager/src/index.ts",
						"line": 585,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-plugin-manager#pluginManager/inspect",
					service: "pluginManager",
					namespace: "pluginManager",
					method: "inspect",
					invocation: { kind: "direct" },
					parameters: [{
						name: "spec",
						wire: "spec",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-plugin-manager#pluginManager/inspect:spec",
							create: _deepseek_ai_dsh_plugin_manager_pluginManager_inspect_parameter_0$schema
						}
					}, {
						name: "options",
						wire: "options",
						source: "json",
						acceptsUndefined: true,
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-plugin-manager/types#InspectOptions",
							create: _deepseek_ai_dsh_plugin_manager_pluginManager_inspect_parameter_1$schema
						}
					}],
					cancellation: { parameter: "signal" },
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-plugin-manager/types#PluginSpecInspection",
						create: _deepseek_ai_dsh_plugin_manager_pluginManager_inspect_result$schema
					},
					sourceLocation: {
						"file": "packages/boot/plugin-manager/src/index.ts",
						"line": 341,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-plugin-manager#pluginManager/installBundle",
					service: "pluginManager",
					namespace: "pluginManager",
					method: "installBundle",
					invocation: { kind: "direct" },
					parameters: [{
						name: "spec",
						wire: "spec",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-plugin-manager#pluginManager/installBundle:spec",
							create: _deepseek_ai_dsh_plugin_manager_pluginManager_installBundle_parameter_0$schema
						}
					}, {
						name: "options",
						wire: "options",
						source: "json",
						acceptsUndefined: true,
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-plugin-manager/types#InstallBundleOptions",
							create: _deepseek_ai_dsh_plugin_manager_pluginManager_installBundle_parameter_1$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-plugin-manager/types#ChangeResult",
						create: _deepseek_ai_dsh_plugin_manager_pluginManager_installBundle_result$schema
					},
					sourceLocation: {
						"file": "packages/boot/plugin-manager/src/index.ts",
						"line": 462,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-plugin-manager#pluginManager/listBundles",
					service: "pluginManager",
					namespace: "pluginManager",
					method: "listBundles",
					invocation: { kind: "direct" },
					parameters: [],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-plugin-manager#pluginManager/listBundles:result",
						create: _deepseek_ai_dsh_plugin_manager_pluginManager_listBundles_result$schema
					},
					sourceLocation: {
						"file": "packages/boot/plugin-manager/src/index.ts",
						"line": 280,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-plugin-manager#pluginManager/listPlugins",
					service: "pluginManager",
					namespace: "pluginManager",
					method: "listPlugins",
					invocation: { kind: "direct" },
					parameters: [],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-plugin-manager#pluginManager/listPlugins:result",
						create: _deepseek_ai_dsh_plugin_manager_pluginManager_listPlugins_result$schema
					},
					sourceLocation: {
						"file": "packages/boot/plugin-manager/src/index.ts",
						"line": 256,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-plugin-manager#pluginManager/listVersionExemptions",
					service: "pluginManager",
					namespace: "pluginManager",
					method: "listVersionExemptions",
					invocation: { kind: "direct" },
					parameters: [],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-plugin-manager#pluginManager/listVersionExemptions:result",
						create: _deepseek_ai_dsh_plugin_manager_pluginManager_listVersionExemptions_result$schema
					},
					sourceLocation: {
						"file": "packages/boot/plugin-manager/src/index.ts",
						"line": 232,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-plugin-manager#pluginManager/registries",
					service: "pluginManager",
					namespace: "pluginManager",
					method: "registries",
					invocation: { kind: "direct" },
					parameters: [],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-plugin-manager/types#PluginRegistries",
						create: _deepseek_ai_dsh_plugin_manager_pluginManager_registries_result$schema
					},
					sourceLocation: {
						"file": "packages/boot/plugin-manager/src/index.ts",
						"line": 325,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-plugin-manager#pluginManager/removeBundle",
					service: "pluginManager",
					namespace: "pluginManager",
					method: "removeBundle",
					invocation: { kind: "direct" },
					parameters: [{
						name: "name",
						wire: "name",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-plugin-manager#pluginManager/removeBundle:name",
							create: _deepseek_ai_dsh_plugin_manager_pluginManager_removeBundle_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-plugin-manager/types#ChangeResult",
						create: _deepseek_ai_dsh_plugin_manager_pluginManager_removeBundle_result$schema
					},
					sourceLocation: {
						"file": "packages/boot/plugin-manager/src/index.ts",
						"line": 601,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-plugin-manager#pluginManager/setBundleEnabled",
					service: "pluginManager",
					namespace: "pluginManager",
					method: "setBundleEnabled",
					invocation: { kind: "direct" },
					parameters: [{
						name: "name",
						wire: "name",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-plugin-manager#pluginManager/setBundleEnabled:name",
							create: _deepseek_ai_dsh_plugin_manager_pluginManager_setBundleEnabled_parameter_0$schema
						}
					}, {
						name: "enabled",
						wire: "enabled",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-plugin-manager#pluginManager/setBundleEnabled:enabled",
							create: _deepseek_ai_dsh_plugin_manager_pluginManager_setBundleEnabled_parameter_1$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-plugin-manager/types#ChangeResult",
						create: _deepseek_ai_dsh_plugin_manager_pluginManager_setBundleEnabled_result$schema
					},
					sourceLocation: {
						"file": "packages/boot/plugin-manager/src/index.ts",
						"line": 443,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-plugin-manager#pluginManager/setPluginEnabled",
					service: "pluginManager",
					namespace: "pluginManager",
					method: "setPluginEnabled",
					invocation: { kind: "direct" },
					parameters: [{
						name: "id",
						wire: "id",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-host-plugin-inventory/types#PluginEntryId",
							create: _deepseek_ai_dsh_plugin_manager_pluginManager_setPluginEnabled_parameter_0$schema
						}
					}, {
						name: "enabled",
						wire: "enabled",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-plugin-manager#pluginManager/setPluginEnabled:enabled",
							create: _deepseek_ai_dsh_plugin_manager_pluginManager_setPluginEnabled_parameter_1$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-plugin-manager/types#ChangeResult",
						create: _deepseek_ai_dsh_plugin_manager_pluginManager_setPluginEnabled_result$schema
					},
					sourceLocation: {
						"file": "packages/boot/plugin-manager/src/index.ts",
						"line": 425,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-plugin-manager#pluginManager/setVersionExemption",
					service: "pluginManager",
					namespace: "pluginManager",
					method: "setVersionExemption",
					invocation: { kind: "direct" },
					parameters: [
						{
							name: "packageVersion",
							wire: "packageVersion",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-plugin-manager#pluginManager/setVersionExemption:packageVersion",
								create: _deepseek_ai_dsh_plugin_manager_pluginManager_setVersionExemption_parameter_0$schema
							}
						},
						{
							name: "runtimeVersion",
							wire: "runtimeVersion",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-plugin-manager#pluginManager/setVersionExemption:runtimeVersion",
								create: _deepseek_ai_dsh_plugin_manager_pluginManager_setVersionExemption_parameter_1$schema
							}
						},
						{
							name: "enabled",
							wire: "enabled",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-plugin-manager#pluginManager/setVersionExemption:enabled",
								create: _deepseek_ai_dsh_plugin_manager_pluginManager_setVersionExemption_parameter_2$schema
							}
						},
						{
							name: "acceptRisk",
							wire: "acceptRisk",
							source: "json",
							acceptsUndefined: true,
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-plugin-manager#pluginManager/setVersionExemption:acceptRisk",
								create: _deepseek_ai_dsh_plugin_manager_pluginManager_setVersionExemption_parameter_3$schema
							}
						}
					],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-plugin-manager/types#ChangeResult",
						create: _deepseek_ai_dsh_plugin_manager_pluginManager_setVersionExemption_result$schema
					},
					sourceLocation: {
						"file": "packages/boot/plugin-manager/src/index.ts",
						"line": 245,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-plugin-manager#pluginManager/waitForInstall",
					service: "pluginManager",
					namespace: "pluginManager",
					method: "waitForInstall",
					invocation: { kind: "direct" },
					parameters: [{
						name: "requestId",
						wire: "requestId",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-plugin-manager/types#PluginInstallRequestId",
							create: _deepseek_ai_dsh_plugin_manager_pluginManager_waitForInstall_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-plugin-manager#pluginManager/waitForInstall:result",
						create: _deepseek_ai_dsh_plugin_manager_pluginManager_waitForInstall_result$schema
					},
					sourceLocation: {
						"file": "packages/boot/plugin-manager/src/index.ts",
						"line": 575,
						"column": 9
					}
				}
			]
		};
		//#endregion
		//#region ../../client/ui-plugin-manager/lib/typert.remote-client.js
		let _deepseek_ai_dsh_client_ui_plugin_manager_pluginRegistryProbe_fastest_result$schema$value;
		const _deepseek_ai_dsh_client_ui_plugin_manager_pluginRegistryProbe_fastest_result$schema = () => _deepseek_ai_dsh_client_ui_plugin_manager_pluginRegistryProbe_fastest_result$schema$value ??= union([literal(null), string()]);
		const TYPERT_REMOTE$12 = {
			package: "@deepseek-ai/dsh-client-ui-plugin-manager",
			descriptors: [{
				id: "@deepseek-ai/dsh-client-ui-plugin-manager#pluginRegistryProbe/fastest",
				service: "pluginRegistryProbe",
				namespace: "pluginRegistryProbe",
				method: "fastest",
				invocation: { kind: "direct" },
				parameters: [],
				result: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-client-ui-plugin-manager#pluginRegistryProbe/fastest:result",
					create: _deepseek_ai_dsh_client_ui_plugin_manager_pluginRegistryProbe_fastest_result$schema
				},
				sourceLocation: {
					"file": "packages/client/ui-plugin-manager/src/index.ts",
					"line": 51,
					"column": 9
				}
			}]
		};
		//#endregion
		//#region ../../host/plugin-inventory/lib/typert.remote-client.js
		let _deepseek_ai_dsh_host_plugin_inventory_pluginInventory_list_result$schema$value;
		const _deepseek_ai_dsh_host_plugin_inventory_pluginInventory_list_result$schema = () => _deepseek_ai_dsh_host_plugin_inventory_pluginInventory_list_result$schema$value ??= object({
			"managementAvailable": boolean().readonly().optional(),
			"entries": array(object({
				"entryId": intersection(string(), unknown()).readonly(),
				"moduleName": string().readonly(),
				"meta": object({
					"title": union([string(), intersection(object({ "en": string().readonly() }), record(string(), string()).readonly())]).readonly().optional(),
					"description": union([string(), intersection(object({ "en": string().readonly() }), record(string(), string()).readonly())]).readonly().optional(),
					"icon": string().readonly().optional(),
					"error": string().readonly().optional()
				}).readonly().optional(),
				"enabled": boolean().readonly(),
				"fiberPhase": union([
					literal(null),
					literal("failed"),
					literal("pending"),
					literal("active"),
					literal("loading"),
					literal("unloading")
				]).readonly()
			})).readonly(),
			"agentPresets": array(object({
				"id": string().readonly(),
				"name": string().readonly().optional(),
				"isDefault": boolean().readonly(),
				"broken": string().readonly().optional(),
				"rows": array(object({
					"entryId": union([literal(null), string()]).readonly(),
					"moduleName": string().readonly(),
					"meta": object({
						"title": union([string(), intersection(object({ "en": string().readonly() }), record(string(), string()).readonly())]).readonly().optional(),
						"description": union([string(), intersection(object({ "en": string().readonly() }), record(string(), string()).readonly())]).readonly().optional(),
						"icon": string().readonly().optional(),
						"error": string().readonly().optional()
					}).readonly().optional(),
					"enabled": union([
						literal(false),
						literal(true),
						literal("conditional")
					]).readonly(),
					"condition": string().readonly().optional(),
					"fiberPhase": union([
						literal(null),
						literal("failed"),
						literal("pending"),
						literal("active"),
						literal("loading"),
						literal("unloading")
					]).readonly()
				})).readonly()
			})).readonly().optional()
		});
		const TYPERT_REMOTE$11 = {
			package: "@deepseek-ai/dsh-host-plugin-inventory",
			descriptors: [{
				id: "@deepseek-ai/dsh-host-plugin-inventory#pluginInventory/list",
				service: "pluginInventory",
				namespace: "pluginInventory",
				method: "list",
				invocation: { kind: "direct" },
				parameters: [],
				result: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-host-plugin-inventory/types#PluginInventorySnapshot",
					create: _deepseek_ai_dsh_host_plugin_inventory_pluginInventory_list_result$schema
				},
				sourceLocation: {
					"file": "packages/host/plugin-inventory/src/index.ts",
					"line": 71,
					"column": 9
				}
			}]
		};
		//#endregion
		//#region ../../feedback/message-feedback/lib/typert.remote-client.js
		let _deepseek_ai_dsh_message_feedback_messageFeedback_delete_parameter_0$schema$value;
		const _deepseek_ai_dsh_message_feedback_messageFeedback_delete_parameter_0$schema = () => _deepseek_ai_dsh_message_feedback_messageFeedback_delete_parameter_0$schema$value ??= object({
			"sessionId": intersection(string(), unknown()).readonly(),
			"messageId": intersection(string(), unknown()).readonly(),
			"ifVersion": intersection(string(), unknown()).readonly()
		});
		let _deepseek_ai_dsh_message_feedback_messageFeedback_delete_result$schema$value;
		const _deepseek_ai_dsh_message_feedback_messageFeedback_delete_result$schema = () => _deepseek_ai_dsh_message_feedback_messageFeedback_delete_result$schema$value ??= union([object({
			"ok": literal(true).readonly(),
			"value": object({ "absent": literal(true).readonly() }).readonly()
		}), object({
			"ok": literal(false).readonly(),
			"error": union([object({
				"code": literal("session-not-found").readonly(),
				"sessionId": intersection(string(), unknown()).readonly()
			}), object({
				"code": literal("version-conflict").readonly(),
				"current": union([literal(null), object({
					"messageId": intersection(string(), unknown()).readonly(),
					"rating": union([literal("positive"), literal("negative")]).readonly(),
					"note": string().readonly().optional(),
					"category": union([
						literal("other"),
						literal("task-result"),
						literal("instruction-following"),
						literal("product-interaction"),
						literal("service-stability"),
						literal("resource-cost"),
						literal("security-privacy-permission")
					]).readonly().optional(),
					"version": intersection(string(), unknown()).readonly(),
					"createdAt": number().readonly(),
					"updatedAt": number().readonly()
				})]).readonly()
			})]).readonly()
		})]);
		let _deepseek_ai_dsh_message_feedback_messageFeedback_list_parameter_0$schema$value;
		const _deepseek_ai_dsh_message_feedback_messageFeedback_list_parameter_0$schema = () => _deepseek_ai_dsh_message_feedback_messageFeedback_list_parameter_0$schema$value ??= object({ "sessionId": intersection(string(), unknown()).readonly() });
		let _deepseek_ai_dsh_message_feedback_messageFeedback_list_result$schema$value;
		const _deepseek_ai_dsh_message_feedback_messageFeedback_list_result$schema = () => _deepseek_ai_dsh_message_feedback_messageFeedback_list_result$schema$value ??= union([object({
			"ok": literal(true).readonly(),
			"value": object({ "items": array(object({
				"messageId": intersection(string(), unknown()).readonly(),
				"rating": union([literal("positive"), literal("negative")]).readonly(),
				"note": string().readonly().optional(),
				"category": union([
					literal("other"),
					literal("task-result"),
					literal("instruction-following"),
					literal("product-interaction"),
					literal("service-stability"),
					literal("resource-cost"),
					literal("security-privacy-permission")
				]).readonly().optional(),
				"version": intersection(string(), unknown()).readonly(),
				"createdAt": number().readonly(),
				"updatedAt": number().readonly()
			})).readonly() }).readonly()
		}), object({
			"ok": literal(false).readonly(),
			"error": object({
				"code": literal("session-not-found").readonly(),
				"sessionId": intersection(string(), unknown()).readonly()
			}).readonly()
		})]);
		let _deepseek_ai_dsh_message_feedback_messageFeedback_put_parameter_0$schema$value;
		const _deepseek_ai_dsh_message_feedback_messageFeedback_put_parameter_0$schema = () => _deepseek_ai_dsh_message_feedback_messageFeedback_put_parameter_0$schema$value ??= object({
			"sessionId": intersection(string(), unknown()).readonly(),
			"messageId": intersection(string(), unknown()).readonly(),
			"rating": union([literal("positive"), literal("negative")]).readonly(),
			"note": string().readonly().optional(),
			"category": union([
				literal("other"),
				literal("task-result"),
				literal("instruction-following"),
				literal("product-interaction"),
				literal("service-stability"),
				literal("resource-cost"),
				literal("security-privacy-permission")
			]).readonly().optional(),
			"ifVersion": union([literal(null), intersection(string(), unknown())]).readonly()
		});
		let _deepseek_ai_dsh_message_feedback_messageFeedback_put_result$schema$value;
		const _deepseek_ai_dsh_message_feedback_messageFeedback_put_result$schema = () => _deepseek_ai_dsh_message_feedback_messageFeedback_put_result$schema$value ??= union([object({
			"ok": literal(true).readonly(),
			"value": object({
				"messageId": intersection(string(), unknown()).readonly(),
				"rating": union([literal("positive"), literal("negative")]).readonly(),
				"note": string().readonly().optional(),
				"category": union([
					literal("other"),
					literal("task-result"),
					literal("instruction-following"),
					literal("product-interaction"),
					literal("service-stability"),
					literal("resource-cost"),
					literal("security-privacy-permission")
				]).readonly().optional(),
				"version": intersection(string(), unknown()).readonly(),
				"createdAt": number().readonly(),
				"updatedAt": number().readonly()
			}).readonly()
		}), object({
			"ok": literal(false).readonly(),
			"error": union([
				object({
					"code": literal("session-not-found").readonly(),
					"sessionId": intersection(string(), unknown()).readonly()
				}),
				object({
					"code": literal("target-not-found").readonly(),
					"sessionId": intersection(string(), unknown()).readonly(),
					"messageId": intersection(string(), unknown()).readonly()
				}),
				object({
					"code": literal("version-conflict").readonly(),
					"current": union([literal(null), object({
						"messageId": intersection(string(), unknown()).readonly(),
						"rating": union([literal("positive"), literal("negative")]).readonly(),
						"note": string().readonly().optional(),
						"category": union([
							literal("other"),
							literal("task-result"),
							literal("instruction-following"),
							literal("product-interaction"),
							literal("service-stability"),
							literal("resource-cost"),
							literal("security-privacy-permission")
						]).readonly().optional(),
						"version": intersection(string(), unknown()).readonly(),
						"createdAt": number().readonly(),
						"updatedAt": number().readonly()
					})]).readonly()
				}),
				object({ "code": literal("note-blank").readonly() }),
				object({
					"code": literal("note-too-large").readonly(),
					"maxBytes": number().readonly(),
					"actualBytes": number().readonly()
				})
			]).readonly()
		})]);
		const TYPERT_REMOTE$10 = {
			package: "@deepseek-ai/dsh-message-feedback",
			descriptors: [
				{
					id: "@deepseek-ai/dsh-message-feedback#messageFeedback/delete",
					service: "messageFeedback",
					namespace: "messageFeedback",
					method: "delete",
					invocation: { kind: "direct" },
					parameters: [{
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-message-feedback/types#MessageFeedbackDeleteRequest",
							create: _deepseek_ai_dsh_message_feedback_messageFeedback_delete_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-message-feedback/types#MessageFeedbackDeleteResult",
						create: _deepseek_ai_dsh_message_feedback_messageFeedback_delete_result$schema
					},
					sourceLocation: {
						"file": "packages/feedback/message-feedback/src/index.ts",
						"line": 207,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-message-feedback#messageFeedback/list",
					service: "messageFeedback",
					namespace: "messageFeedback",
					method: "list",
					invocation: { kind: "direct" },
					parameters: [{
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-message-feedback/types#MessageFeedbackListRequest",
							create: _deepseek_ai_dsh_message_feedback_messageFeedback_list_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-message-feedback/types#MessageFeedbackListResult",
						create: _deepseek_ai_dsh_message_feedback_messageFeedback_list_result$schema
					},
					sourceLocation: {
						"file": "packages/feedback/message-feedback/src/index.ts",
						"line": 155,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-message-feedback#messageFeedback/put",
					service: "messageFeedback",
					namespace: "messageFeedback",
					method: "put",
					invocation: { kind: "direct" },
					parameters: [{
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-message-feedback/types#MessageFeedbackPutRequest",
							create: _deepseek_ai_dsh_message_feedback_messageFeedback_put_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-message-feedback/types#MessageFeedbackPutResult",
						create: _deepseek_ai_dsh_message_feedback_messageFeedback_put_result$schema
					},
					sourceLocation: {
						"file": "packages/feedback/message-feedback/src/index.ts",
						"line": 167,
						"column": 3
					}
				}
			]
		};
		//#endregion
		//#region ../../interaction/permission-presets/lib/typert.remote-client.js
		let _deepseek_ai_dsh_permission_presets_permissionPresets_catalog_result$schema$value;
		const _deepseek_ai_dsh_permission_presets_permissionPresets_catalog_result$schema = () => _deepseek_ai_dsh_permission_presets_permissionPresets_catalog_result$schema$value ??= object({
			"options": array(object({
				"value": string(),
				"name": string(),
				"description": string().optional()
			})),
			"defaultOptions": array(object({
				"value": string(),
				"name": string(),
				"description": string().optional()
			})),
			"defaultPreset": string()
		});
		const TYPERT_REMOTE$9 = {
			package: "@deepseek-ai/dsh-permission-presets",
			descriptors: [{
				id: "@deepseek-ai/dsh-permission-presets#permissionPresets/catalog",
				service: "permissionPresets",
				namespace: "permissionPresets",
				method: "catalog",
				invocation: { kind: "direct" },
				parameters: [],
				result: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-permission-presets/client#PermissionCatalog",
					create: _deepseek_ai_dsh_permission_presets_permissionPresets_catalog_result$schema
				},
				sourceLocation: {
					"file": "packages/interaction/permission-presets/src/index.ts",
					"line": 293,
					"column": 3
				}
			}]
		};
		//#endregion
		//#region ../../feedback/command-feedback/lib/typert.remote-client.js
		let _deepseek_ai_dsh_command_feedback_sessionFeedback_record_parameter_0$schema$value;
		const _deepseek_ai_dsh_command_feedback_sessionFeedback_record_parameter_0$schema = () => _deepseek_ai_dsh_command_feedback_sessionFeedback_record_parameter_0$schema$value ??= object({
			"sessionId": intersection(string(), unknown()).readonly(),
			"text": string().readonly().optional(),
			"category": union([
				literal("other"),
				literal("task-result"),
				literal("instruction-following"),
				literal("product-interaction"),
				literal("service-stability"),
				literal("resource-cost"),
				literal("security-privacy-permission")
			]).readonly().optional()
		});
		let _deepseek_ai_dsh_command_feedback_sessionFeedback_record_result$schema$value;
		const _deepseek_ai_dsh_command_feedback_sessionFeedback_record_result$schema = () => _deepseek_ai_dsh_command_feedback_sessionFeedback_record_result$schema$value ??= union([object({
			"ok": literal(true).readonly(),
			"value": object({ "recorded": literal(true).readonly() }).readonly()
		}), object({
			"ok": literal(false).readonly(),
			"error": object({
				"code": literal("session-not-found").readonly(),
				"sessionId": intersection(string(), unknown()).readonly()
			}).readonly()
		})]);
		const TYPERT_REMOTE$8 = {
			package: "@deepseek-ai/dsh-command-feedback",
			descriptors: [{
				id: "@deepseek-ai/dsh-command-feedback#sessionFeedback/record",
				service: "sessionFeedback",
				namespace: "sessionFeedback",
				method: "record",
				invocation: { kind: "direct" },
				parameters: [{
					name: "request",
					wire: "request",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-command-feedback/types#SessionFeedbackRecordRequest",
						create: _deepseek_ai_dsh_command_feedback_sessionFeedback_record_parameter_0$schema
					}
				}],
				result: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-command-feedback/types#SessionFeedbackRecordResult",
					create: _deepseek_ai_dsh_command_feedback_sessionFeedback_record_result$schema
				},
				sourceLocation: {
					"file": "packages/feedback/command-feedback/src/index.ts",
					"line": 102,
					"column": 3
				}
			}]
		};
		//#endregion
		//#region ../../client/file-upload/lib/typert.remote-client.js
		let _deepseek_ai_dsh_client_file_upload_fileUploads_upload_parameter_0$schema$value;
		const _deepseek_ai_dsh_client_file_upload_fileUploads_upload_parameter_0$schema = () => _deepseek_ai_dsh_client_file_upload_fileUploads_upload_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_client_file_upload_fileUploads_upload_parameter_1$schema$value;
		const _deepseek_ai_dsh_client_file_upload_fileUploads_upload_parameter_1$schema = () => _deepseek_ai_dsh_client_file_upload_fileUploads_upload_parameter_1$schema$value ??= object({
			"data": string().readonly(),
			"name": string().readonly().optional()
		});
		let _deepseek_ai_dsh_client_file_upload_fileUploads_upload_result$schema$value;
		const _deepseek_ai_dsh_client_file_upload_fileUploads_upload_result$schema = () => _deepseek_ai_dsh_client_file_upload_fileUploads_upload_result$schema$value ??= object({
			"receiptId": intersection(string(), unknown()).readonly(),
			"file": object({
				"attachmentId": intersection(string(), unknown()),
				"name": string(),
				"bytes": number()
			}).readonly()
		});
		const TYPERT_REMOTE$7 = {
			package: "@deepseek-ai/dsh-client-file-upload",
			descriptors: [{
				id: "@deepseek-ai/dsh-client-file-upload#fileUploads/upload",
				service: "fileUploads",
				namespace: "fileUploads",
				method: "upload",
				invocation: { kind: "direct" },
				scope: {
					context: "agent",
					wire: "agentId"
				},
				parameters: [{
					name: "agent",
					wire: "agentId",
					source: "lookup",
					lookup: "agent",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
						create: _deepseek_ai_dsh_client_file_upload_fileUploads_upload_parameter_0$schema
					}
				}, {
					name: "request",
					wire: "request",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-client-file-upload/types#EncodedFileUploadRequest",
						create: _deepseek_ai_dsh_client_file_upload_fileUploads_upload_parameter_1$schema
					}
				}],
				cancellation: { parameter: "signal" },
				result: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-client-file-upload/types#FileUploadValue",
					create: _deepseek_ai_dsh_client_file_upload_fileUploads_upload_result$schema
				},
				sourceLocation: {
					"file": "packages/client/file-upload/src/index.ts",
					"line": 106,
					"column": 3
				}
			}]
		};
		//#endregion
		//#region ../../context/session-reference/lib/typert.remote-client.js
		let _deepseek_ai_dsh_session_reference_sessionReferenceResolver_candidates_parameter_0$schema$value;
		const _deepseek_ai_dsh_session_reference_sessionReferenceResolver_candidates_parameter_0$schema = () => _deepseek_ai_dsh_session_reference_sessionReferenceResolver_candidates_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_session_reference_sessionReferenceResolver_candidates_parameter_1$schema$value;
		const _deepseek_ai_dsh_session_reference_sessionReferenceResolver_candidates_parameter_1$schema = () => _deepseek_ai_dsh_session_reference_sessionReferenceResolver_candidates_parameter_1$schema$value ??= string();
		let _deepseek_ai_dsh_session_reference_sessionReferenceResolver_candidates_result$schema$value;
		const _deepseek_ai_dsh_session_reference_sessionReferenceResolver_candidates_result$schema = () => _deepseek_ai_dsh_session_reference_sessionReferenceResolver_candidates_result$schema$value ??= array(object({
			"mention": string(),
			"sessionId": intersection(string(), unknown()),
			"label": string(),
			"displayTitle": string().optional(),
			"cwd": string().optional(),
			"sameWorkspace": boolean(),
			"createdAt": number()
		}));
		const TYPERT_REMOTE$6 = {
			package: "@deepseek-ai/dsh-session-reference",
			descriptors: [{
				id: "@deepseek-ai/dsh-session-reference#sessionReferenceResolver/candidates",
				service: "sessionReferenceResolver",
				namespace: "sessionReferenceResolver",
				method: "candidates",
				implementation: "remoteExportCandidates",
				invocation: { kind: "direct" },
				scope: {
					context: "agent",
					wire: "agentId"
				},
				parameters: [{
					name: "agent",
					wire: "agentId",
					source: "lookup",
					lookup: "agent",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
						create: _deepseek_ai_dsh_session_reference_sessionReferenceResolver_candidates_parameter_0$schema
					}
				}, {
					name: "query",
					wire: "query",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-session-reference#sessionReferenceResolver/candidates:query",
						create: _deepseek_ai_dsh_session_reference_sessionReferenceResolver_candidates_parameter_1$schema
					}
				}],
				cancellation: { parameter: "signal" },
				result: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-session-reference#sessionReferenceResolver/candidates:result",
					create: _deepseek_ai_dsh_session_reference_sessionReferenceResolver_candidates_result$schema
				},
				sourceLocation: {
					"file": "packages/context/session-reference/src/index.ts",
					"line": 272,
					"column": 9
				}
			}]
		};
		//#endregion
		//#region ../../subagent/subagent/lib/typert.remote-client.js
		let _deepseek_ai_dsh_subagent_subagents_interruptByParent_parameter_0$schema$value;
		const _deepseek_ai_dsh_subagent_subagents_interruptByParent_parameter_0$schema = () => _deepseek_ai_dsh_subagent_subagents_interruptByParent_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_subagent_subagents_interruptByParent_parameter_1$schema$value;
		const _deepseek_ai_dsh_subagent_subagents_interruptByParent_parameter_1$schema = () => _deepseek_ai_dsh_subagent_subagents_interruptByParent_parameter_1$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_subagent_subagents_interruptByParent_parameter_2$schema$value;
		const _deepseek_ai_dsh_subagent_subagents_interruptByParent_parameter_2$schema = () => _deepseek_ai_dsh_subagent_subagents_interruptByParent_parameter_2$schema$value ??= literal("continuable");
		let _deepseek_ai_dsh_subagent_subagents_interruptByParent_result$schema$value;
		const _deepseek_ai_dsh_subagent_subagents_interruptByParent_result$schema = () => _deepseek_ai_dsh_subagent_subagents_interruptByParent_result$schema$value ??= object({ "accepted": literal(true).readonly() });
		let _deepseek_ai_dsh_subagent_subagents_prompt_parameter_0$schema$value;
		const _deepseek_ai_dsh_subagent_subagents_prompt_parameter_0$schema = () => _deepseek_ai_dsh_subagent_subagents_prompt_parameter_0$schema$value ??= object({
			"requestId": intersection(string(), unknown()).readonly(),
			"parentSessionId": intersection(string(), unknown()).readonly(),
			"childSessionId": intersection(string(), unknown()).readonly(),
			"mode": literal("continuable").readonly(),
			"delivery": union([literal("queue"), literal("steer")]).readonly(),
			"content": array(union([object({
				"type": literal("text").readonly(),
				"text": string().readonly()
			}), object({
				"type": literal("image").readonly(),
				"mediaType": union([
					literal("image/png"),
					literal("image/jpeg"),
					literal("image/webp"),
					literal("image/gif")
				]).readonly(),
				"data": string().readonly(),
				"name": string().readonly().optional()
			})])).readonly(),
			"clientTimeZone": string().readonly().optional()
		});
		let _deepseek_ai_dsh_subagent_subagents_prompt_result$schema$value;
		const _deepseek_ai_dsh_subagent_subagents_prompt_result$schema = () => _deepseek_ai_dsh_subagent_subagents_prompt_result$schema$value ??= object({ "messageId": intersection(string(), unknown()).readonly() });
		const TYPERT_REMOTE$5 = {
			package: "@deepseek-ai/dsh-subagent",
			descriptors: [{
				id: "@deepseek-ai/dsh-subagent#subagents/interruptByParent",
				service: "subagents",
				namespace: "subagents",
				method: "interruptByParent",
				invocation: { kind: "direct" },
				parameters: [
					{
						name: "childSessionId",
						wire: "childSessionId",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
							create: _deepseek_ai_dsh_subagent_subagents_interruptByParent_parameter_0$schema
						}
					},
					{
						name: "parentSessionId",
						wire: "parentSessionId",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
							create: _deepseek_ai_dsh_subagent_subagents_interruptByParent_parameter_1$schema
						}
					},
					{
						name: "mode",
						wire: "mode",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-subagent#subagents/interruptByParent:mode",
							create: _deepseek_ai_dsh_subagent_subagents_interruptByParent_parameter_2$schema
						}
					}
				],
				result: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-subagent/client#SubagentInterruptReceipt",
					create: _deepseek_ai_dsh_subagent_subagents_interruptByParent_result$schema
				},
				sourceLocation: {
					"file": "packages/subagent/subagent/src/index.ts",
					"line": 483,
					"column": 3
				}
			}, {
				id: "@deepseek-ai/dsh-subagent#subagents/prompt",
				service: "subagents",
				namespace: "subagents",
				method: "prompt",
				invocation: { kind: "direct" },
				parameters: [{
					name: "request",
					wire: "request",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-subagent/client#SubagentPromptRequest",
						create: _deepseek_ai_dsh_subagent_subagents_prompt_parameter_0$schema
					}
				}],
				cancellation: { parameter: "signal" },
				result: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-subagent/client#SubagentPromptReceipt",
					create: _deepseek_ai_dsh_subagent_subagents_prompt_result$schema
				},
				sourceLocation: {
					"file": "packages/subagent/subagent/src/index.ts",
					"line": 416,
					"column": 9
				}
			}]
		};
		//#endregion
		//#region ../session-controller/lib/typert.remote-client.js
		let JsonValueRemoteCodec$schema$value;
		const JsonValueRemoteCodec$schema = () => JsonValueRemoteCodec$schema$value ??= union([
			literal(null),
			string(),
			number(),
			literal(false),
			literal(true),
			array(lazy(() => JsonValueRemoteCodec$schema())),
			record(string(), lazy(() => JsonValueRemoteCodec$schema()))
		]);
		let JsonValueRemoteCodec$schema2$value;
		const JsonValueRemoteCodec$schema2 = () => JsonValueRemoteCodec$schema2$value ??= union([
			literal(null),
			string(),
			number(),
			literal(false),
			literal(true),
			array(lazy(() => JsonValueRemoteCodec$schema2())),
			record(string(), lazy(() => JsonValueRemoteCodec$schema2()))
		]);
		let JsonValueRemoteCodec$schema3$value;
		const JsonValueRemoteCodec$schema3 = () => JsonValueRemoteCodec$schema3$value ??= union([
			literal(null),
			string(),
			number(),
			literal(false),
			literal(true),
			array(lazy(() => JsonValueRemoteCodec$schema3())),
			record(string(), lazy(() => JsonValueRemoteCodec$schema3()))
		]);
		let JsonValueRemoteCodec$schema4$value;
		const JsonValueRemoteCodec$schema4 = () => JsonValueRemoteCodec$schema4$value ??= union([
			literal(null),
			string(),
			number(),
			literal(false),
			literal(true),
			array(lazy(() => JsonValueRemoteCodec$schema4())),
			record(string(), lazy(() => JsonValueRemoteCodec$schema4()))
		]);
		let JsonValueRemoteCodec$schema5$value;
		const JsonValueRemoteCodec$schema5 = () => JsonValueRemoteCodec$schema5$value ??= union([
			literal(null),
			string(),
			number(),
			literal(false),
			literal(true),
			array(lazy(() => JsonValueRemoteCodec$schema5())),
			record(string(), lazy(() => JsonValueRemoteCodec$schema5()))
		]);
		let _deepseek_ai_dsh_api_session_controller_fileReferences_list_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_session_controller_fileReferences_list_parameter_0$schema = () => _deepseek_ai_dsh_api_session_controller_fileReferences_list_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_api_session_controller_fileReferences_list_parameter_1$schema$value;
		const _deepseek_ai_dsh_api_session_controller_fileReferences_list_parameter_1$schema = () => _deepseek_ai_dsh_api_session_controller_fileReferences_list_parameter_1$schema$value ??= string();
		let _deepseek_ai_dsh_api_session_controller_fileReferences_list_result$schema$value;
		const _deepseek_ai_dsh_api_session_controller_fileReferences_list_result$schema = () => _deepseek_ai_dsh_api_session_controller_fileReferences_list_result$schema$value ??= array(object({
			"path": string(),
			"kind": union([literal("file"), literal("directory")])
		}));
		let _deepseek_ai_dsh_api_session_controller_session_attachment_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_session_controller_session_attachment_parameter_0$schema = () => _deepseek_ai_dsh_api_session_controller_session_attachment_parameter_0$schema$value ??= object({
			"sessionId": intersection(string(), unknown()).readonly(),
			"attachmentId": intersection(string(), unknown()).readonly()
		});
		let _deepseek_ai_dsh_api_session_controller_session_attachment_result$schema$value;
		const _deepseek_ai_dsh_api_session_controller_session_attachment_result$schema = () => _deepseek_ai_dsh_api_session_controller_session_attachment_result$schema$value ??= object({
			"attachment": object({
				"attachmentId": intersection(string(), unknown()),
				"mediaType": union([
					literal("image/png"),
					literal("image/jpeg"),
					literal("image/webp"),
					literal("image/gif")
				]),
				"bytes": number(),
				"width": number(),
				"height": number(),
				"name": string().optional(),
				"originalDimensions": object({
					"width": number(),
					"height": number()
				}).optional()
			}).readonly(),
			"data": string().readonly()
		});
		let _deepseek_ai_dsh_api_session_controller_session_cancel_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_session_controller_session_cancel_parameter_0$schema = () => _deepseek_ai_dsh_api_session_controller_session_cancel_parameter_0$schema$value ??= object({ "sessionId": intersection(string(), unknown()).readonly() });
		let _deepseek_ai_dsh_api_session_controller_session_cancel_result$schema$value;
		const _deepseek_ai_dsh_api_session_controller_session_cancel_result$schema = () => _deepseek_ai_dsh_api_session_controller_session_cancel_result$schema$value ??= object({ "accepted": literal(true).readonly() });
		let _deepseek_ai_dsh_api_session_controller_session_canOpenWorkspacePath_result$schema$value;
		const _deepseek_ai_dsh_api_session_controller_session_canOpenWorkspacePath_result$schema = () => _deepseek_ai_dsh_api_session_controller_session_canOpenWorkspacePath_result$schema$value ??= boolean();
		let _deepseek_ai_dsh_api_session_controller_session_control_result$schema$value;
		const _deepseek_ai_dsh_api_session_controller_session_control_result$schema = () => _deepseek_ai_dsh_api_session_controller_session_control_result$schema$value ??= union([object({
			"type": literal("baseline").readonly(),
			"value": object({ "projections": record(intersection(string(), unknown()), object({
				"asOfSeq": number().readonly(),
				"values": intersection(object({
					"inbox": object({
						"next-turn": array(union([
							literal(null),
							string(),
							number(),
							literal(false),
							literal(true),
							array(lazy(() => JsonValueRemoteCodec$schema5())),
							record(string(), lazy(() => JsonValueRemoteCodec$schema5()))
						])).readonly(),
						"next-step": array(union([
							literal(null),
							string(),
							number(),
							literal(false),
							literal(true),
							array(lazy(() => JsonValueRemoteCodec$schema5())),
							record(string(), lazy(() => JsonValueRemoteCodec$schema5()))
						])).readonly()
					}).optional(),
					"agentPreset": union([literal(null), string()]).optional(),
					"title": union([literal(null), string()]).optional(),
					"todos": union([literal(null), array(object({
						"content": string(),
						"status": union([
							literal("completed"),
							literal("pending"),
							literal("in_progress")
						])
					}))]).optional(),
					"sessionListMetadata": object({
						"blank": boolean().readonly(),
						"lastPromptAt": union([literal(null), number()]).readonly()
					}).optional(),
					"imageLimits": object({
						"maxImageBytes": number(),
						"maxImagesPerMessage": number(),
						"maxMessageImageBytes": number(),
						"maxImagePixels": number(),
						"maxImageDimension": number(),
						"mediaTypes": array(union([
							literal("image/png"),
							literal("image/jpeg"),
							literal("image/webp"),
							literal("image/gif")
						]))
					}).optional(),
					"modelSelection": object({
						"lastUsed": union([literal(null), object({
							"provider": string().readonly(),
							"model": string().readonly(),
							"reasoningEffort": string().readonly().optional()
						})]).readonly(),
						"next": union([literal(null), object({
							"provider": string().readonly(),
							"model": string().readonly(),
							"reasoningEffort": string().readonly().optional()
						})]).readonly()
					}).optional(),
					"permissions": object({ "currentValue": string() }).optional(),
					"subagentCatalog": array(union([
						intersection(object({
							"id": intersection(string(), unknown()).readonly(),
							"createdAt": number().readonly()
						}), object({
							"mode": literal("one-shot").readonly(),
							"label": string().readonly().optional()
						})),
						intersection(object({
							"id": intersection(string(), unknown()).readonly(),
							"createdAt": number().readonly()
						}), object({
							"mode": literal("continuable").readonly(),
							"label": string().readonly()
						})),
						intersection(object({
							"id": intersection(string(), unknown()).readonly(),
							"createdAt": number().readonly()
						}), object({
							"mode": literal("unknown").readonly(),
							"label": string().readonly().optional()
						}))
					])).optional(),
					"subagentTiming": object({
						"settledMs": number(),
						"active": object({
							"since": number(),
							"through": number()
						}).optional(),
						"lastTurnCompleted": boolean().optional()
					}).optional(),
					"subagent": union([
						literal(null),
						object({
							"mode": literal("one-shot"),
							"label": string().optional(),
							"seq": intersection(number(), unknown())
						}),
						object({
							"mode": literal("continuable"),
							"label": string(),
							"seq": intersection(number(), unknown())
						})
					]).optional(),
					"goal": union([literal(null), object({
						"goal": object({
							"objective": string().readonly(),
							"phase": union([
								literal("active"),
								literal("paused"),
								literal("blocked"),
								literal("complete")
							]).readonly(),
							"blockedReason": object({
								"code": string().readonly(),
								"message": string().readonly()
							}).readonly().optional(),
							"maxGoalRounds": number().readonly(),
							"id": intersection(string(), unknown()).readonly(),
							"revision": number().readonly()
						}).readonly(),
						"roundsStarted": number().readonly(),
						"createdAt": number().readonly(),
						"updatedAt": number().readonly()
					})]).optional(),
					"userQuestions": object({
						"active": array(object({
							"callId": intersection(string(), unknown()).readonly(),
							"questions": array(object({
								"id": string(),
								"question": string(),
								"detail": string().optional(),
								"header": string().optional(),
								"options": array(object({
									"label": string(),
									"description": string().optional()
								})).optional(),
								"multiSelect": boolean().optional(),
								"intent": object({
									"kind": literal("plan-review"),
									"approve": string(),
									"callId": intersection(string(), unknown()).optional()
								}).optional()
							})).readonly(),
							"state": union([literal("open"), literal("continued")]).readonly()
						})).readonly(),
						"settled": array(object({
							"callId": intersection(string(), unknown()).readonly(),
							"answers": array(object({
								"id": string(),
								"selected": array(string()),
								"custom": string().optional()
							})).readonly()
						})).readonly()
					}).optional()
				}), record(string(), union([
					literal(null),
					string(),
					number(),
					literal(false),
					literal(true),
					array(lazy(() => JsonValueRemoteCodec$schema5())),
					record(string(), lazy(() => JsonValueRemoteCodec$schema5()))
				])).readonly()).readonly()
			})).readonly().readonly() }).readonly()
		}), intersection(object({ "type": literal("projection").readonly() }), object({
			"sessionId": intersection(string(), unknown()).readonly(),
			"key": string().readonly(),
			"value": union([
				literal(null),
				string(),
				number(),
				literal(false),
				literal(true),
				array(lazy(() => JsonValueRemoteCodec$schema5())),
				record(string(), lazy(() => JsonValueRemoteCodec$schema5()))
			]).readonly(),
			"seq": number().readonly()
		}))]);
		let _deepseek_ai_dsh_api_session_controller_session_create_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_session_controller_session_create_parameter_0$schema = () => _deepseek_ai_dsh_api_session_controller_session_create_parameter_0$schema$value ??= object({
			"workspaceId": intersection(string(), unknown()).readonly().optional(),
			"cwd": string().readonly().optional(),
			"sessionId": intersection(string(), unknown()).readonly().optional(),
			"agentPreset": string().readonly().optional()
		});
		let _deepseek_ai_dsh_api_session_controller_session_create_result$schema$value;
		const _deepseek_ai_dsh_api_session_controller_session_create_result$schema = () => _deepseek_ai_dsh_api_session_controller_session_create_result$schema$value ??= object({
			"sessionId": intersection(string(), unknown()).readonly(),
			"agentPreset": string().readonly().optional()
		});
		let _deepseek_ai_dsh_api_session_controller_session_follow_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_session_controller_session_follow_parameter_0$schema = () => _deepseek_ai_dsh_api_session_controller_session_follow_parameter_0$schema$value ??= object({
			"address": union([object({
				"kind": literal("session").readonly(),
				"sessionId": intersection(string(), unknown()).readonly()
			}), object({
				"kind": literal("subagent").readonly(),
				"parentSessionId": intersection(string(), unknown()).readonly(),
				"childSessionId": intersection(string(), unknown()).readonly(),
				"mode": union([
					literal("one-shot"),
					literal("continuable"),
					literal("unknown")
				]).readonly()
			})]).readonly(),
			"assistantStream": literal(true).readonly().optional(),
			"maxMessages": number().readonly().optional(),
			"turnWindow": object({
				"minMessages": number().readonly(),
				"minTurns": number().readonly()
			}).readonly().optional()
		});
		let _deepseek_ai_dsh_api_session_controller_session_follow_result$schema$value;
		const _deepseek_ai_dsh_api_session_controller_session_follow_result$schema = () => _deepseek_ai_dsh_api_session_controller_session_follow_result$schema$value ??= union([
			object({
				"type": literal("event").readonly(),
				"event": object({
					"type": string().readonly(),
					"seq": number().readonly(),
					"time": number().readonly(),
					"data": union([
						literal(null),
						string(),
						number(),
						literal(false),
						literal(true),
						array(lazy(() => JsonValueRemoteCodec$schema3())),
						record(string(), lazy(() => JsonValueRemoteCodec$schema3()))
					]).readonly(),
					"ignorable": literal(true).readonly().optional(),
					"sourceEventSeqs": union([
						literal(null),
						string(),
						number(),
						literal(false),
						literal(true),
						array(lazy(() => JsonValueRemoteCodec$schema3())),
						record(string(), lazy(() => JsonValueRemoteCodec$schema3()))
					]).readonly().optional(),
					"surfaceOp": union([
						literal(null),
						string(),
						number(),
						literal(false),
						literal(true),
						array(lazy(() => JsonValueRemoteCodec$schema3())),
						record(string(), lazy(() => JsonValueRemoteCodec$schema3()))
					]).readonly().optional()
				}).readonly()
			}),
			object({
				"type": literal("snapshot").readonly(),
				"header": object({
					"version": number().readonly(),
					"id": intersection(string(), unknown()).readonly(),
					"createdAt": number().readonly(),
					"cwd": string().readonly().optional(),
					"parentSession": intersection(string(), unknown()).readonly().optional(),
					"isSeeded": boolean().readonly(),
					"origin": literal("subagent").readonly().optional(),
					"delegationDepth": number().readonly().optional(),
					"agentPreset": string().readonly().optional()
				}).readonly(),
				"cursor": number().readonly(),
				"records": array(object({
					"type": literal("event").readonly(),
					"event": object({
						"type": string().readonly(),
						"seq": number().readonly(),
						"time": number().readonly(),
						"data": union([
							literal(null),
							string(),
							number(),
							literal(false),
							literal(true),
							array(lazy(() => JsonValueRemoteCodec$schema3())),
							record(string(), lazy(() => JsonValueRemoteCodec$schema3()))
						]).readonly(),
						"ignorable": literal(true).readonly().optional(),
						"sourceEventSeqs": union([
							literal(null),
							string(),
							number(),
							literal(false),
							literal(true),
							array(lazy(() => JsonValueRemoteCodec$schema3())),
							record(string(), lazy(() => JsonValueRemoteCodec$schema3()))
						]).readonly().optional(),
						"surfaceOp": union([
							literal(null),
							string(),
							number(),
							literal(false),
							literal(true),
							array(lazy(() => JsonValueRemoteCodec$schema3())),
							record(string(), lazy(() => JsonValueRemoteCodec$schema3()))
						]).readonly().optional()
					}).readonly()
				})).readonly(),
				"hasMore": boolean().readonly(),
				"projections": object({
					"asOfSeq": number().readonly(),
					"values": intersection(object({
						"inbox": object({
							"next-turn": array(union([
								literal(null),
								string(),
								number(),
								literal(false),
								literal(true),
								array(lazy(() => JsonValueRemoteCodec$schema3())),
								record(string(), lazy(() => JsonValueRemoteCodec$schema3()))
							])).readonly(),
							"next-step": array(union([
								literal(null),
								string(),
								number(),
								literal(false),
								literal(true),
								array(lazy(() => JsonValueRemoteCodec$schema3())),
								record(string(), lazy(() => JsonValueRemoteCodec$schema3()))
							])).readonly()
						}).optional(),
						"agentPreset": union([literal(null), string()]).optional(),
						"title": union([literal(null), string()]).optional(),
						"todos": union([literal(null), array(object({
							"content": string(),
							"status": union([
								literal("completed"),
								literal("pending"),
								literal("in_progress")
							])
						}))]).optional(),
						"sessionListMetadata": object({
							"blank": boolean().readonly(),
							"lastPromptAt": union([literal(null), number()]).readonly()
						}).optional(),
						"imageLimits": object({
							"maxImageBytes": number(),
							"maxImagesPerMessage": number(),
							"maxMessageImageBytes": number(),
							"maxImagePixels": number(),
							"maxImageDimension": number(),
							"mediaTypes": array(union([
								literal("image/png"),
								literal("image/jpeg"),
								literal("image/webp"),
								literal("image/gif")
							]))
						}).optional(),
						"modelSelection": object({
							"lastUsed": union([literal(null), object({
								"provider": string().readonly(),
								"model": string().readonly(),
								"reasoningEffort": string().readonly().optional()
							})]).readonly(),
							"next": union([literal(null), object({
								"provider": string().readonly(),
								"model": string().readonly(),
								"reasoningEffort": string().readonly().optional()
							})]).readonly()
						}).optional(),
						"permissions": object({ "currentValue": string() }).optional(),
						"subagentCatalog": array(union([
							intersection(object({
								"id": intersection(string(), unknown()).readonly(),
								"createdAt": number().readonly()
							}), object({
								"mode": literal("one-shot").readonly(),
								"label": string().readonly().optional()
							})),
							intersection(object({
								"id": intersection(string(), unknown()).readonly(),
								"createdAt": number().readonly()
							}), object({
								"mode": literal("continuable").readonly(),
								"label": string().readonly()
							})),
							intersection(object({
								"id": intersection(string(), unknown()).readonly(),
								"createdAt": number().readonly()
							}), object({
								"mode": literal("unknown").readonly(),
								"label": string().readonly().optional()
							}))
						])).optional(),
						"subagentTiming": object({
							"settledMs": number(),
							"active": object({
								"since": number(),
								"through": number()
							}).optional(),
							"lastTurnCompleted": boolean().optional()
						}).optional(),
						"subagent": union([
							literal(null),
							object({
								"mode": literal("one-shot"),
								"label": string().optional(),
								"seq": intersection(number(), unknown())
							}),
							object({
								"mode": literal("continuable"),
								"label": string(),
								"seq": intersection(number(), unknown())
							})
						]).optional(),
						"goal": union([literal(null), object({
							"goal": object({
								"objective": string().readonly(),
								"phase": union([
									literal("active"),
									literal("paused"),
									literal("blocked"),
									literal("complete")
								]).readonly(),
								"blockedReason": object({
									"code": string().readonly(),
									"message": string().readonly()
								}).readonly().optional(),
								"maxGoalRounds": number().readonly(),
								"id": intersection(string(), unknown()).readonly(),
								"revision": number().readonly()
							}).readonly(),
							"roundsStarted": number().readonly(),
							"createdAt": number().readonly(),
							"updatedAt": number().readonly()
						})]).optional(),
						"userQuestions": object({
							"active": array(object({
								"callId": intersection(string(), unknown()).readonly(),
								"questions": array(object({
									"id": string(),
									"question": string(),
									"detail": string().optional(),
									"header": string().optional(),
									"options": array(object({
										"label": string(),
										"description": string().optional()
									})).optional(),
									"multiSelect": boolean().optional(),
									"intent": object({
										"kind": literal("plan-review"),
										"approve": string(),
										"callId": intersection(string(), unknown()).optional()
									}).optional()
								})).readonly(),
								"state": union([literal("open"), literal("continued")]).readonly()
							})).readonly(),
							"settled": array(object({
								"callId": intersection(string(), unknown()).readonly(),
								"answers": array(object({
									"id": string(),
									"selected": array(string()),
									"custom": string().optional()
								})).readonly()
							})).readonly()
						}).optional()
					}), record(string(), union([
						literal(null),
						string(),
						number(),
						literal(false),
						literal(true),
						array(lazy(() => JsonValueRemoteCodec$schema3())),
						record(string(), lazy(() => JsonValueRemoteCodec$schema3()))
					])).readonly()).readonly()
				}).readonly(),
				"assistantStream": object({
					"revision": number().readonly(),
					"activeAttempt": object({
						"attemptId": intersection(string(), unknown()).readonly(),
						"startedAfterSeq": union([intersection(number(), unknown()), literal(-1)]).readonly(),
						"turn": number().readonly(),
						"step": number().readonly(),
						"nextIndex": number().readonly(),
						"stream": array(union([
							literal(null),
							string(),
							number(),
							literal(false),
							literal(true),
							array(lazy(() => JsonValueRemoteCodec$schema3())),
							record(string(), lazy(() => JsonValueRemoteCodec$schema3()))
						])).readonly()
					}).readonly().optional()
				}).readonly().optional()
			}),
			object({
				"type": literal("assistant-stream").readonly(),
				"frame": union([
					object({
						"type": literal("start").readonly(),
						"attemptId": intersection(string(), unknown()).readonly(),
						"revision": number().readonly(),
						"startedAfterSeq": union([intersection(number(), unknown()), literal(-1)]).readonly(),
						"turn": number().readonly(),
						"step": number().readonly()
					}),
					object({
						"type": literal("chunk").readonly(),
						"attemptId": intersection(string(), unknown()).readonly(),
						"revision": number().readonly(),
						"index": number().readonly(),
						"time": number().readonly(),
						"chunk": union([
							literal(null),
							string(),
							number(),
							literal(false),
							literal(true),
							array(lazy(() => JsonValueRemoteCodec$schema3())),
							record(string(), lazy(() => JsonValueRemoteCodec$schema3()))
						]).readonly()
					}),
					object({
						"type": literal("end").readonly(),
						"attemptId": intersection(string(), unknown()).readonly(),
						"revision": number().readonly(),
						"index": number().readonly(),
						"outcome": union([object({
							"kind": literal("committed").readonly(),
							"eventType": union([literal("assistant/message"), literal("assistant/attempt")]).readonly(),
							"seq": number().readonly()
						}), object({ "kind": literal("abandoned").readonly() })]).readonly()
					})
				]).readonly()
			})
		]);
		let _deepseek_ai_dsh_api_session_controller_session_fork_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_session_controller_session_fork_parameter_0$schema = () => _deepseek_ai_dsh_api_session_controller_session_fork_parameter_0$schema$value ??= object({
			"sessionId": intersection(string(), unknown()).readonly(),
			"atSeq": number().readonly().optional()
		});
		let _deepseek_ai_dsh_api_session_controller_session_fork_result$schema$value;
		const _deepseek_ai_dsh_api_session_controller_session_fork_result$schema = () => _deepseek_ai_dsh_api_session_controller_session_fork_result$schema$value ??= object({ "sessionId": intersection(string(), unknown()).readonly() });
		let _deepseek_ai_dsh_api_session_controller_session_initializeDefaultModel_result$schema$value;
		const _deepseek_ai_dsh_api_session_controller_session_initializeDefaultModel_result$schema = () => _deepseek_ai_dsh_api_session_controller_session_initializeDefaultModel_result$schema$value ??= _void();
		let _deepseek_ai_dsh_api_session_controller_session_list_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_session_controller_session_list_parameter_0$schema = () => _deepseek_ai_dsh_api_session_controller_session_list_parameter_0$schema$value ??= object({ "cursor": string().readonly().optional() });
		let _deepseek_ai_dsh_api_session_controller_session_list_result$schema$value;
		const _deepseek_ai_dsh_api_session_controller_session_list_result$schema = () => _deepseek_ai_dsh_api_session_controller_session_list_result$schema$value ??= object({ "items": array(object({
			"agentAvailable": boolean().readonly(),
			"sessionId": intersection(string(), unknown()).readonly(),
			"updatedAt": number().readonly(),
			"running": boolean().readonly(),
			"blank": boolean().readonly(),
			"parentSessionId": intersection(string(), unknown()).readonly().optional(),
			"origin": literal("subagent").readonly().optional(),
			"cwd": string().readonly().optional(),
			"projections": object({
				"kind": union([literal("cached"), literal("sequenced")]).readonly(),
				"asOfSeq": number().readonly(),
				"values": intersection(object({
					"inbox": object({
						"next-turn": array(union([
							literal(null),
							string(),
							number(),
							literal(false),
							literal(true),
							array(lazy(() => JsonValueRemoteCodec$schema())),
							record(string(), lazy(() => JsonValueRemoteCodec$schema()))
						])).readonly(),
						"next-step": array(union([
							literal(null),
							string(),
							number(),
							literal(false),
							literal(true),
							array(lazy(() => JsonValueRemoteCodec$schema())),
							record(string(), lazy(() => JsonValueRemoteCodec$schema()))
						])).readonly()
					}).optional(),
					"agentPreset": union([literal(null), string()]).optional(),
					"title": union([literal(null), string()]).optional(),
					"todos": union([literal(null), array(object({
						"content": string(),
						"status": union([
							literal("completed"),
							literal("pending"),
							literal("in_progress")
						])
					}))]).optional(),
					"sessionListMetadata": object({
						"blank": boolean().readonly(),
						"lastPromptAt": union([literal(null), number()]).readonly()
					}).optional(),
					"imageLimits": object({
						"maxImageBytes": number(),
						"maxImagesPerMessage": number(),
						"maxMessageImageBytes": number(),
						"maxImagePixels": number(),
						"maxImageDimension": number(),
						"mediaTypes": array(union([
							literal("image/png"),
							literal("image/jpeg"),
							literal("image/webp"),
							literal("image/gif")
						]))
					}).optional(),
					"modelSelection": object({
						"lastUsed": union([literal(null), object({
							"provider": string().readonly(),
							"model": string().readonly(),
							"reasoningEffort": string().readonly().optional()
						})]).readonly(),
						"next": union([literal(null), object({
							"provider": string().readonly(),
							"model": string().readonly(),
							"reasoningEffort": string().readonly().optional()
						})]).readonly()
					}).optional(),
					"permissions": object({ "currentValue": string() }).optional(),
					"subagentCatalog": array(union([
						intersection(object({
							"id": intersection(string(), unknown()).readonly(),
							"createdAt": number().readonly()
						}), object({
							"mode": literal("one-shot").readonly(),
							"label": string().readonly().optional()
						})),
						intersection(object({
							"id": intersection(string(), unknown()).readonly(),
							"createdAt": number().readonly()
						}), object({
							"mode": literal("continuable").readonly(),
							"label": string().readonly()
						})),
						intersection(object({
							"id": intersection(string(), unknown()).readonly(),
							"createdAt": number().readonly()
						}), object({
							"mode": literal("unknown").readonly(),
							"label": string().readonly().optional()
						}))
					])).optional(),
					"subagentTiming": object({
						"settledMs": number(),
						"active": object({
							"since": number(),
							"through": number()
						}).optional(),
						"lastTurnCompleted": boolean().optional()
					}).optional(),
					"subagent": union([
						literal(null),
						object({
							"mode": literal("one-shot"),
							"label": string().optional(),
							"seq": intersection(number(), unknown())
						}),
						object({
							"mode": literal("continuable"),
							"label": string(),
							"seq": intersection(number(), unknown())
						})
					]).optional(),
					"goal": union([literal(null), object({
						"goal": object({
							"objective": string().readonly(),
							"phase": union([
								literal("active"),
								literal("paused"),
								literal("blocked"),
								literal("complete")
							]).readonly(),
							"blockedReason": object({
								"code": string().readonly(),
								"message": string().readonly()
							}).readonly().optional(),
							"maxGoalRounds": number().readonly(),
							"id": intersection(string(), unknown()).readonly(),
							"revision": number().readonly()
						}).readonly(),
						"roundsStarted": number().readonly(),
						"createdAt": number().readonly(),
						"updatedAt": number().readonly()
					})]).optional(),
					"userQuestions": object({
						"active": array(object({
							"callId": intersection(string(), unknown()).readonly(),
							"questions": array(object({
								"id": string(),
								"question": string(),
								"detail": string().optional(),
								"header": string().optional(),
								"options": array(object({
									"label": string(),
									"description": string().optional()
								})).optional(),
								"multiSelect": boolean().optional(),
								"intent": object({
									"kind": literal("plan-review"),
									"approve": string(),
									"callId": intersection(string(), unknown()).optional()
								}).optional()
							})).readonly(),
							"state": union([literal("open"), literal("continued")]).readonly()
						})).readonly(),
						"settled": array(object({
							"callId": intersection(string(), unknown()).readonly(),
							"answers": array(object({
								"id": string(),
								"selected": array(string()),
								"custom": string().optional()
							})).readonly()
						})).readonly()
					}).optional()
				}), record(string(), union([
					literal(null),
					string(),
					number(),
					literal(false),
					literal(true),
					array(lazy(() => JsonValueRemoteCodec$schema())),
					record(string(), lazy(() => JsonValueRemoteCodec$schema()))
				])).readonly()).readonly()
			}).readonly().optional()
		})).readonly() });
		let _deepseek_ai_dsh_api_session_controller_session_modelCatalog_result$schema$value;
		const _deepseek_ai_dsh_api_session_controller_session_modelCatalog_result$schema = () => _deepseek_ai_dsh_api_session_controller_session_modelCatalog_result$schema$value ??= object({
			"default": object({
				"provider": string().readonly(),
				"model": string().readonly(),
				"reasoningEffort": string().readonly().optional()
			}).readonly(),
			"routableProviders": array(string()).readonly(),
			"groups": array(object({
				"id": string().readonly(),
				"name": string().readonly(),
				"models": array(object({
					"id": string().readonly(),
					"name": string().readonly(),
					"description": string().readonly().optional(),
					"reasoning": object({
						"efforts": array(object({
							"id": string().readonly(),
							"name": string().readonly(),
							"description": string().readonly().optional()
						})).readonly(),
						"defaultEffort": string().readonly().optional()
					}).readonly().optional()
				})).readonly()
			})).readonly(),
			"failures": array(object({
				"id": string().readonly(),
				"name": string().readonly(),
				"message": string().readonly()
			})).readonly()
		});
		let _deepseek_ai_dsh_api_session_controller_session_openWorkspacePath_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_session_controller_session_openWorkspacePath_parameter_0$schema = () => _deepseek_ai_dsh_api_session_controller_session_openWorkspacePath_parameter_0$schema$value ??= object({
			"action": literal("reveal").readonly().optional(),
			"application": string().readonly().optional(),
			"path": string().readonly()
		});
		let _deepseek_ai_dsh_api_session_controller_session_openWorkspacePath_result$schema$value;
		const _deepseek_ai_dsh_api_session_controller_session_openWorkspacePath_result$schema = () => _deepseek_ai_dsh_api_session_controller_session_openWorkspacePath_result$schema$value ??= object({ "opened": literal(true).readonly() });
		let _deepseek_ai_dsh_api_session_controller_session_page_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_session_controller_session_page_parameter_0$schema = () => _deepseek_ai_dsh_api_session_controller_session_page_parameter_0$schema$value ??= object({
			"address": union([object({
				"kind": literal("session").readonly(),
				"sessionId": intersection(string(), unknown()).readonly()
			}), object({
				"kind": literal("subagent").readonly(),
				"parentSessionId": intersection(string(), unknown()).readonly(),
				"childSessionId": intersection(string(), unknown()).readonly(),
				"mode": union([
					literal("one-shot"),
					literal("continuable"),
					literal("unknown")
				]).readonly()
			})]).readonly(),
			"throughSeq": number().readonly(),
			"beforeSeq": number().readonly().optional(),
			"maxMessages": number().readonly().optional(),
			"turnWindow": object({
				"minMessages": number().readonly(),
				"minTurns": number().readonly()
			}).readonly().optional()
		});
		let _deepseek_ai_dsh_api_session_controller_session_page_result$schema$value;
		const _deepseek_ai_dsh_api_session_controller_session_page_result$schema = () => _deepseek_ai_dsh_api_session_controller_session_page_result$schema$value ??= object({
			"records": array(object({
				"type": literal("event").readonly(),
				"event": object({
					"type": string().readonly(),
					"seq": number().readonly(),
					"time": number().readonly(),
					"data": union([
						literal(null),
						string(),
						number(),
						literal(false),
						literal(true),
						array(lazy(() => JsonValueRemoteCodec$schema2())),
						record(string(), lazy(() => JsonValueRemoteCodec$schema2()))
					]).readonly(),
					"ignorable": literal(true).readonly().optional(),
					"sourceEventSeqs": union([
						literal(null),
						string(),
						number(),
						literal(false),
						literal(true),
						array(lazy(() => JsonValueRemoteCodec$schema2())),
						record(string(), lazy(() => JsonValueRemoteCodec$schema2()))
					]).readonly().optional(),
					"surfaceOp": union([
						literal(null),
						string(),
						number(),
						literal(false),
						literal(true),
						array(lazy(() => JsonValueRemoteCodec$schema2())),
						record(string(), lazy(() => JsonValueRemoteCodec$schema2()))
					]).readonly().optional()
				}).readonly()
			})).readonly(),
			"hasMore": boolean().readonly()
		});
		let _deepseek_ai_dsh_api_session_controller_session_projections_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_session_controller_session_projections_parameter_0$schema = () => _deepseek_ai_dsh_api_session_controller_session_projections_parameter_0$schema$value ??= object({ "sessionId": intersection(string(), unknown()).readonly() });
		let _deepseek_ai_dsh_api_session_controller_session_projections_result$schema$value;
		const _deepseek_ai_dsh_api_session_controller_session_projections_result$schema = () => _deepseek_ai_dsh_api_session_controller_session_projections_result$schema$value ??= union([literal(null), object({
			"asOfSeq": number().readonly(),
			"values": intersection(object({
				"inbox": object({
					"next-turn": array(union([
						literal(null),
						string(),
						number(),
						literal(false),
						literal(true),
						array(lazy(() => JsonValueRemoteCodec$schema4())),
						record(string(), lazy(() => JsonValueRemoteCodec$schema4()))
					])).readonly(),
					"next-step": array(union([
						literal(null),
						string(),
						number(),
						literal(false),
						literal(true),
						array(lazy(() => JsonValueRemoteCodec$schema4())),
						record(string(), lazy(() => JsonValueRemoteCodec$schema4()))
					])).readonly()
				}).optional(),
				"agentPreset": union([literal(null), string()]).optional(),
				"title": union([literal(null), string()]).optional(),
				"todos": union([literal(null), array(object({
					"content": string(),
					"status": union([
						literal("completed"),
						literal("pending"),
						literal("in_progress")
					])
				}))]).optional(),
				"sessionListMetadata": object({
					"blank": boolean().readonly(),
					"lastPromptAt": union([literal(null), number()]).readonly()
				}).optional(),
				"imageLimits": object({
					"maxImageBytes": number(),
					"maxImagesPerMessage": number(),
					"maxMessageImageBytes": number(),
					"maxImagePixels": number(),
					"maxImageDimension": number(),
					"mediaTypes": array(union([
						literal("image/png"),
						literal("image/jpeg"),
						literal("image/webp"),
						literal("image/gif")
					]))
				}).optional(),
				"modelSelection": object({
					"lastUsed": union([literal(null), object({
						"provider": string().readonly(),
						"model": string().readonly(),
						"reasoningEffort": string().readonly().optional()
					})]).readonly(),
					"next": union([literal(null), object({
						"provider": string().readonly(),
						"model": string().readonly(),
						"reasoningEffort": string().readonly().optional()
					})]).readonly()
				}).optional(),
				"permissions": object({ "currentValue": string() }).optional(),
				"subagentCatalog": array(union([
					intersection(object({
						"id": intersection(string(), unknown()).readonly(),
						"createdAt": number().readonly()
					}), object({
						"mode": literal("one-shot").readonly(),
						"label": string().readonly().optional()
					})),
					intersection(object({
						"id": intersection(string(), unknown()).readonly(),
						"createdAt": number().readonly()
					}), object({
						"mode": literal("continuable").readonly(),
						"label": string().readonly()
					})),
					intersection(object({
						"id": intersection(string(), unknown()).readonly(),
						"createdAt": number().readonly()
					}), object({
						"mode": literal("unknown").readonly(),
						"label": string().readonly().optional()
					}))
				])).optional(),
				"subagentTiming": object({
					"settledMs": number(),
					"active": object({
						"since": number(),
						"through": number()
					}).optional(),
					"lastTurnCompleted": boolean().optional()
				}).optional(),
				"subagent": union([
					literal(null),
					object({
						"mode": literal("one-shot"),
						"label": string().optional(),
						"seq": intersection(number(), unknown())
					}),
					object({
						"mode": literal("continuable"),
						"label": string(),
						"seq": intersection(number(), unknown())
					})
				]).optional(),
				"goal": union([literal(null), object({
					"goal": object({
						"objective": string().readonly(),
						"phase": union([
							literal("active"),
							literal("paused"),
							literal("blocked"),
							literal("complete")
						]).readonly(),
						"blockedReason": object({
							"code": string().readonly(),
							"message": string().readonly()
						}).readonly().optional(),
						"maxGoalRounds": number().readonly(),
						"id": intersection(string(), unknown()).readonly(),
						"revision": number().readonly()
					}).readonly(),
					"roundsStarted": number().readonly(),
					"createdAt": number().readonly(),
					"updatedAt": number().readonly()
				})]).optional(),
				"userQuestions": object({
					"active": array(object({
						"callId": intersection(string(), unknown()).readonly(),
						"questions": array(object({
							"id": string(),
							"question": string(),
							"detail": string().optional(),
							"header": string().optional(),
							"options": array(object({
								"label": string(),
								"description": string().optional()
							})).optional(),
							"multiSelect": boolean().optional(),
							"intent": object({
								"kind": literal("plan-review"),
								"approve": string(),
								"callId": intersection(string(), unknown()).optional()
							}).optional()
						})).readonly(),
						"state": union([literal("open"), literal("continued")]).readonly()
					})).readonly(),
					"settled": array(object({
						"callId": intersection(string(), unknown()).readonly(),
						"answers": array(object({
							"id": string(),
							"selected": array(string()),
							"custom": string().optional()
						})).readonly()
					})).readonly()
				}).optional()
			}), record(string(), union([
				literal(null),
				string(),
				number(),
				literal(false),
				literal(true),
				array(lazy(() => JsonValueRemoteCodec$schema4())),
				record(string(), lazy(() => JsonValueRemoteCodec$schema4()))
			])).readonly()).readonly()
		})]);
		let _deepseek_ai_dsh_api_session_controller_session_prompt_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_session_controller_session_prompt_parameter_0$schema = () => _deepseek_ai_dsh_api_session_controller_session_prompt_parameter_0$schema$value ??= object({
			"requestId": intersection(string(), unknown()).readonly(),
			"sessionId": intersection(string(), unknown()).readonly(),
			"mode": union([literal("queue"), literal("steer")]).readonly(),
			"content": array(union([
				object({
					"type": literal("text").readonly(),
					"text": string().readonly()
				}),
				object({
					"type": literal("image").readonly(),
					"mediaType": union([
						literal("image/png"),
						literal("image/jpeg"),
						literal("image/webp"),
						literal("image/gif")
					]).readonly(),
					"data": string().readonly(),
					"name": string().readonly().optional()
				}),
				object({
					"type": literal("file").readonly(),
					"receiptId": intersection(string(), unknown()).readonly()
				})
			])).readonly(),
			"clientTimeZone": string().readonly().optional()
		});
		let _deepseek_ai_dsh_api_session_controller_session_prompt_result$schema$value;
		const _deepseek_ai_dsh_api_session_controller_session_prompt_result$schema = () => _deepseek_ai_dsh_api_session_controller_session_prompt_result$schema$value ??= object({ "accepted": literal(true).readonly() });
		let _deepseek_ai_dsh_api_session_controller_session_rename_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_session_controller_session_rename_parameter_0$schema = () => _deepseek_ai_dsh_api_session_controller_session_rename_parameter_0$schema$value ??= object({
			"sessionId": intersection(string(), unknown()).readonly(),
			"title": string().readonly()
		});
		let _deepseek_ai_dsh_api_session_controller_session_rename_result$schema$value;
		const _deepseek_ai_dsh_api_session_controller_session_rename_result$schema = () => _deepseek_ai_dsh_api_session_controller_session_rename_result$schema$value ??= object({
			"title": string().readonly(),
			"seq": number().readonly()
		});
		let _deepseek_ai_dsh_api_session_controller_session_search_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_session_controller_session_search_parameter_0$schema = () => _deepseek_ai_dsh_api_session_controller_session_search_parameter_0$schema$value ??= object({ "query": string().readonly() });
		let _deepseek_ai_dsh_api_session_controller_session_search_result$schema$value;
		const _deepseek_ai_dsh_api_session_controller_session_search_result$schema = () => _deepseek_ai_dsh_api_session_controller_session_search_result$schema$value ??= object({
			"items": array(object({
				"sessionId": intersection(string(), unknown()).readonly(),
				"snippet": string().readonly()
			})).readonly(),
			"hasMore": boolean().readonly()
		});
		let _deepseek_ai_dsh_api_session_controller_session_selectModel_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_session_controller_session_selectModel_parameter_0$schema = () => _deepseek_ai_dsh_api_session_controller_session_selectModel_parameter_0$schema$value ??= object({
			"sessionId": intersection(string(), unknown()).readonly(),
			"provider": string().readonly(),
			"model": string().readonly(),
			"reasoningEffort": string().readonly().optional()
		});
		let _deepseek_ai_dsh_api_session_controller_session_selectModel_result$schema$value;
		const _deepseek_ai_dsh_api_session_controller_session_selectModel_result$schema = () => _deepseek_ai_dsh_api_session_controller_session_selectModel_result$schema$value ??= object({ "selected": object({
			"provider": string().readonly(),
			"model": string().readonly(),
			"reasoningEffort": string().readonly().optional()
		}).readonly() });
		let _deepseek_ai_dsh_api_session_controller_session_updateQueue_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_session_controller_session_updateQueue_parameter_0$schema = () => _deepseek_ai_dsh_api_session_controller_session_updateQueue_parameter_0$schema$value ??= object({
			"sessionId": intersection(string(), unknown()).readonly(),
			"itemId": intersection(string(), unknown()).readonly(),
			"action": union([
				object({
					"kind": literal("edit").readonly(),
					"content": array(object({
						"type": literal("text"),
						"text": string()
					})).readonly()
				}),
				object({ "kind": literal("remove").readonly() }),
				object({ "kind": literal("steer").readonly() })
			]).readonly()
		});
		let _deepseek_ai_dsh_api_session_controller_session_updateQueue_result$schema$value;
		const _deepseek_ai_dsh_api_session_controller_session_updateQueue_result$schema = () => _deepseek_ai_dsh_api_session_controller_session_updateQueue_result$schema$value ??= object({ "accepted": literal(true).readonly() });
		let _deepseek_ai_dsh_api_session_controller_session_workspacePathApplications_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_session_controller_session_workspacePathApplications_parameter_0$schema = () => _deepseek_ai_dsh_api_session_controller_session_workspacePathApplications_parameter_0$schema$value ??= object({ "path": string().readonly() });
		let _deepseek_ai_dsh_api_session_controller_session_workspacePathApplications_result$schema$value;
		const _deepseek_ai_dsh_api_session_controller_session_workspacePathApplications_result$schema = () => _deepseek_ai_dsh_api_session_controller_session_workspacePathApplications_result$schema$value ??= array(object({
			"id": string().readonly(),
			"name": string().readonly(),
			"default": boolean().readonly(),
			"icon": union([literal(null), string()]).readonly()
		}));
		let _deepseek_ai_dsh_api_session_controller_skills_list_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_session_controller_skills_list_parameter_0$schema = () => _deepseek_ai_dsh_api_session_controller_skills_list_parameter_0$schema$value ??= object({ "sessionId": intersection(string(), unknown()).readonly() });
		let _deepseek_ai_dsh_api_session_controller_skills_list_result$schema$value;
		const _deepseek_ai_dsh_api_session_controller_skills_list_result$schema = () => _deepseek_ai_dsh_api_session_controller_skills_list_result$schema$value ??= object({ "skills": array(object({
			"path": string().readonly().optional(),
			"name": string().readonly(),
			"description": string().readonly(),
			"whenToUse": string().readonly().optional(),
			"modelInvocable": boolean().readonly()
		})).readonly() });
		const TYPERT_REMOTE$4 = {
			package: "@deepseek-ai/dsh-api-session-controller",
			descriptors: [
				{
					id: "@deepseek-ai/dsh-api-session-controller#fileReferences/list",
					service: "sessionFileReferences",
					namespace: "fileReferences",
					method: "list",
					invocation: { kind: "direct" },
					scope: {
						context: "agent",
						wire: "agentId"
					},
					parameters: [{
						name: "agent",
						wire: "agentId",
						source: "lookup",
						lookup: "agent",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
							create: _deepseek_ai_dsh_api_session_controller_fileReferences_list_parameter_0$schema
						}
					}, {
						name: "query",
						wire: "query",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-session-controller#fileReferences/list:query",
							create: _deepseek_ai_dsh_api_session_controller_fileReferences_list_parameter_1$schema
						}
					}],
					cancellation: { parameter: "signal" },
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-session-controller#fileReferences/list:result",
						create: _deepseek_ai_dsh_api_session_controller_fileReferences_list_result$schema
					},
					sourceLocation: {
						"file": "packages/api/session-controller/src/file-references.ts",
						"line": 33,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-session-controller#session/attachment",
					service: "sessionController",
					namespace: "session",
					method: "attachment",
					invocation: { kind: "direct" },
					parameters: [{
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionAttachmentRequest",
							create: _deepseek_ai_dsh_api_session_controller_session_attachment_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionAttachmentValue",
						create: _deepseek_ai_dsh_api_session_controller_session_attachment_result$schema
					},
					sourceLocation: {
						"file": "packages/api/session-controller/src/index.ts",
						"line": 437,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-session-controller#session/cancel",
					service: "sessionController",
					namespace: "session",
					method: "cancel",
					invocation: { kind: "direct" },
					parameters: [{
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionCancelRequest",
							create: _deepseek_ai_dsh_api_session_controller_session_cancel_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionCancelValue",
						create: _deepseek_ai_dsh_api_session_controller_session_cancel_result$schema
					},
					sourceLocation: {
						"file": "packages/api/session-controller/src/index.ts",
						"line": 457,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-session-controller#session/canOpenWorkspacePath",
					service: "sessionController",
					namespace: "session",
					method: "canOpenWorkspacePath",
					invocation: { kind: "direct" },
					parameters: [],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-session-controller#session/canOpenWorkspacePath:result",
						create: _deepseek_ai_dsh_api_session_controller_session_canOpenWorkspacePath_result$schema
					},
					sourceLocation: {
						"file": "packages/api/session-controller/src/index.ts",
						"line": 319,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-session-controller#session/control",
					service: "sessionController",
					namespace: "session",
					method: "control",
					mode: "stream",
					invocation: { kind: "direct" },
					parameters: [],
					cancellation: { parameter: "signal" },
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionControlFrame",
						create: _deepseek_ai_dsh_api_session_controller_session_control_result$schema
					},
					sourceLocation: {
						"file": "packages/api/session-controller/src/index.ts",
						"line": 520,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-session-controller#session/create",
					service: "sessionController",
					namespace: "session",
					method: "create",
					invocation: { kind: "direct" },
					parameters: [{
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionCreateRequest",
							create: _deepseek_ai_dsh_api_session_controller_session_create_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionCreateValue",
						create: _deepseek_ai_dsh_api_session_controller_session_create_result$schema
					},
					sourceLocation: {
						"file": "packages/api/session-controller/src/index.ts",
						"line": 273,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-session-controller#session/follow",
					service: "sessionController",
					namespace: "session",
					method: "follow",
					mode: "stream",
					invocation: { kind: "direct" },
					parameters: [{
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionFollowRequest",
							create: _deepseek_ai_dsh_api_session_controller_session_follow_parameter_0$schema
						}
					}],
					cancellation: { parameter: "signal" },
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionFollowFrame",
						create: _deepseek_ai_dsh_api_session_controller_session_follow_result$schema
					},
					sourceLocation: {
						"file": "packages/api/session-controller/src/index.ts",
						"line": 480,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-session-controller#session/fork",
					service: "sessionController",
					namespace: "session",
					method: "fork",
					invocation: { kind: "direct" },
					parameters: [{
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionForkRequest",
							create: _deepseek_ai_dsh_api_session_controller_session_fork_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionForkValue",
						create: _deepseek_ai_dsh_api_session_controller_session_fork_result$schema
					},
					sourceLocation: {
						"file": "packages/api/session-controller/src/index.ts",
						"line": 415,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-session-controller#session/initializeDefaultModel",
					service: "sessionController",
					namespace: "session",
					method: "initializeDefaultModel",
					invocation: { kind: "direct" },
					parameters: [],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-session-controller#session/initializeDefaultModel:result",
						create: _deepseek_ai_dsh_api_session_controller_session_initializeDefaultModel_result$schema
					},
					sourceLocation: {
						"file": "packages/api/session-controller/src/index.ts",
						"line": 292,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-api-session-controller#session/list",
					service: "sessionController",
					namespace: "session",
					method: "list",
					invocation: { kind: "direct" },
					parameters: [{
						name: "_request",
						wire: "_request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionListRequest",
							create: _deepseek_ai_dsh_api_session_controller_session_list_parameter_0$schema
						}
					}],
					cancellation: { parameter: "signal" },
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionListValue",
						create: _deepseek_ai_dsh_api_session_controller_session_list_result$schema
					},
					sourceLocation: {
						"file": "packages/api/session-controller/src/index.ts",
						"line": 252,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-api-session-controller#session/modelCatalog",
					service: "sessionController",
					namespace: "session",
					method: "modelCatalog",
					invocation: { kind: "direct" },
					parameters: [],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#ModelCatalog",
						create: _deepseek_ai_dsh_api_session_controller_session_modelCatalog_result$schema
					},
					sourceLocation: {
						"file": "packages/api/session-controller/src/index.ts",
						"line": 310,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-session-controller#session/openWorkspacePath",
					service: "sessionController",
					namespace: "session",
					method: "openWorkspacePath",
					invocation: { kind: "direct" },
					parameters: [{
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionOpenWorkspacePathRequest",
							create: _deepseek_ai_dsh_api_session_controller_session_openWorkspacePath_parameter_0$schema
						}
					}],
					cancellation: { parameter: "signal" },
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionOpenWorkspacePathValue",
						create: _deepseek_ai_dsh_api_session_controller_session_openWorkspacePath_result$schema
					},
					sourceLocation: {
						"file": "packages/api/session-controller/src/index.ts",
						"line": 340,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-api-session-controller#session/page",
					service: "sessionController",
					namespace: "session",
					method: "page",
					invocation: { kind: "direct" },
					parameters: [{
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionPageRequest",
							create: _deepseek_ai_dsh_api_session_controller_session_page_parameter_0$schema
						}
					}],
					cancellation: { parameter: "signal" },
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionPage",
						create: _deepseek_ai_dsh_api_session_controller_session_page_result$schema
					},
					sourceLocation: {
						"file": "packages/api/session-controller/src/index.ts",
						"line": 468,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-session-controller#session/projections",
					service: "sessionController",
					namespace: "session",
					method: "projections",
					invocation: { kind: "direct" },
					parameters: [{
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionProjectionsRequest",
							create: _deepseek_ai_dsh_api_session_controller_session_projections_parameter_0$schema
						}
					}],
					cancellation: { parameter: "signal" },
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionProjectionsValue",
						create: _deepseek_ai_dsh_api_session_controller_session_projections_result$schema
					},
					sourceLocation: {
						"file": "packages/api/session-controller/src/index.ts",
						"line": 491,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-api-session-controller#session/prompt",
					service: "sessionController",
					namespace: "session",
					method: "prompt",
					invocation: { kind: "direct" },
					parameters: [{
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionPromptRequest",
							create: _deepseek_ai_dsh_api_session_controller_session_prompt_parameter_0$schema
						}
					}],
					cancellation: { parameter: "signal" },
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionPromptValue",
						create: _deepseek_ai_dsh_api_session_controller_session_prompt_result$schema
					},
					sourceLocation: {
						"file": "packages/api/session-controller/src/index.ts",
						"line": 426,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-session-controller#session/rename",
					service: "sessionController",
					namespace: "session",
					method: "rename",
					invocation: { kind: "direct" },
					parameters: [{
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionRenameRequest",
							create: _deepseek_ai_dsh_api_session_controller_session_rename_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionRenameValue",
						create: _deepseek_ai_dsh_api_session_controller_session_rename_result$schema
					},
					sourceLocation: {
						"file": "packages/api/session-controller/src/index.ts",
						"line": 403,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-session-controller#session/search",
					service: "sessionController",
					namespace: "session",
					method: "search",
					invocation: { kind: "direct" },
					parameters: [{
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionSearchRequest",
							create: _deepseek_ai_dsh_api_session_controller_session_search_parameter_0$schema
						}
					}],
					cancellation: { parameter: "signal" },
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionSearchValue",
						create: _deepseek_ai_dsh_api_session_controller_session_search_result$schema
					},
					sourceLocation: {
						"file": "packages/api/session-controller/src/index.ts",
						"line": 263,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-session-controller#session/selectModel",
					service: "sessionController",
					namespace: "session",
					method: "selectModel",
					invocation: { kind: "direct" },
					parameters: [{
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionSelectModelRequest",
							create: _deepseek_ai_dsh_api_session_controller_session_selectModel_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionSelectModelValue",
						create: _deepseek_ai_dsh_api_session_controller_session_selectModel_result$schema
					},
					sourceLocation: {
						"file": "packages/api/session-controller/src/index.ts",
						"line": 283,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-session-controller#session/updateQueue",
					service: "sessionController",
					namespace: "session",
					method: "updateQueue",
					invocation: { kind: "direct" },
					parameters: [{
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionUpdateQueueRequest",
							create: _deepseek_ai_dsh_api_session_controller_session_updateQueue_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionUpdateQueueValue",
						create: _deepseek_ai_dsh_api_session_controller_session_updateQueue_result$schema
					},
					sourceLocation: {
						"file": "packages/api/session-controller/src/index.ts",
						"line": 447,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-session-controller#session/workspacePathApplications",
					service: "sessionController",
					namespace: "session",
					method: "workspacePathApplications",
					invocation: { kind: "direct" },
					parameters: [{
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-session-controller#session/workspacePathApplications:request",
							create: _deepseek_ai_dsh_api_session_controller_session_workspacePathApplications_parameter_0$schema
						}
					}],
					cancellation: { parameter: "signal" },
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-session-controller#session/workspacePathApplications:result",
						create: _deepseek_ai_dsh_api_session_controller_session_workspacePathApplications_result$schema
					},
					sourceLocation: {
						"file": "packages/api/session-controller/src/index.ts",
						"line": 370,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-api-session-controller#skills/list",
					service: "sessionSkillCatalog",
					namespace: "skills",
					method: "list",
					invocation: { kind: "direct" },
					parameters: [{
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SkillListRequest",
							create: _deepseek_ai_dsh_api_session_controller_skills_list_parameter_0$schema
						}
					}],
					cancellation: { parameter: "signal" },
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SkillListValue",
						create: _deepseek_ai_dsh_api_session_controller_skills_list_result$schema
					},
					sourceLocation: {
						"file": "packages/api/session-controller/src/skill-catalog.ts",
						"line": 35,
						"column": 9
					}
				}
			]
		};
		//#endregion
		//#region ../job-controller/lib/typert.remote-client.js
		let _deepseek_ai_dsh_api_job_controller_job_follow_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_job_controller_job_follow_parameter_0$schema = () => _deepseek_ai_dsh_api_job_controller_job_follow_parameter_0$schema$value ??= object({
			"sessionId": intersection(string(), unknown()).readonly().optional(),
			"jobId": intersection(string(), unknown()).readonly(),
			"from": number().readonly().optional()
		});
		let _deepseek_ai_dsh_api_job_controller_job_follow_result$schema$value;
		const _deepseek_ai_dsh_api_job_controller_job_follow_result$schema = () => _deepseek_ai_dsh_api_job_controller_job_follow_result$schema$value ??= union([
			object({
				"type": literal("opened").readonly(),
				"job": object({
					"id": intersection(string(), unknown()).readonly(),
					"kind": string().readonly(),
					"label": string().readonly(),
					"owner": intersection(string(), unknown()).readonly().optional(),
					"outputLimitBytes": number().readonly().optional(),
					"status": union([
						literal("failed"),
						literal("running"),
						literal("stopping"),
						literal("completed"),
						literal("killed")
					]).readonly(),
					"progress": string().readonly().optional(),
					"detail": string().readonly().optional(),
					"startedAt": number().readonly(),
					"finishedAt": number().readonly().optional(),
					"output": object({
						"total": number().readonly(),
						"earliest": number().readonly(),
						"spillPaths": array(string()).readonly().optional()
					}).readonly()
				}).readonly(),
				"from": number().readonly()
			}),
			object({
				"type": literal("output").readonly(),
				"chunks": array(object({
					"at": number().readonly(),
					"text": string().readonly(),
					"channel": union([
						literal("stdout"),
						literal("stderr"),
						literal("log")
					]).readonly().optional(),
					"gapBefore": literal(true).readonly().optional()
				})).readonly(),
				"next": number().readonly(),
				"lossy": literal(true).readonly().optional()
			}),
			object({
				"type": literal("status").readonly(),
				"job": object({
					"id": intersection(string(), unknown()).readonly(),
					"kind": string().readonly(),
					"label": string().readonly(),
					"owner": intersection(string(), unknown()).readonly().optional(),
					"outputLimitBytes": number().readonly().optional(),
					"status": union([
						literal("failed"),
						literal("running"),
						literal("stopping"),
						literal("completed"),
						literal("killed")
					]).readonly(),
					"progress": string().readonly().optional(),
					"detail": string().readonly().optional(),
					"startedAt": number().readonly(),
					"finishedAt": number().readonly().optional(),
					"output": object({
						"total": number().readonly(),
						"earliest": number().readonly(),
						"spillPaths": array(string()).readonly().optional()
					}).readonly()
				}).readonly()
			})
		]);
		let _deepseek_ai_dsh_api_job_controller_job_kill_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_job_controller_job_kill_parameter_0$schema = () => _deepseek_ai_dsh_api_job_controller_job_kill_parameter_0$schema$value ??= object({
			"sessionId": intersection(string(), unknown()).readonly(),
			"jobId": intersection(string(), unknown()).readonly()
		});
		let _deepseek_ai_dsh_api_job_controller_job_kill_result$schema$value;
		const _deepseek_ai_dsh_api_job_controller_job_kill_result$schema = () => _deepseek_ai_dsh_api_job_controller_job_kill_result$schema$value ??= object({ "outcome": union([literal("requested"), literal("already-finished")]).readonly() });
		let _deepseek_ai_dsh_api_job_controller_job_list_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_job_controller_job_list_parameter_0$schema = () => _deepseek_ai_dsh_api_job_controller_job_list_parameter_0$schema$value ??= object({ "sessionId": intersection(string(), unknown()).readonly() });
		let _deepseek_ai_dsh_api_job_controller_job_list_result$schema$value;
		const _deepseek_ai_dsh_api_job_controller_job_list_result$schema = () => _deepseek_ai_dsh_api_job_controller_job_list_result$schema$value ??= object({
			"type": literal("rows").readonly(),
			"jobs": array(object({
				"id": intersection(string(), unknown()).readonly(),
				"kind": string().readonly(),
				"label": string().readonly(),
				"owner": intersection(string(), unknown()).readonly().optional(),
				"outputLimitBytes": number().readonly().optional(),
				"status": union([
					literal("failed"),
					literal("running"),
					literal("stopping"),
					literal("completed"),
					literal("killed")
				]).readonly(),
				"progress": string().readonly().optional(),
				"detail": string().readonly().optional(),
				"startedAt": number().readonly(),
				"finishedAt": number().readonly().optional(),
				"output": object({
					"total": number().readonly(),
					"earliest": number().readonly(),
					"spillPaths": array(string()).readonly().optional()
				}).readonly()
			})).readonly()
		});
		const TYPERT_REMOTE$3 = {
			package: "@deepseek-ai/dsh-api-job-controller",
			descriptors: [
				{
					id: "@deepseek-ai/dsh-api-job-controller#job/follow",
					service: "jobController",
					namespace: "job",
					method: "follow",
					mode: "stream",
					invocation: { kind: "direct" },
					parameters: [{
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-job-controller/types#JobFollowRequest",
							create: _deepseek_ai_dsh_api_job_controller_job_follow_parameter_0$schema
						}
					}],
					cancellation: { parameter: "signal" },
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-job-controller/types#JobFollowFrame",
						create: _deepseek_ai_dsh_api_job_controller_job_follow_result$schema
					},
					sourceLocation: {
						"file": "packages/api/job-controller/src/index.ts",
						"line": 91,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-job-controller#job/kill",
					service: "jobController",
					namespace: "job",
					method: "kill",
					invocation: { kind: "direct" },
					parameters: [{
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-job-controller/types#JobKillRequest",
							create: _deepseek_ai_dsh_api_job_controller_job_kill_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-job-controller/types#JobKillValue",
						create: _deepseek_ai_dsh_api_job_controller_job_kill_result$schema
					},
					sourceLocation: {
						"file": "packages/api/job-controller/src/index.ts",
						"line": 110,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-job-controller#job/list",
					service: "jobController",
					namespace: "job",
					method: "list",
					mode: "stream",
					invocation: { kind: "direct" },
					parameters: [{
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-job-controller/types#JobListRequest",
							create: _deepseek_ai_dsh_api_job_controller_job_list_parameter_0$schema
						}
					}],
					cancellation: { parameter: "signal" },
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-job-controller/types#JobListFrame",
						create: _deepseek_ai_dsh_api_job_controller_job_list_result$schema
					},
					sourceLocation: {
						"file": "packages/api/job-controller/src/index.ts",
						"line": 76,
						"column": 3
					}
				}
			]
		};
		//#endregion
		//#region ../workspace-controller/lib/typert.remote-client.js
		let _deepseek_ai_dsh_api_workspace_controller_directoryPicker_createDirectory_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_workspace_controller_directoryPicker_createDirectory_parameter_0$schema = () => _deepseek_ai_dsh_api_workspace_controller_directoryPicker_createDirectory_parameter_0$schema$value ??= string();
		let _deepseek_ai_dsh_api_workspace_controller_directoryPicker_createDirectory_parameter_1$schema$value;
		const _deepseek_ai_dsh_api_workspace_controller_directoryPicker_createDirectory_parameter_1$schema = () => _deepseek_ai_dsh_api_workspace_controller_directoryPicker_createDirectory_parameter_1$schema$value ??= string();
		let _deepseek_ai_dsh_api_workspace_controller_directoryPicker_createDirectory_result$schema$value;
		const _deepseek_ai_dsh_api_workspace_controller_directoryPicker_createDirectory_result$schema = () => _deepseek_ai_dsh_api_workspace_controller_directoryPicker_createDirectory_result$schema$value ??= string();
		let _deepseek_ai_dsh_api_workspace_controller_directoryPicker_list_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_workspace_controller_directoryPicker_list_parameter_0$schema = () => _deepseek_ai_dsh_api_workspace_controller_directoryPicker_list_parameter_0$schema$value ??= union([_undefined(), string()]);
		let _deepseek_ai_dsh_api_workspace_controller_directoryPicker_list_result$schema$value;
		const _deepseek_ai_dsh_api_workspace_controller_directoryPicker_list_result$schema = () => _deepseek_ai_dsh_api_workspace_controller_directoryPicker_list_result$schema$value ??= object({
			"path": string(),
			"home": string(),
			"crumbs": array(object({
				"name": string(),
				"path": string(),
				"hidden": boolean()
			})),
			"entries": array(object({
				"name": string(),
				"path": string(),
				"hidden": boolean()
			})),
			"truncated": boolean()
		});
		let _deepseek_ai_dsh_api_workspace_controller_directoryPicker_pick_result$schema$value;
		const _deepseek_ai_dsh_api_workspace_controller_directoryPicker_pick_result$schema = () => _deepseek_ai_dsh_api_workspace_controller_directoryPicker_pick_result$schema$value ??= union([literal(null), string()]);
		let _deepseek_ai_dsh_api_workspace_controller_workspace_archiveSession_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_workspace_controller_workspace_archiveSession_parameter_0$schema = () => _deepseek_ai_dsh_api_workspace_controller_workspace_archiveSession_parameter_0$schema$value ??= object({
			"sessionId": intersection(string(), unknown()).readonly(),
			"stopActivity": boolean().readonly().optional()
		});
		let _deepseek_ai_dsh_api_workspace_controller_workspace_archiveSession_result$schema$value;
		const _deepseek_ai_dsh_api_workspace_controller_workspace_archiveSession_result$schema = () => _deepseek_ai_dsh_api_workspace_controller_workspace_archiveSession_result$schema$value ??= object({ "archivedSessionIds": array(intersection(string(), unknown())).readonly() });
		let _deepseek_ai_dsh_api_workspace_controller_workspace_create_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_workspace_controller_workspace_create_parameter_0$schema = () => _deepseek_ai_dsh_api_workspace_controller_workspace_create_parameter_0$schema$value ??= object({ "path": string().readonly() });
		let _deepseek_ai_dsh_api_workspace_controller_workspace_create_result$schema$value;
		const _deepseek_ai_dsh_api_workspace_controller_workspace_create_result$schema = () => _deepseek_ai_dsh_api_workspace_controller_workspace_create_result$schema$value ??= object({
			"workspace": object({
				"workspaceId": intersection(string(), unknown()).readonly(),
				"path": string().readonly(),
				"title": string().readonly(),
				"sessionIds": array(intersection(string(), unknown())).readonly(),
				"createdAt": string().readonly(),
				"updatedAt": string().readonly()
			}).readonly(),
			"created": boolean().readonly()
		});
		let _deepseek_ai_dsh_api_workspace_controller_workspace_delete_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_workspace_controller_workspace_delete_parameter_0$schema = () => _deepseek_ai_dsh_api_workspace_controller_workspace_delete_parameter_0$schema$value ??= object({ "workspaceId": intersection(string(), unknown()).readonly() });
		let _deepseek_ai_dsh_api_workspace_controller_workspace_delete_result$schema$value;
		const _deepseek_ai_dsh_api_workspace_controller_workspace_delete_result$schema = () => _deepseek_ai_dsh_api_workspace_controller_workspace_delete_result$schema$value ??= object({ "deleted": literal(true).readonly() });
		let _deepseek_ai_dsh_api_workspace_controller_workspace_follow_result$schema$value;
		const _deepseek_ai_dsh_api_workspace_controller_workspace_follow_result$schema = () => _deepseek_ai_dsh_api_workspace_controller_workspace_follow_result$schema$value ??= union([
			object({
				"type": literal("baseline").readonly(),
				"value": object({
					"items": array(object({
						"workspaceId": intersection(string(), unknown()).readonly(),
						"path": string().readonly(),
						"title": string().readonly(),
						"sessionIds": array(intersection(string(), unknown())).readonly(),
						"createdAt": string().readonly(),
						"updatedAt": string().readonly()
					})).readonly(),
					"archivedSessionIds": array(intersection(string(), unknown())).readonly(),
					"pinnedSessionIds": array(intersection(string(), unknown())).readonly()
				}).readonly()
			}),
			object({
				"type": literal("upsert").readonly(),
				"workspace": object({
					"workspaceId": intersection(string(), unknown()).readonly(),
					"path": string().readonly(),
					"title": string().readonly(),
					"sessionIds": array(intersection(string(), unknown())).readonly(),
					"createdAt": string().readonly(),
					"updatedAt": string().readonly()
				}).readonly()
			}),
			object({
				"type": literal("remove").readonly(),
				"workspaceId": intersection(string(), unknown()).readonly()
			}),
			object({
				"type": literal("order").readonly(),
				"workspaceIds": array(intersection(string(), unknown())).readonly()
			}),
			object({
				"type": literal("archived").readonly(),
				"archivedSessionIds": array(intersection(string(), unknown())).readonly()
			}),
			object({
				"type": literal("pinned").readonly(),
				"pinnedSessionIds": array(intersection(string(), unknown())).readonly()
			})
		]);
		let _deepseek_ai_dsh_api_workspace_controller_workspace_initializeDefault_result$schema$value;
		const _deepseek_ai_dsh_api_workspace_controller_workspace_initializeDefault_result$schema = () => _deepseek_ai_dsh_api_workspace_controller_workspace_initializeDefault_result$schema$value ??= union([_undefined(), object({ "workspace": object({
			"workspaceId": intersection(string(), unknown()).readonly(),
			"path": string().readonly(),
			"title": string().readonly(),
			"sessionIds": array(intersection(string(), unknown())).readonly(),
			"createdAt": string().readonly(),
			"updatedAt": string().readonly()
		}).readonly() })]);
		let _deepseek_ai_dsh_api_workspace_controller_workspace_insertBefore_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_workspace_controller_workspace_insertBefore_parameter_0$schema = () => _deepseek_ai_dsh_api_workspace_controller_workspace_insertBefore_parameter_0$schema$value ??= object({
			"workspaceId": intersection(string(), unknown()).readonly(),
			"beforeWorkspaceId": intersection(string(), unknown()).readonly().optional()
		});
		let _deepseek_ai_dsh_api_workspace_controller_workspace_insertBefore_result$schema$value;
		const _deepseek_ai_dsh_api_workspace_controller_workspace_insertBefore_result$schema = () => _deepseek_ai_dsh_api_workspace_controller_workspace_insertBefore_result$schema$value ??= object({ "workspaceIds": array(intersection(string(), unknown())).readonly() });
		let _deepseek_ai_dsh_api_workspace_controller_workspace_insertSessionBefore_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_workspace_controller_workspace_insertSessionBefore_parameter_0$schema = () => _deepseek_ai_dsh_api_workspace_controller_workspace_insertSessionBefore_parameter_0$schema$value ??= object({
			"workspaceId": intersection(string(), unknown()).readonly(),
			"sessionId": intersection(string(), unknown()).readonly(),
			"beforeSessionId": intersection(string(), unknown()).readonly().optional()
		});
		let _deepseek_ai_dsh_api_workspace_controller_workspace_insertSessionBefore_result$schema$value;
		const _deepseek_ai_dsh_api_workspace_controller_workspace_insertSessionBefore_result$schema = () => _deepseek_ai_dsh_api_workspace_controller_workspace_insertSessionBefore_result$schema$value ??= object({ "workspace": object({
			"workspaceId": intersection(string(), unknown()).readonly(),
			"path": string().readonly(),
			"title": string().readonly(),
			"sessionIds": array(intersection(string(), unknown())).readonly(),
			"createdAt": string().readonly(),
			"updatedAt": string().readonly()
		}).readonly() });
		let _deepseek_ai_dsh_api_workspace_controller_workspace_pinSession_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_workspace_controller_workspace_pinSession_parameter_0$schema = () => _deepseek_ai_dsh_api_workspace_controller_workspace_pinSession_parameter_0$schema$value ??= object({ "sessionId": intersection(string(), unknown()).readonly() });
		let _deepseek_ai_dsh_api_workspace_controller_workspace_pinSession_result$schema$value;
		const _deepseek_ai_dsh_api_workspace_controller_workspace_pinSession_result$schema = () => _deepseek_ai_dsh_api_workspace_controller_workspace_pinSession_result$schema$value ??= object({ "pinnedSessionIds": array(intersection(string(), unknown())).readonly() });
		let _deepseek_ai_dsh_api_workspace_controller_workspace_rename_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_workspace_controller_workspace_rename_parameter_0$schema = () => _deepseek_ai_dsh_api_workspace_controller_workspace_rename_parameter_0$schema$value ??= object({
			"workspaceId": intersection(string(), unknown()).readonly(),
			"title": string().readonly()
		});
		let _deepseek_ai_dsh_api_workspace_controller_workspace_rename_result$schema$value;
		const _deepseek_ai_dsh_api_workspace_controller_workspace_rename_result$schema = () => _deepseek_ai_dsh_api_workspace_controller_workspace_rename_result$schema$value ??= object({ "workspace": object({
			"workspaceId": intersection(string(), unknown()).readonly(),
			"path": string().readonly(),
			"title": string().readonly(),
			"sessionIds": array(intersection(string(), unknown())).readonly(),
			"createdAt": string().readonly(),
			"updatedAt": string().readonly()
		}).readonly() });
		let _deepseek_ai_dsh_api_workspace_controller_workspace_unarchiveSession_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_workspace_controller_workspace_unarchiveSession_parameter_0$schema = () => _deepseek_ai_dsh_api_workspace_controller_workspace_unarchiveSession_parameter_0$schema$value ??= object({ "sessionId": intersection(string(), unknown()).readonly() });
		let _deepseek_ai_dsh_api_workspace_controller_workspace_unarchiveSession_result$schema$value;
		const _deepseek_ai_dsh_api_workspace_controller_workspace_unarchiveSession_result$schema = () => _deepseek_ai_dsh_api_workspace_controller_workspace_unarchiveSession_result$schema$value ??= object({ "archivedSessionIds": array(intersection(string(), unknown())).readonly() });
		let _deepseek_ai_dsh_api_workspace_controller_workspace_unpinSession_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_workspace_controller_workspace_unpinSession_parameter_0$schema = () => _deepseek_ai_dsh_api_workspace_controller_workspace_unpinSession_parameter_0$schema$value ??= object({ "sessionId": intersection(string(), unknown()).readonly() });
		let _deepseek_ai_dsh_api_workspace_controller_workspace_unpinSession_result$schema$value;
		const _deepseek_ai_dsh_api_workspace_controller_workspace_unpinSession_result$schema = () => _deepseek_ai_dsh_api_workspace_controller_workspace_unpinSession_result$schema$value ??= object({ "pinnedSessionIds": array(intersection(string(), unknown())).readonly() });
		const TYPERT_REMOTE$2 = {
			package: "@deepseek-ai/dsh-api-workspace-controller",
			descriptors: [
				{
					id: "@deepseek-ai/dsh-api-workspace-controller#directoryPicker/createDirectory",
					service: "directoryPickerController",
					namespace: "directoryPicker",
					method: "createDirectory",
					invocation: { kind: "direct" },
					parameters: [{
						name: "path",
						wire: "path",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-workspace-controller#directoryPicker/createDirectory:path",
							create: _deepseek_ai_dsh_api_workspace_controller_directoryPicker_createDirectory_parameter_0$schema
						}
					}, {
						name: "name",
						wire: "name",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-workspace-controller#directoryPicker/createDirectory:name",
							create: _deepseek_ai_dsh_api_workspace_controller_directoryPicker_createDirectory_parameter_1$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-workspace-controller#directoryPicker/createDirectory:result",
						create: _deepseek_ai_dsh_api_workspace_controller_directoryPicker_createDirectory_result$schema
					},
					sourceLocation: {
						"file": "packages/api/workspace-controller/src/directory-picker.ts",
						"line": 88,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-api-workspace-controller#directoryPicker/list",
					service: "directoryPickerController",
					namespace: "directoryPicker",
					method: "list",
					invocation: { kind: "direct" },
					parameters: [{
						name: "path",
						wire: "path",
						source: "json",
						acceptsUndefined: true,
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-workspace-controller#directoryPicker/list:path",
							create: _deepseek_ai_dsh_api_workspace_controller_directoryPicker_list_parameter_0$schema
						}
					}],
					cancellation: { parameter: "signal" },
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-host-directory-picker/types#DirectoryListing",
						create: _deepseek_ai_dsh_api_workspace_controller_directoryPicker_list_result$schema
					},
					sourceLocation: {
						"file": "packages/api/workspace-controller/src/directory-picker.ts",
						"line": 72,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-api-workspace-controller#directoryPicker/pick",
					service: "directoryPickerController",
					namespace: "directoryPicker",
					method: "pick",
					invocation: { kind: "direct" },
					parameters: [],
					cancellation: { parameter: "signal" },
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-workspace-controller#directoryPicker/pick:result",
						create: _deepseek_ai_dsh_api_workspace_controller_directoryPicker_pick_result$schema
					},
					sourceLocation: {
						"file": "packages/api/workspace-controller/src/directory-picker.ts",
						"line": 55,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-api-workspace-controller#workspace/archiveSession",
					service: "workspaceController",
					namespace: "workspace",
					method: "archiveSession",
					invocation: { kind: "direct" },
					parameters: [{
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-workspace-controller/types#WorkspaceArchiveSessionRequest",
							create: _deepseek_ai_dsh_api_workspace_controller_workspace_archiveSession_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-workspace-controller/types#WorkspaceArchiveValue",
						create: _deepseek_ai_dsh_api_workspace_controller_workspace_archiveSession_result$schema
					},
					sourceLocation: {
						"file": "packages/api/workspace-controller/src/index.ts",
						"line": 155,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-workspace-controller#workspace/create",
					service: "workspaceController",
					namespace: "workspace",
					method: "create",
					invocation: { kind: "direct" },
					parameters: [{
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-workspace-controller/types#WorkspaceCreateRequest",
							create: _deepseek_ai_dsh_api_workspace_controller_workspace_create_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-workspace-controller/types#WorkspaceCreateValue",
						create: _deepseek_ai_dsh_api_workspace_controller_workspace_create_result$schema
					},
					sourceLocation: {
						"file": "packages/api/workspace-controller/src/index.ts",
						"line": 86,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-workspace-controller#workspace/delete",
					service: "workspaceController",
					namespace: "workspace",
					method: "delete",
					invocation: { kind: "direct" },
					parameters: [{
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-workspace-controller/types#WorkspaceDeleteRequest",
							create: _deepseek_ai_dsh_api_workspace_controller_workspace_delete_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-workspace-controller/types#WorkspaceDeleteValue",
						create: _deepseek_ai_dsh_api_workspace_controller_workspace_delete_result$schema
					},
					sourceLocation: {
						"file": "packages/api/workspace-controller/src/index.ts",
						"line": 125,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-workspace-controller#workspace/follow",
					service: "workspaceController",
					namespace: "workspace",
					method: "follow",
					mode: "stream",
					invocation: { kind: "direct" },
					parameters: [],
					cancellation: { parameter: "signal" },
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-workspace-controller/types#WorkspaceFollowFrame",
						create: _deepseek_ai_dsh_api_workspace_controller_workspace_follow_result$schema
					},
					sourceLocation: {
						"file": "packages/api/workspace-controller/src/index.ts",
						"line": 195,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-workspace-controller#workspace/initializeDefault",
					service: "workspaceController",
					namespace: "workspace",
					method: "initializeDefault",
					invocation: { kind: "direct" },
					parameters: [],
					cancellation: { parameter: "signal" },
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-workspace-controller#workspace/initializeDefault:result",
						create: _deepseek_ai_dsh_api_workspace_controller_workspace_initializeDefault_result$schema
					},
					sourceLocation: {
						"file": "packages/api/workspace-controller/src/index.ts",
						"line": 99,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-api-workspace-controller#workspace/insertBefore",
					service: "workspaceController",
					namespace: "workspace",
					method: "insertBefore",
					invocation: { kind: "direct" },
					parameters: [{
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-workspace-controller/types#WorkspaceInsertBeforeRequest",
							create: _deepseek_ai_dsh_api_workspace_controller_workspace_insertBefore_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-workspace-controller/types#WorkspaceOrderValue",
						create: _deepseek_ai_dsh_api_workspace_controller_workspace_insertBefore_result$schema
					},
					sourceLocation: {
						"file": "packages/api/workspace-controller/src/index.ts",
						"line": 135,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-workspace-controller#workspace/insertSessionBefore",
					service: "workspaceController",
					namespace: "workspace",
					method: "insertSessionBefore",
					invocation: { kind: "direct" },
					parameters: [{
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-workspace-controller/types#WorkspaceInsertSessionBeforeRequest",
							create: _deepseek_ai_dsh_api_workspace_controller_workspace_insertSessionBefore_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-workspace-controller/types#WorkspaceValue",
						create: _deepseek_ai_dsh_api_workspace_controller_workspace_insertSessionBefore_result$schema
					},
					sourceLocation: {
						"file": "packages/api/workspace-controller/src/index.ts",
						"line": 145,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-workspace-controller#workspace/pinSession",
					service: "workspaceController",
					namespace: "workspace",
					method: "pinSession",
					invocation: { kind: "direct" },
					parameters: [{
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-workspace-controller/types#WorkspacePinSessionRequest",
							create: _deepseek_ai_dsh_api_workspace_controller_workspace_pinSession_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-workspace-controller/types#WorkspacePinValue",
						create: _deepseek_ai_dsh_api_workspace_controller_workspace_pinSession_result$schema
					},
					sourceLocation: {
						"file": "packages/api/workspace-controller/src/index.ts",
						"line": 175,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-workspace-controller#workspace/rename",
					service: "workspaceController",
					namespace: "workspace",
					method: "rename",
					invocation: { kind: "direct" },
					parameters: [{
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-workspace-controller/types#WorkspaceRenameRequest",
							create: _deepseek_ai_dsh_api_workspace_controller_workspace_rename_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-workspace-controller/types#WorkspaceValue",
						create: _deepseek_ai_dsh_api_workspace_controller_workspace_rename_result$schema
					},
					sourceLocation: {
						"file": "packages/api/workspace-controller/src/index.ts",
						"line": 115,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-workspace-controller#workspace/unarchiveSession",
					service: "workspaceController",
					namespace: "workspace",
					method: "unarchiveSession",
					invocation: { kind: "direct" },
					parameters: [{
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-workspace-controller/types#WorkspaceUnarchiveSessionRequest",
							create: _deepseek_ai_dsh_api_workspace_controller_workspace_unarchiveSession_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-workspace-controller/types#WorkspaceArchiveValue",
						create: _deepseek_ai_dsh_api_workspace_controller_workspace_unarchiveSession_result$schema
					},
					sourceLocation: {
						"file": "packages/api/workspace-controller/src/index.ts",
						"line": 165,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-workspace-controller#workspace/unpinSession",
					service: "workspaceController",
					namespace: "workspace",
					method: "unpinSession",
					invocation: { kind: "direct" },
					parameters: [{
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-workspace-controller/types#WorkspaceUnpinSessionRequest",
							create: _deepseek_ai_dsh_api_workspace_controller_workspace_unpinSession_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-workspace-controller/types#WorkspacePinValue",
						create: _deepseek_ai_dsh_api_workspace_controller_workspace_unpinSession_result$schema
					},
					sourceLocation: {
						"file": "packages/api/workspace-controller/src/index.ts",
						"line": 185,
						"column": 3
					}
				}
			]
		};
		//#endregion
		//#region ../terminal-controller/lib/typert.remote-client.js
		let _deepseek_ai_dsh_api_terminal_controller_terminal_close_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_terminal_controller_terminal_close_parameter_0$schema = () => _deepseek_ai_dsh_api_terminal_controller_terminal_close_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_api_terminal_controller_terminal_close_parameter_1$schema$value;
		const _deepseek_ai_dsh_api_terminal_controller_terminal_close_parameter_1$schema = () => _deepseek_ai_dsh_api_terminal_controller_terminal_close_parameter_1$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_api_terminal_controller_terminal_close_result$schema$value;
		const _deepseek_ai_dsh_api_terminal_controller_terminal_close_result$schema = () => _deepseek_ai_dsh_api_terminal_controller_terminal_close_result$schema$value ??= _void();
		let _deepseek_ai_dsh_api_terminal_controller_terminal_create_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_terminal_controller_terminal_create_parameter_0$schema = () => _deepseek_ai_dsh_api_terminal_controller_terminal_create_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_api_terminal_controller_terminal_create_parameter_1$schema$value;
		const _deepseek_ai_dsh_api_terminal_controller_terminal_create_parameter_1$schema = () => _deepseek_ai_dsh_api_terminal_controller_terminal_create_parameter_1$schema$value ??= object({
			"shellPath": string().readonly().optional(),
			"id": intersection(string(), unknown()).readonly(),
			"cols": number().readonly(),
			"rows": number().readonly()
		});
		let _deepseek_ai_dsh_api_terminal_controller_terminal_create_result$schema$value;
		const _deepseek_ai_dsh_api_terminal_controller_terminal_create_result$schema = () => _deepseek_ai_dsh_api_terminal_controller_terminal_create_result$schema$value ??= object({
			"id": intersection(string(), unknown()).readonly(),
			"title": string().readonly(),
			"shell": object({
				"path": string().readonly(),
				"args": array(string()).readonly(),
				"name": string().readonly()
			}).readonly(),
			"cwd": string().readonly(),
			"cols": number().readonly(),
			"rows": number().readonly(),
			"state": union([
				literal("failed"),
				literal("running"),
				literal("exited")
			]).readonly(),
			"exitCode": union([literal(null), number()]).readonly(),
			"error": string().readonly().optional(),
			"controllerId": intersection(string(), unknown()).readonly().optional()
		});
		let _deepseek_ai_dsh_api_terminal_controller_terminal_environment_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_terminal_controller_terminal_environment_parameter_0$schema = () => _deepseek_ai_dsh_api_terminal_controller_terminal_environment_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_api_terminal_controller_terminal_environment_result$schema$value;
		const _deepseek_ai_dsh_api_terminal_controller_terminal_environment_result$schema = () => _deepseek_ai_dsh_api_terminal_controller_terminal_environment_result$schema$value ??= object({
			"cwd": string().readonly(),
			"maxInputBytes": number().readonly(),
			"maxCols": number().readonly(),
			"maxRows": number().readonly(),
			"scrollback": number().readonly()
		});
		let _deepseek_ai_dsh_api_terminal_controller_terminal_follow_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_terminal_controller_terminal_follow_parameter_0$schema = () => _deepseek_ai_dsh_api_terminal_controller_terminal_follow_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_api_terminal_controller_terminal_follow_parameter_1$schema$value;
		const _deepseek_ai_dsh_api_terminal_controller_terminal_follow_parameter_1$schema = () => _deepseek_ai_dsh_api_terminal_controller_terminal_follow_parameter_1$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_api_terminal_controller_terminal_follow_parameter_2$schema$value;
		const _deepseek_ai_dsh_api_terminal_controller_terminal_follow_parameter_2$schema = () => _deepseek_ai_dsh_api_terminal_controller_terminal_follow_parameter_2$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_api_terminal_controller_terminal_follow_result$schema$value;
		const _deepseek_ai_dsh_api_terminal_controller_terminal_follow_result$schema = () => _deepseek_ai_dsh_api_terminal_controller_terminal_follow_result$schema$value ??= union([
			object({
				"type": literal("snapshot").readonly(),
				"sequence": number().readonly(),
				"screen": string().readonly(),
				"info": object({
					"id": intersection(string(), unknown()).readonly(),
					"title": string().readonly(),
					"shell": object({
						"path": string().readonly(),
						"args": array(string()).readonly(),
						"name": string().readonly()
					}).readonly(),
					"cwd": string().readonly(),
					"cols": number().readonly(),
					"rows": number().readonly(),
					"state": union([
						literal("failed"),
						literal("running"),
						literal("exited")
					]).readonly(),
					"exitCode": union([literal(null), number()]).readonly(),
					"error": string().readonly().optional(),
					"controllerId": intersection(string(), unknown()).readonly().optional()
				}).readonly()
			}),
			object({
				"type": literal("output").readonly(),
				"sequence": number().readonly(),
				"data": string().readonly()
			}),
			object({
				"type": literal("state").readonly(),
				"info": object({
					"id": intersection(string(), unknown()).readonly(),
					"title": string().readonly(),
					"shell": object({
						"path": string().readonly(),
						"args": array(string()).readonly(),
						"name": string().readonly()
					}).readonly(),
					"cwd": string().readonly(),
					"cols": number().readonly(),
					"rows": number().readonly(),
					"state": union([
						literal("failed"),
						literal("running"),
						literal("exited")
					]).readonly(),
					"exitCode": union([literal(null), number()]).readonly(),
					"error": string().readonly().optional(),
					"controllerId": intersection(string(), unknown()).readonly().optional()
				}).readonly()
			})
		]);
		let _deepseek_ai_dsh_api_terminal_controller_terminal_list_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_terminal_controller_terminal_list_parameter_0$schema = () => _deepseek_ai_dsh_api_terminal_controller_terminal_list_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_api_terminal_controller_terminal_list_result$schema$value;
		const _deepseek_ai_dsh_api_terminal_controller_terminal_list_result$schema = () => _deepseek_ai_dsh_api_terminal_controller_terminal_list_result$schema$value ??= array(object({
			"id": intersection(string(), unknown()).readonly(),
			"title": string().readonly(),
			"shell": object({
				"path": string().readonly(),
				"args": array(string()).readonly(),
				"name": string().readonly()
			}).readonly(),
			"cwd": string().readonly(),
			"cols": number().readonly(),
			"rows": number().readonly(),
			"state": union([
				literal("failed"),
				literal("running"),
				literal("exited")
			]).readonly(),
			"exitCode": union([literal(null), number()]).readonly(),
			"error": string().readonly().optional(),
			"controllerId": intersection(string(), unknown()).readonly().optional()
		}));
		let _deepseek_ai_dsh_api_terminal_controller_terminal_rename_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_terminal_controller_terminal_rename_parameter_0$schema = () => _deepseek_ai_dsh_api_terminal_controller_terminal_rename_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_api_terminal_controller_terminal_rename_parameter_1$schema$value;
		const _deepseek_ai_dsh_api_terminal_controller_terminal_rename_parameter_1$schema = () => _deepseek_ai_dsh_api_terminal_controller_terminal_rename_parameter_1$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_api_terminal_controller_terminal_rename_parameter_2$schema$value;
		const _deepseek_ai_dsh_api_terminal_controller_terminal_rename_parameter_2$schema = () => _deepseek_ai_dsh_api_terminal_controller_terminal_rename_parameter_2$schema$value ??= string();
		let _deepseek_ai_dsh_api_terminal_controller_terminal_rename_result$schema$value;
		const _deepseek_ai_dsh_api_terminal_controller_terminal_rename_result$schema = () => _deepseek_ai_dsh_api_terminal_controller_terminal_rename_result$schema$value ??= _void();
		let _deepseek_ai_dsh_api_terminal_controller_terminal_resize_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_terminal_controller_terminal_resize_parameter_0$schema = () => _deepseek_ai_dsh_api_terminal_controller_terminal_resize_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_api_terminal_controller_terminal_resize_parameter_1$schema$value;
		const _deepseek_ai_dsh_api_terminal_controller_terminal_resize_parameter_1$schema = () => _deepseek_ai_dsh_api_terminal_controller_terminal_resize_parameter_1$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_api_terminal_controller_terminal_resize_parameter_2$schema$value;
		const _deepseek_ai_dsh_api_terminal_controller_terminal_resize_parameter_2$schema = () => _deepseek_ai_dsh_api_terminal_controller_terminal_resize_parameter_2$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_api_terminal_controller_terminal_resize_parameter_3$schema$value;
		const _deepseek_ai_dsh_api_terminal_controller_terminal_resize_parameter_3$schema = () => _deepseek_ai_dsh_api_terminal_controller_terminal_resize_parameter_3$schema$value ??= number();
		let _deepseek_ai_dsh_api_terminal_controller_terminal_resize_parameter_4$schema$value;
		const _deepseek_ai_dsh_api_terminal_controller_terminal_resize_parameter_4$schema = () => _deepseek_ai_dsh_api_terminal_controller_terminal_resize_parameter_4$schema$value ??= number();
		let _deepseek_ai_dsh_api_terminal_controller_terminal_resize_result$schema$value;
		const _deepseek_ai_dsh_api_terminal_controller_terminal_resize_result$schema = () => _deepseek_ai_dsh_api_terminal_controller_terminal_resize_result$schema$value ??= _void();
		let _deepseek_ai_dsh_api_terminal_controller_terminal_retain_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_terminal_controller_terminal_retain_parameter_0$schema = () => _deepseek_ai_dsh_api_terminal_controller_terminal_retain_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_api_terminal_controller_terminal_retain_parameter_1$schema$value;
		const _deepseek_ai_dsh_api_terminal_controller_terminal_retain_parameter_1$schema = () => _deepseek_ai_dsh_api_terminal_controller_terminal_retain_parameter_1$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_api_terminal_controller_terminal_retain_result$schema$value;
		const _deepseek_ai_dsh_api_terminal_controller_terminal_retain_result$schema = () => _deepseek_ai_dsh_api_terminal_controller_terminal_retain_result$schema$value ??= object({ "type": literal("retained").readonly() });
		let _deepseek_ai_dsh_api_terminal_controller_terminal_shells_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_terminal_controller_terminal_shells_parameter_0$schema = () => _deepseek_ai_dsh_api_terminal_controller_terminal_shells_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_api_terminal_controller_terminal_shells_result$schema$value;
		const _deepseek_ai_dsh_api_terminal_controller_terminal_shells_result$schema = () => _deepseek_ai_dsh_api_terminal_controller_terminal_shells_result$schema$value ??= array(object({
			"path": string().readonly(),
			"args": array(string()).readonly(),
			"name": string().readonly()
		}));
		let _deepseek_ai_dsh_api_terminal_controller_terminal_write_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_terminal_controller_terminal_write_parameter_0$schema = () => _deepseek_ai_dsh_api_terminal_controller_terminal_write_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_api_terminal_controller_terminal_write_parameter_1$schema$value;
		const _deepseek_ai_dsh_api_terminal_controller_terminal_write_parameter_1$schema = () => _deepseek_ai_dsh_api_terminal_controller_terminal_write_parameter_1$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_api_terminal_controller_terminal_write_parameter_2$schema$value;
		const _deepseek_ai_dsh_api_terminal_controller_terminal_write_parameter_2$schema = () => _deepseek_ai_dsh_api_terminal_controller_terminal_write_parameter_2$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_api_terminal_controller_terminal_write_parameter_3$schema$value;
		const _deepseek_ai_dsh_api_terminal_controller_terminal_write_parameter_3$schema = () => _deepseek_ai_dsh_api_terminal_controller_terminal_write_parameter_3$schema$value ??= string();
		let _deepseek_ai_dsh_api_terminal_controller_terminal_write_result$schema$value;
		const _deepseek_ai_dsh_api_terminal_controller_terminal_write_result$schema = () => _deepseek_ai_dsh_api_terminal_controller_terminal_write_result$schema$value ??= _void();
		const TYPERT_REMOTE$1 = {
			package: "@deepseek-ai/dsh-api-terminal-controller",
			descriptors: [
				{
					id: "@deepseek-ai/dsh-api-terminal-controller#terminal/close",
					service: "terminalController",
					namespace: "terminal",
					method: "close",
					invocation: { kind: "direct" },
					scope: {
						context: "agent",
						wire: "agentId"
					},
					parameters: [{
						name: "agent",
						wire: "agentId",
						source: "lookup",
						lookup: "agent",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
							create: _deepseek_ai_dsh_api_terminal_controller_terminal_close_parameter_0$schema
						}
					}, {
						name: "id",
						wire: "id",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-terminal-controller/types#WebTerminalId",
							create: _deepseek_ai_dsh_api_terminal_controller_terminal_close_parameter_1$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-terminal-controller#terminal/close:result",
						create: _deepseek_ai_dsh_api_terminal_controller_terminal_close_result$schema
					},
					sourceLocation: {
						"file": "packages/api/terminal-controller/src/index.ts",
						"line": 269,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-api-terminal-controller#terminal/create",
					service: "terminalController",
					namespace: "terminal",
					method: "create",
					invocation: { kind: "direct" },
					scope: {
						context: "agent",
						wire: "agentId"
					},
					parameters: [{
						name: "agent",
						wire: "agentId",
						source: "lookup",
						lookup: "agent",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
							create: _deepseek_ai_dsh_api_terminal_controller_terminal_create_parameter_0$schema
						}
					}, {
						name: "request",
						wire: "request",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-terminal-controller/types#TerminalCreateRequest",
							create: _deepseek_ai_dsh_api_terminal_controller_terminal_create_parameter_1$schema
						}
					}],
					cancellation: { parameter: "signal" },
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-terminal-controller/types#WebTerminalInfo",
						create: _deepseek_ai_dsh_api_terminal_controller_terminal_create_result$schema
					},
					sourceLocation: {
						"file": "packages/api/terminal-controller/src/index.ts",
						"line": 158,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-api-terminal-controller#terminal/environment",
					service: "terminalController",
					namespace: "terminal",
					method: "environment",
					invocation: { kind: "direct" },
					scope: {
						context: "agent",
						wire: "agentId"
					},
					parameters: [{
						name: "agent",
						wire: "agentId",
						source: "lookup",
						lookup: "agent",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
							create: _deepseek_ai_dsh_api_terminal_controller_terminal_environment_parameter_0$schema
						}
					}],
					cancellation: { parameter: "signal" },
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-terminal-controller/types#TerminalEnvironment",
						create: _deepseek_ai_dsh_api_terminal_controller_terminal_environment_result$schema
					},
					sourceLocation: {
						"file": "packages/api/terminal-controller/src/index.ts",
						"line": 118,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-terminal-controller#terminal/follow",
					service: "terminalController",
					namespace: "terminal",
					method: "follow",
					mode: "stream",
					invocation: { kind: "direct" },
					scope: {
						context: "agent",
						wire: "agentId"
					},
					parameters: [
						{
							name: "agent",
							wire: "agentId",
							source: "lookup",
							lookup: "agent",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
								create: _deepseek_ai_dsh_api_terminal_controller_terminal_follow_parameter_0$schema
							}
						},
						{
							name: "id",
							wire: "id",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-api-terminal-controller/types#WebTerminalId",
								create: _deepseek_ai_dsh_api_terminal_controller_terminal_follow_parameter_1$schema
							}
						},
						{
							name: "attachmentId",
							wire: "attachmentId",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-api-terminal-controller/types#TerminalAttachmentId",
								create: _deepseek_ai_dsh_api_terminal_controller_terminal_follow_parameter_2$schema
							}
						}
					],
					cancellation: { parameter: "signal" },
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-terminal-controller/types#TerminalFrame",
						create: _deepseek_ai_dsh_api_terminal_controller_terminal_follow_result$schema
					},
					sourceLocation: {
						"file": "packages/api/terminal-controller/src/index.ts",
						"line": 216,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-terminal-controller#terminal/list",
					service: "terminalController",
					namespace: "terminal",
					method: "list",
					invocation: { kind: "direct" },
					parameters: [{
						name: "sessionId",
						wire: "sessionId",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
							create: _deepseek_ai_dsh_api_terminal_controller_terminal_list_parameter_0$schema
						}
					}],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-terminal-controller#terminal/list:result",
						create: _deepseek_ai_dsh_api_terminal_controller_terminal_list_result$schema
					},
					sourceLocation: {
						"file": "packages/api/terminal-controller/src/index.ts",
						"line": 144,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-terminal-controller#terminal/rename",
					service: "terminalController",
					namespace: "terminal",
					method: "rename",
					invocation: { kind: "direct" },
					scope: {
						context: "agent",
						wire: "agentId"
					},
					parameters: [
						{
							name: "agent",
							wire: "agentId",
							source: "lookup",
							lookup: "agent",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
								create: _deepseek_ai_dsh_api_terminal_controller_terminal_rename_parameter_0$schema
							}
						},
						{
							name: "id",
							wire: "id",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-api-terminal-controller/types#WebTerminalId",
								create: _deepseek_ai_dsh_api_terminal_controller_terminal_rename_parameter_1$schema
							}
						},
						{
							name: "title",
							wire: "title",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-api-terminal-controller#terminal/rename:title",
								create: _deepseek_ai_dsh_api_terminal_controller_terminal_rename_parameter_2$schema
							}
						}
					],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-terminal-controller#terminal/rename:result",
						create: _deepseek_ai_dsh_api_terminal_controller_terminal_rename_result$schema
					},
					sourceLocation: {
						"file": "packages/api/terminal-controller/src/index.ts",
						"line": 257,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-terminal-controller#terminal/resize",
					service: "terminalController",
					namespace: "terminal",
					method: "resize",
					invocation: { kind: "direct" },
					scope: {
						context: "agent",
						wire: "agentId"
					},
					parameters: [
						{
							name: "agent",
							wire: "agentId",
							source: "lookup",
							lookup: "agent",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
								create: _deepseek_ai_dsh_api_terminal_controller_terminal_resize_parameter_0$schema
							}
						},
						{
							name: "id",
							wire: "id",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-api-terminal-controller/types#WebTerminalId",
								create: _deepseek_ai_dsh_api_terminal_controller_terminal_resize_parameter_1$schema
							}
						},
						{
							name: "attachmentId",
							wire: "attachmentId",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-api-terminal-controller/types#TerminalAttachmentId",
								create: _deepseek_ai_dsh_api_terminal_controller_terminal_resize_parameter_2$schema
							}
						},
						{
							name: "cols",
							wire: "cols",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-api-terminal-controller#terminal/resize:cols",
								create: _deepseek_ai_dsh_api_terminal_controller_terminal_resize_parameter_3$schema
							}
						},
						{
							name: "rows",
							wire: "rows",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-api-terminal-controller#terminal/resize:rows",
								create: _deepseek_ai_dsh_api_terminal_controller_terminal_resize_parameter_4$schema
							}
						}
					],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-terminal-controller#terminal/resize:result",
						create: _deepseek_ai_dsh_api_terminal_controller_terminal_resize_result$schema
					},
					sourceLocation: {
						"file": "packages/api/terminal-controller/src/index.ts",
						"line": 245,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-api-terminal-controller#terminal/retain",
					service: "terminalController",
					namespace: "terminal",
					method: "retain",
					mode: "stream",
					invocation: { kind: "direct" },
					parameters: [{
						name: "sessionId",
						wire: "sessionId",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
							create: _deepseek_ai_dsh_api_terminal_controller_terminal_retain_parameter_0$schema
						}
					}, {
						name: "id",
						wire: "id",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-terminal-controller/types#WebTerminalId",
							create: _deepseek_ai_dsh_api_terminal_controller_terminal_retain_parameter_1$schema
						}
					}],
					cancellation: { parameter: "signal" },
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-terminal-controller/types#TerminalRetentionFrame",
						create: _deepseek_ai_dsh_api_terminal_controller_terminal_retain_result$schema
					},
					sourceLocation: {
						"file": "packages/api/terminal-controller/src/index.ts",
						"line": 198,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-terminal-controller#terminal/shells",
					service: "terminalController",
					namespace: "terminal",
					method: "shells",
					invocation: { kind: "direct" },
					scope: {
						context: "agent",
						wire: "agentId"
					},
					parameters: [{
						name: "agent",
						wire: "agentId",
						source: "lookup",
						lookup: "agent",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
							create: _deepseek_ai_dsh_api_terminal_controller_terminal_shells_parameter_0$schema
						}
					}],
					cancellation: { parameter: "signal" },
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-terminal-controller#terminal/shells:result",
						create: _deepseek_ai_dsh_api_terminal_controller_terminal_shells_result$schema
					},
					sourceLocation: {
						"file": "packages/api/terminal-controller/src/index.ts",
						"line": 133,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-terminal-controller#terminal/write",
					service: "terminalController",
					namespace: "terminal",
					method: "write",
					invocation: { kind: "direct" },
					scope: {
						context: "agent",
						wire: "agentId"
					},
					parameters: [
						{
							name: "agent",
							wire: "agentId",
							source: "lookup",
							lookup: "agent",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
								create: _deepseek_ai_dsh_api_terminal_controller_terminal_write_parameter_0$schema
							}
						},
						{
							name: "id",
							wire: "id",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-api-terminal-controller/types#WebTerminalId",
								create: _deepseek_ai_dsh_api_terminal_controller_terminal_write_parameter_1$schema
							}
						},
						{
							name: "attachmentId",
							wire: "attachmentId",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-api-terminal-controller/types#TerminalAttachmentId",
								create: _deepseek_ai_dsh_api_terminal_controller_terminal_write_parameter_2$schema
							}
						},
						{
							name: "data",
							wire: "data",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-api-terminal-controller#terminal/write:data",
								create: _deepseek_ai_dsh_api_terminal_controller_terminal_write_parameter_3$schema
							}
						}
					],
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-terminal-controller#terminal/write:result",
						create: _deepseek_ai_dsh_api_terminal_controller_terminal_write_result$schema
					},
					sourceLocation: {
						"file": "packages/api/terminal-controller/src/index.ts",
						"line": 230,
						"column": 9
					}
				}
			]
		};
		//#endregion
		//#region ../workspace-files/lib/typert.remote-client.js
		let _deepseek_ai_dsh_api_workspace_files_workspaceFiles_changes_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_changes_parameter_0$schema = () => _deepseek_ai_dsh_api_workspace_files_workspaceFiles_changes_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_api_workspace_files_workspaceFiles_changes_parameter_1$schema$value;
		const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_changes_parameter_1$schema = () => _deepseek_ai_dsh_api_workspace_files_workspaceFiles_changes_parameter_1$schema$value ??= string();
		let _deepseek_ai_dsh_api_workspace_files_workspaceFiles_changes_result$schema$value;
		const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_changes_result$schema = () => _deepseek_ai_dsh_api_workspace_files_workspaceFiles_changes_result$schema$value ??= union([object({ "kind": literal("ready").readonly() }), object({
			"kind": literal("change").readonly(),
			"change": union([object({
				"absolutePath": string().readonly(),
				"version": string().readonly()
			}), object({
				"absolutePath": string().readonly(),
				"absent": literal(true).readonly()
			})]).readonly()
		})]);
		let _deepseek_ai_dsh_api_workspace_files_workspaceFiles_list_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_list_parameter_0$schema = () => _deepseek_ai_dsh_api_workspace_files_workspaceFiles_list_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_api_workspace_files_workspaceFiles_list_parameter_1$schema$value;
		const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_list_parameter_1$schema = () => _deepseek_ai_dsh_api_workspace_files_workspaceFiles_list_parameter_1$schema$value ??= string();
		let _deepseek_ai_dsh_api_workspace_files_workspaceFiles_list_result$schema$value;
		const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_list_result$schema = () => _deepseek_ai_dsh_api_workspace_files_workspaceFiles_list_result$schema$value ??= object({
			"path": string().readonly(),
			"entries": array(object({
				"name": string().readonly(),
				"type": union([
					literal("file"),
					literal("directory"),
					literal("other")
				]).readonly(),
				"size": number().readonly().optional()
			})).readonly(),
			"truncated": boolean().readonly()
		});
		let _deepseek_ai_dsh_api_workspace_files_workspaceFiles_read_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_read_parameter_0$schema = () => _deepseek_ai_dsh_api_workspace_files_workspaceFiles_read_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_api_workspace_files_workspaceFiles_read_parameter_1$schema$value;
		const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_read_parameter_1$schema = () => _deepseek_ai_dsh_api_workspace_files_workspaceFiles_read_parameter_1$schema$value ??= string();
		let _deepseek_ai_dsh_api_workspace_files_workspaceFiles_read_parameter_2$schema$value;
		const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_read_parameter_2$schema = () => _deepseek_ai_dsh_api_workspace_files_workspaceFiles_read_parameter_2$schema$value ??= object({
			"offset": number().readonly().optional(),
			"limit": number().readonly().optional()
		});
		let _deepseek_ai_dsh_api_workspace_files_workspaceFiles_read_result$schema$value;
		const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_read_result$schema = () => _deepseek_ai_dsh_api_workspace_files_workspaceFiles_read_result$schema$value ??= object({
			"offset": number().readonly(),
			"text": string().readonly(),
			"lines": number().readonly(),
			"eof": boolean().readonly(),
			"absolutePath": string().readonly(),
			"version": string().readonly(),
			"bytes": number().readonly().optional()
		});
		let _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readBytes_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readBytes_parameter_0$schema = () => _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readBytes_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readBytes_parameter_1$schema$value;
		const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readBytes_parameter_1$schema = () => _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readBytes_parameter_1$schema$value ??= string();
		let _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readBytes_parameter_2$schema$value;
		const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readBytes_parameter_2$schema = () => _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readBytes_parameter_2$schema$value ??= object({
			"range": object({
				"offset": number().readonly().optional(),
				"length": number().readonly().optional()
			}).readonly().optional(),
			"baseFile": string().readonly().optional()
		});
		let _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readBytes_result$schema$value;
		const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readBytes_result$schema = () => _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readBytes_result$schema$value ??= object({
			"offset": number().readonly(),
			"data": _instanceof(Uint8Array),
			"eof": boolean().readonly(),
			"absolutePath": string().readonly(),
			"version": string().readonly(),
			"bytes": number().readonly().optional()
		});
		let _deepseek_ai_dsh_api_workspace_files_workspaceFiles_stat_parameter_0$schema$value;
		const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_stat_parameter_0$schema = () => _deepseek_ai_dsh_api_workspace_files_workspaceFiles_stat_parameter_0$schema$value ??= intersection(string(), unknown());
		let _deepseek_ai_dsh_api_workspace_files_workspaceFiles_stat_parameter_1$schema$value;
		const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_stat_parameter_1$schema = () => _deepseek_ai_dsh_api_workspace_files_workspaceFiles_stat_parameter_1$schema$value ??= string();
		let _deepseek_ai_dsh_api_workspace_files_workspaceFiles_stat_result$schema$value;
		const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_stat_result$schema = () => _deepseek_ai_dsh_api_workspace_files_workspaceFiles_stat_result$schema$value ??= object({
			"absolutePath": string().readonly(),
			"version": string().readonly(),
			"bytes": number().readonly().optional()
		});
		const $resultSnapshot = (input, path) => {
			if (input === null || typeof input !== "object" || input instanceof Uint8Array) return input;
			const toJSON = input.toJSON;
			const value = typeof toJSON === "function" ? toJSON.call(input, path.at(-1)?.toString() ?? "value") : input;
			if (value === null || typeof value !== "object" || value instanceof Uint8Array) return value;
			if (Array.isArray(value)) {
				const items = [];
				for (let index = 0, length = value.length; index < length; index++) items.push(value[index]);
				return items;
			}
			const fields = {};
			for (const key of Object.keys(value)) {
				const item = key === "toJSON" && value === input ? toJSON : value[key];
				if (key === "toJSON" && typeof item === "function") continue;
				Object.defineProperty(fields, key, {
					value: item,
					enumerable: true,
					writable: true,
					configurable: true
				});
			}
			return fields;
		};
		const $resultContainer = (input, path, ancestors, project, snapshot) => {
			if (input === null || typeof input !== "object") return project(input);
			const owner = !ancestors.has(input);
			if (!owner && ancestors.get(input) !== path.length) throw new TypeError("Remote result contains a circular object");
			if (owner) ancestors.set(input, path.length);
			try {
				return project(snapshot ? $resultSnapshot(input, path) : input);
			} finally {
				if (owner) ancestors.delete(input);
			}
		};
		const $encode1 = (value, writeBytes, path, ancestors) => {
			return value instanceof Uint8Array ? writeBytes(value, path) : value;
		};
		const $encode0 = (value, writeBytes, path, ancestors) => {
			return $resultContainer(value, path, ancestors, (value) => {
				if (value === null || typeof value !== "object" || Array.isArray(value) || value instanceof Uint8Array) return value;
				if (Object.hasOwn(value, "data")) value["data"] = $encode1(value["data"], writeBytes, [...path, "data"], ancestors);
				return value;
			}, true);
		};
		const TYPERT_REMOTE = {
			package: "@deepseek-ai/dsh-api-workspace-files",
			descriptors: [
				{
					id: "@deepseek-ai/dsh-api-workspace-files#workspaceFiles/changes",
					service: "workspaceFiles",
					namespace: "workspaceFiles",
					method: "changes",
					mode: "stream",
					invocation: { kind: "direct" },
					parameters: [{
						name: "workspaceFileScope",
						wire: "workspaceFileScopeId",
						source: "lookup",
						lookup: "workspaceFileScope",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
							create: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_changes_parameter_0$schema
						}
					}, {
						name: "path",
						wire: "path",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-workspace-files#workspaceFiles/changes:path",
							create: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_changes_parameter_1$schema
						}
					}],
					cancellation: { parameter: "signal" },
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-workspace-files/types#WorkspaceFileWatchFrame",
						create: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_changes_result$schema
					},
					sourceLocation: {
						"file": "packages/api/workspace-files/src/index.ts",
						"line": 340,
						"column": 3
					}
				},
				{
					id: "@deepseek-ai/dsh-api-workspace-files#workspaceFiles/list",
					service: "workspaceFiles",
					namespace: "workspaceFiles",
					method: "list",
					invocation: { kind: "direct" },
					parameters: [{
						name: "workspaceFileScope",
						wire: "workspaceFileScopeId",
						source: "lookup",
						lookup: "workspaceFileScope",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
							create: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_list_parameter_0$schema
						}
					}, {
						name: "path",
						wire: "path",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-workspace-files#workspaceFiles/list:path",
							create: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_list_parameter_1$schema
						}
					}],
					cancellation: { parameter: "signal" },
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-workspace-files/types#WorkspaceDirectoryListing",
						create: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_list_result$schema
					},
					sourceLocation: {
						"file": "packages/api/workspace-files/src/index.ts",
						"line": 303,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-api-workspace-files#workspaceFiles/read",
					service: "workspaceFiles",
					namespace: "workspaceFiles",
					method: "read",
					invocation: { kind: "direct" },
					parameters: [
						{
							name: "workspaceFileScope",
							wire: "workspaceFileScopeId",
							source: "lookup",
							lookup: "workspaceFileScope",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
								create: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_read_parameter_0$schema
							}
						},
						{
							name: "path",
							wire: "path",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-api-workspace-files#workspaceFiles/read:path",
								create: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_read_parameter_1$schema
							}
						},
						{
							name: "range",
							wire: "range",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-api-workspace-files/types#WorkspaceFileRange",
								create: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_read_parameter_2$schema
							}
						}
					],
					cancellation: { parameter: "signal" },
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-workspace-files/types#WorkspaceFileText",
						create: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_read_result$schema
					},
					sourceLocation: {
						"file": "packages/api/workspace-files/src/index.ts",
						"line": 233,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-api-workspace-files#workspaceFiles/readBytes",
					service: "workspaceFiles",
					namespace: "workspaceFiles",
					method: "readBytes",
					invocation: { kind: "direct" },
					parameters: [
						{
							name: "workspaceFileScope",
							wire: "workspaceFileScopeId",
							source: "lookup",
							lookup: "workspaceFileScope",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
								create: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readBytes_parameter_0$schema
							}
						},
						{
							name: "path",
							wire: "path",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-api-workspace-files#workspaceFiles/readBytes:path",
								create: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readBytes_parameter_1$schema
							}
						},
						{
							name: "options",
							wire: "options",
							source: "json",
							codec: {
								mode: "strict",
								typeSymbol: "@deepseek-ai/dsh-api-workspace-files/types#WorkspaceByteReadOptions",
								create: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readBytes_parameter_2$schema
							}
						}
					],
					cancellation: { parameter: "signal" },
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-workspace-files/types#WorkspaceFileBytes",
						create: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readBytes_result$schema,
						decode: (value) => _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readBytes_result$schema().parse(value),
						encode: (value, writeBytes) => $encode0(value, writeBytes, [], /* @__PURE__ */ new Map())
					},
					sourceLocation: {
						"file": "packages/api/workspace-files/src/index.ts",
						"line": 257,
						"column": 9
					}
				},
				{
					id: "@deepseek-ai/dsh-api-workspace-files#workspaceFiles/stat",
					service: "workspaceFiles",
					namespace: "workspaceFiles",
					method: "stat",
					invocation: { kind: "direct" },
					parameters: [{
						name: "workspaceFileScope",
						wire: "workspaceFileScopeId",
						source: "lookup",
						lookup: "workspaceFileScope",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
							create: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_stat_parameter_0$schema
						}
					}, {
						name: "path",
						wire: "path",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-workspace-files#workspaceFiles/stat:path",
							create: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_stat_parameter_1$schema
						}
					}],
					cancellation: { parameter: "signal" },
					result: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-workspace-files/types#WorkspaceFileStat",
						create: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_stat_result$schema
					},
					sourceLocation: {
						"file": "packages/api/workspace-files/src/index.ts",
						"line": 290,
						"column": 9
					}
				}
			]
		};
		//#endregion
		//#region lib/types/client/index.js
		/** Platform-neutral assembly of generated Host Remote contributions. */
		/** Required service: the typed Client Remote contribution mount. */
		const inject = ["remote"];
		/**
		* Mount the Host capabilities explicitly selected for this Client assembly.
		* @param ctx - Client Cordis root carrying the typed API service.
		* @returns disposer after every selected Remote namespace is ready.
		*/
		async function apply(ctx) {
			const disposers = [];
			try {
				for (const contribution of [
					TYPERT_REMOTE$24,
					TYPERT_REMOTE$23,
					TYPERT_REMOTE$21,
					TYPERT_REMOTE$19,
					TYPERT_REMOTE$20,
					TYPERT_REMOTE$17,
					TYPERT_REMOTE$15,
					TYPERT_REMOTE$14,
					TYPERT_REMOTE$16,
					TYPERT_REMOTE$11,
					TYPERT_REMOTE$13,
					TYPERT_REMOTE$12,
					TYPERT_REMOTE$10,
					TYPERT_REMOTE$8,
					TYPERT_REMOTE$7,
					TYPERT_REMOTE$6,
					TYPERT_REMOTE$9,
					TYPERT_REMOTE$5,
					TYPERT_REMOTE$4,
					TYPERT_REMOTE$3,
					TYPERT_REMOTE$2,
					TYPERT_REMOTE,
					TYPERT_REMOTE$1,
					TYPERT_REMOTE$18,
					TYPERT_REMOTE$22
				]) disposers.push(await ctx.remote.$mount(contribution));
			} catch (error) {
				for (const dispose of disposers.reverse()) await dispose();
				throw error;
			}
			return async () => {
				for (const dispose of disposers.reverse()) await dispose();
			};
		}
		//#endregion
		exports.apply = apply;
		exports.inject = inject;
		return module.exports;
	}
});

//# sourceMappingURL=client.js.map
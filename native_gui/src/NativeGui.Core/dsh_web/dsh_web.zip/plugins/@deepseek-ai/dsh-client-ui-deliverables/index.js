import { remoteErrorOf } from "@deepseek-ai/dsh-typert-protocol";
//#region lib/types/changes.js
/** Authenticated GET route serving one announced change summary while its Session lives. */
const CHANGED_FILES_PATH = "/api/changes.summary";
/** Authenticated GET route serving one listed file's turn-start and turn-end comparison while its Session lives. */
const CHANGES_DIFF_PATH = "/api/changes.diff";
/** Authenticated POST route for opening a changed file on the Host desktop. */
const CHANGES_OPEN_PATH = "/api/changes.open";
CHANGED_FILES_PATH.slice(1);
CHANGES_DIFF_PATH.slice(1);
CHANGES_OPEN_PATH.slice(1);
//#endregion
//#region lib/types/presented.js
/** Authenticated POST route for opening a workspace file on the Host desktop. */
const PRESENT_OPEN_PATH = "/api/present.open";
/** Authenticated desktop availability and destination metadata. */
const PRESENT_HOST_PATH = "/api/present.host";
PRESENT_OPEN_PATH.slice(1);
PRESENT_HOST_PATH.slice(1);
/**
* Validate a file declaration read from a Session log.
* @param value - decoded durable data.
* @returns whether the declaration contains a path and optional description.
*/
function isPresentedFile(value) {
	if (typeof value !== "object" || value === null || Array.isArray(value)) return false;
	const { path, description } = value;
	return typeof path === "string" && path.trim().length > 0 && (description === void 0 || typeof description === "string");
}
/**
* Validate a delivery event before reading its turn or file declarations.
* @param value - decoded durable event data.
* @returns whether the event identifies a turn, call, and file list.
*/
function isPresentedData(value) {
	if (typeof value !== "object" || value === null || Array.isArray(value)) return false;
	const { turn, callId, files } = value;
	return typeof turn === "number" && Number.isSafeInteger(turn) && turn >= 1 && typeof callId === "string" && callId.length > 0 && Array.isArray(files);
}
//#endregion
//#region lib/types/present-open.js
/**
* Register the deliverables routes inside Connection's authentication fence:
* desktop metadata, change summaries and comparisons, declared-file actions,
* and changed-file opening.
* @param ctx - Session lookup, change summaries, native opener, and route lifetime.
*/
function registerPresentOpen(ctx) {
	ctx.connection.fetch.register({
		path: PRESENT_HOST_PATH,
		methods: ["GET"],
		requestBody: "buffered",
		fetch: () => Promise.resolve(Response.json(ctx.sessionController.workspaceDesktop(), { headers: { "cache-control": "no-store" } }))
	});
	ctx.connection.fetch.register({
		path: CHANGED_FILES_PATH,
		methods: ["GET"],
		requestBody: "buffered",
		fetch: (request) => Promise.resolve(handleChangesSummary(ctx, request))
	});
	const lifetime = new AbortController();
	const pending = /* @__PURE__ */ new Set();
	ctx.effect(() => async () => {
		lifetime.abort();
		await Promise.allSettled(pending);
	});
	const routes = [
		[
			PRESENT_OPEN_PATH,
			["GET", "POST"],
			handlePresentOpen
		],
		[
			CHANGES_OPEN_PATH,
			["GET", "POST"],
			handleChangesOpen
		],
		[
			CHANGES_DIFF_PATH,
			["GET"],
			handleChangesDiff
		]
	];
	for (const [path, methods, handler] of routes) ctx.connection.fetch.register({
		path,
		methods: [...methods],
		requestBody: "buffered",
		fetch: (request) => {
			const task = handler(ctx, new Request(request, { signal: AbortSignal.any([request.signal, lifetime.signal]) }));
			pending.add(task);
			task.then(() => {
				pending.delete(task);
			}, () => {
				pending.delete(task);
			});
			return task;
		}
	});
}
const NUMERIC = /^\d+$/;
function coordinate(value) {
	return value !== null && NUMERIC.test(value) && Number.isSafeInteger(Number(value)) ? Number(value) : void 0;
}
/** Translate lookup and filesystem failures into the not-found or failure status the browser retries from. */
function failureStatus(error) {
	const remote = remoteErrorOf(error);
	return remote?.code === "session/not-found" || remote?.code === "workspace-file/not-found" || remote?.code === "workspace-file/not-regular-file" || error instanceof Error && "code" in error && (error.code === "SESSION_QUERY_SESSION_NOT_FOUND" || error.code === "SESSION_QUERY_EVENT_NOT_FOUND" || error.code === "ENOENT" || error.code === "ENOTDIR") ? 404 : 500;
}
/**
* Read the addressed event once the Host desktop is known to be available.
* @returns the event with its Session header, or the refusal to answer with.
*/
async function readTarget(ctx, request, id, seq) {
	request.signal.throwIfAborted();
	if (!ctx.sessionController.workspaceDesktop().available) return new Response("Host desktop unavailable.", { status: 409 });
	return ctx.sessionQuery.readEvent({
		sessionId: id,
		seq,
		before: 0,
		after: 0
	}, request.signal);
}
/**
* Open one verified Host path. A file is verified through the Session
* filesystem; a directory is verified by the Host filesystem mapping alone.
* @returns the HTTP status to answer with.
*/
async function openVerified(ctx, request, path, action) {
	const { fs } = ctx;
	const mapped = fs.processPathFromHostPath(path);
	if (mapped === void 0 || fs.processPath(await fs.resolve(mapped, { signal: request.signal })) !== path) return new Response("Path has no verified Host path.", { status: 422 });
	request.signal.throwIfAborted();
	if (request.method === "GET") return Response.json(await ctx.sessionController.workspacePathApplications({ path }, request.signal), { headers: { "cache-control": "no-store" } });
	const application = new URL(request.url).searchParams.get("application");
	await ctx.sessionController.openWorkspacePath({
		path,
		...action === "reveal" ? { action } : application === null ? {} : { application }
	}, request.signal);
	return new Response(null, {
		status: 204,
		headers: { "cache-control": "no-store" }
	});
}
async function handlePresentOpen(ctx, request) {
	const query = new URL(request.url).searchParams;
	const action = query.get("action") ?? "open";
	if (action !== "open" && action !== "reveal") return new Response("Invalid file action.", { status: 400 });
	const id = query.get("sessionId");
	const seq = coordinate(query.get("seq"));
	const index = coordinate(query.get("index"));
	if (!id || seq === void 0 || index === void 0) return new Response("Invalid Presented file coordinates.", { status: 400 });
	try {
		const read = await readTarget(ctx, request, id, seq);
		if (read instanceof Response) return read;
		const { target, session } = read;
		const file = target.type === "deliverables/presented" && isPresentedData(target.data) ? target.data.files[index] : void 0;
		if (!isPresentedFile(file)) return new Response("Presented file not found in this Session result.", { status: 404 });
		request.signal.throwIfAborted();
		const { absolutePath: path } = await ctx.workspaceFiles.stat({
			sessionId: id,
			workspaceRoot: session.cwd ?? ctx.sandboxPolicy.workspaceRoot
		}, file.path, request.signal);
		return await openVerified(ctx, request, path, action);
	} catch (error) {
		request.signal.throwIfAborted();
		return new Response("Presented file unavailable.", { status: failureStatus(error) });
	}
}
/** The summary one `workspace/changes` event announced, without the Host working directory; 404 once the Host no longer serves it. */
function handleChangesSummary(ctx, request) {
	const query = new URL(request.url).searchParams;
	const id = query.get("sessionId");
	const seq = coordinate(query.get("seq"));
	if (!id || seq === void 0) return new Response("Invalid change summary coordinates.", { status: 400 });
	const summary = ctx.workspaceChanges.summary(id, seq);
	if (summary === void 0) return new Response("Change summary unavailable.", { status: 404 });
	const { turn, files, total, added, deleted } = summary;
	return Response.json({
		turn,
		files,
		total,
		added,
		deleted
	}, { headers: { "cache-control": "no-store" } });
}
/** A changed file's coordinates from a route query, or the 400 to answer with. */
function changedFileCoordinates(request) {
	const query = new URL(request.url).searchParams;
	const id = query.get("sessionId");
	const seq = coordinate(query.get("seq"));
	const index = coordinate(query.get("index"));
	if (!id || seq === void 0 || index === void 0) return new Response("Invalid changed file coordinates.", { status: 400 });
	return {
		id,
		seq,
		index
	};
}
/** One listed file's comparison; 404 once the Host no longer serves the summary or the index names no file. */
async function handleChangesDiff(ctx, request) {
	const coordinates = changedFileCoordinates(request);
	if (coordinates instanceof Response) return coordinates;
	const { id, seq, index } = coordinates;
	try {
		const diff = await ctx.workspaceChanges.diff(id, seq, index, request.signal);
		if (diff === void 0) return new Response("Change comparison unavailable.", { status: 404 });
		return Response.json(diff, { headers: { "cache-control": "no-store" } });
	} catch (error) {
		request.signal.throwIfAborted();
		return new Response("Change comparison unavailable.", { status: failureStatus(error) });
	}
}
async function handleChangesOpen(ctx, request) {
	const action = new URL(request.url).searchParams.get("action") ?? "open";
	if (action !== "open" && action !== "reveal") return new Response("Invalid file action.", { status: 400 });
	const coordinates = changedFileCoordinates(request);
	if (coordinates instanceof Response) return coordinates;
	const { id, seq, index } = coordinates;
	try {
		request.signal.throwIfAborted();
		if (!ctx.sessionController.workspaceDesktop().available) return new Response("Host desktop unavailable.", { status: 409 });
		const changes = ctx.workspaceChanges.summary(id, seq);
		if (changes === void 0) return new Response("Change summary unavailable.", { status: 404 });
		const workspaceRoot = changes.cwd;
		const file = changes.files[index];
		if (file === void 0) return new Response("Changed file not found in this summary.", { status: 404 });
		const { absolutePath: path } = await ctx.workspaceFiles.stat({
			sessionId: id,
			workspaceRoot
		}, file.path, request.signal);
		return await openVerified(ctx, request, path, action);
	} catch (error) {
		request.signal.throwIfAborted();
		return new Response("Changed file unavailable.", { status: failureStatus(error) });
	}
}
//#endregion
//#region lib/types/index.js
/**
* Deliverables plugin, node half. Registers Web file-reference guidance and
* serves authenticated native opens of declared files. The browser
* half ships via exports["./client"], discovered through the package.json
* dsh.client declaration.
*/
/** Services required for file-reference guidance, change summaries, and authenticated native opens. */
const inject = [
	"systemPrompt",
	"connection",
	"sessionQuery",
	"sessionController",
	"workspaceFiles",
	"fs",
	"sandboxPolicy",
	"workspaceChanges"
];
/** Static Web guidance for primary outputs and existing-file references. */
const FILE_REFERENCE_PROMPT = "Prefer showing the primary results within your final response alongside a brief explanation. Use ![Description](<path/to/image.png>) when an image supports an explanation or comparison. Use [Description](<path/to/image.png>) when referring to an image or listing files. Enclose Markdown file destinations in angle brackets, especially paths containing spaces. Do not call present just to list edited source files, or run commands to check whether a diff view will appear. Use present when a separate file card helps the user open the complete deliverable, including images, Office documents, spreadsheets, and slide decks. Each presented file adds a card below the reply, with preview and native-open actions. Avoid repeating results already shown inline unless the separate card adds useful access. Outside commands, configuration expressions, and code blocks, link every mention of an existing file, including repeats and tables, to its full path relative to the working directory or absolute; append #L24 or #L24-L30 to the target for known lines. Use the filename or a clear alias as the label, adding only enough parent directories to distinguish files; keep full paths out of labels. Default to the name alone; when precise locations matter, append :24 or :24–30, with no # or L in the line suffix.";
/**
* Register Web file-reference guidance and native opens for declared files.
* @param ctx - host context carrying the system-prompt registry.
*/
function apply(ctx) {
	registerPresentOpen(ctx);
	ctx.systemPrompt.section({
		name: "ui:deliverable-file-references",
		order: ctx.systemPrompt.getSectionOrder("DELIVERABLE_FILE_REFERENCES"),
		text: FILE_REFERENCE_PROMPT
	});
}
//#endregion
export { apply, inject };

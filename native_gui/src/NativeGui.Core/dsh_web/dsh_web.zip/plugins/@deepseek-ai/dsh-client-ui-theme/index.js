import z from "@deepseek-ai/schemastery";
//#region lib/types/theme-settings.js
/** Theme preferences stored in the Host user-settings document. */
/** Built-in preferences accepted at the registry and settings boundaries. */
const THEME_PREFERENCES = [
	"light",
	"dark",
	"system"
];
/** Settings namespace owned by the theme plugin. */
const THEME_SETTINGS_NAMESPACE = "ui-theme";
/** Field carrying the selected built-in theme preference. */
const THEME_PREFERENCE_FIELD = "preference";
/** Field carrying the conversation content font size. */
const FONT_SIZE_FIELD = "fontSize";
/** Default preference when the user-settings document has no override. */
const DEFAULT_PREFERENCE = "system";
/** Smallest accepted content font size (px). */
const FONT_SIZE_MIN = 10;
/** Largest accepted content font size (px). */
const FONT_SIZE_MAX = 22;
/** Content font size when the user-settings document has no override (px). */
const DEFAULT_FONT_SIZE = 14;
z.object({
	[THEME_PREFERENCE_FIELD]: z.union([...THEME_PREFERENCES]).default(DEFAULT_PREFERENCE),
	[FONT_SIZE_FIELD]: z.number().step(1).min(10).max(22).default(14)
});
//#endregion
//#region lib/types/boot-theme.js
/**
* Theme bootstrap row for the browser's pre-plugin interval. Each index
* render embeds the current durable built-in preference and content font size.
* Head CSS colors the document canvas before script execution; the body script
* installs the palette selector and font size that the client presenters adopt.
*/
const LIGHT_BACKGROUND = "#fff";
const DARK_BACKGROUND = "#151517";
/** CSS that colors the document canvas before any script executes. */
function bootThemeStyle(preference) {
	const light = `:root{color-scheme:light}body{background-color:${LIGHT_BACKGROUND};--dsh-boot-bg:${LIGHT_BACKGROUND}}`;
	const dark = `:root{color-scheme:dark}body{background-color:${DARK_BACKGROUND};--dsh-boot-bg:${DARK_BACKGROUND}}`;
	if (preference === "light") return light;
	if (preference === "dark") return dark;
	return `${light}@media(prefers-color-scheme:dark){${dark}}`;
}
/** Build the body script that installs the palette selector and content size. */
function bootThemeBodyScript(preference, fontSize) {
	return `(() => {
  const preference = ${JSON.stringify(preference)}
  const systemDark = preference === 'system'
    && typeof matchMedia !== 'undefined'
    && matchMedia('(prefers-color-scheme: dark)').matches
  const dark = preference === 'dark' || systemDark
  document.documentElement.dataset.dsThemeSource = preference
  document.body.toggleAttribute('data-ds-dark-theme', dark)
  document.body.style.setProperty('--dsh-content-font-size', ${JSON.stringify(`${fontSize}px`)})
})()`;
}
/**
* Theme bootstrap rows: head CSS colors the document canvas before
* first paint, then the body script installs the palette selector and font
* size before the shell mount and module script.
* @param preference - Current Host-backed built-in preference.
* @param fontSize - Current Host-backed content font size in px.
* @returns head and body script rows in execution order.
*/
function bootThemeInjections(preference = DEFAULT_PREFERENCE, fontSize = 14) {
	return [{
		kind: "style",
		text: bootThemeStyle(preference)
	}, {
		kind: "script",
		placement: "body",
		text: bootThemeBodyScript(preference, fontSize)
	}];
}
//#endregion
//#region lib/types/index.js
/** Live theme and typography preferences. */
const Config = z.object({
	preference: z.union([...THEME_PREFERENCES]).default(DEFAULT_PREFERENCE).volatile(),
	fontSize: z.number().step(1).min(10).max(22).default(14).volatile()
});
/** Supply the current palette before browser plugins start.
* @param ctx Host plugin context.
* @param config Validated live theme preferences.
*/
function apply(ctx, config) {
	ctx.inject(["settings"], (child) => {
		child.effect(() => child.settings.configure({ auto: false }, ctx.fiber));
	});
	ctx.on("webserver/index-inject", (table) => {
		table.push(...bootThemeInjections(config.preference.get(), config.fontSize.get()));
	}, { prepend: true });
}
//#endregion
export { Config, DEFAULT_FONT_SIZE, DEFAULT_PREFERENCE, FONT_SIZE_FIELD, FONT_SIZE_MAX, FONT_SIZE_MIN, THEME_PREFERENCES, THEME_PREFERENCE_FIELD, THEME_SETTINGS_NAMESPACE, apply };
